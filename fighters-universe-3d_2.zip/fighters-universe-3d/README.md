# Fighters Universe 3D

## Como executar no navegador
1. Extraia a pasta e abra `index.html` (Chrome, Edge ou Firefox). Precisa de internet só para baixar o Three.js (r128) e as fontes.
2. Ou use um servidor local: `python3 -m http.server` e acesse http://localhost:8000

## Como virar APK / app instalável
Veja **BUILD-APK.md** (GitHub Actions sem instalar nada, Android Studio, ou PWA).

## Estrutura (ordem de carregamento)
- `js/00_core.js`     utilitários, armazenamento, qualidade gráfica, som procedural, entrada (teclas remapeáveis)
- `js/05_data.js`     opções do editor, estilos de luta, atributos, lutadores prontos
- `js/10_rig.js`      modelo 3D procedural articulado + aplicação de poses
- `js/20_anim.js`     poses, interpolação e tabela de golpes (MOVES)
- `js/30_fighter.js`  estados, movimento, golpes, defesa, dano, janelas de ataque e colisão
- `js/40_ai.js`       IA (4 níveis + bonecos de treino) e controle do jogador
- `js/50_arenas.js`   3 arenas
- `js/60_match.js`    efeitos, câmera dinâmica, rounds, vitória/derrota
- `js/70_ui.js`       perfil salvo, palco 3D, editor, seleção de luta, HUD, ajustes
- `js/75_touch.js`    controles na tela (joystick + botões) para celular
- `js/80_main.js`     laço principal, resolução dinâmica e fluxo entre telas
- `css/style.css`     identidade visual

## Controles (teclado; alteráveis em Controles e opções)
A/D mover · W/S contornar o oponente · J soco rápido · K soco forte · L chute · U chute forte · I defesa · Espaço esquiva · Shift corrida · E agarrão · Esc (ou P) pausar
No celular: joystick à esquerda e botões à direita.
