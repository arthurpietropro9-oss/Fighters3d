'use strict';
/* =====================================================================
   FIGHTERS UNIVERSE 3D
   MÓDULO 00 — Núcleo: utilitários, armazenamento, configurações, som, entrada
   ===================================================================== */

const U = {
  clamp: (v, a, b) => (v < a ? a : v > b ? b : v),
  lerp: (a, b, t) => a + (b - a) * t,
  damp: (a, b, l, dt) => a + (b - a) * (1 - Math.exp(-l * dt)),
  rand: (a, b) => a + Math.random() * (b - a),
  randInt: (a, b) => Math.floor(a + Math.random() * (b - a + 1)),
  pick: (arr) => arr[Math.floor(Math.random() * arr.length)],
  smooth: (t) => { t = t < 0 ? 0 : t > 1 ? 1 : t; return t * t * (3 - 2 * t); },
  easeOut: (t) => { t = t < 0 ? 0 : t > 1 ? 1 : t; return 1 - (1 - t) * (1 - t); },
  angDiff: (a, b) => { let d = (b - a) % (Math.PI * 2); if (d > Math.PI) d -= Math.PI * 2; if (d < -Math.PI) d += Math.PI * 2; return d; },
  dampAngle: (a, b, l, dt) => a + U.angDiff(a, b) * (1 - Math.exp(-l * dt)),
  clone: (o) => JSON.parse(JSON.stringify(o)),
  uid: () => 'f' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
  // distância de um ponto a um segmento (sem alocar objetos)
  ptSeg(px, py, pz, ax, ay, az, bx, by, bz) {
    const abx = bx - ax, aby = by - ay, abz = bz - az;
    const l2 = abx * abx + aby * aby + abz * abz;
    let t = l2 > 1e-9 ? ((px - ax) * abx + (py - ay) * aby + (pz - az) * abz) / l2 : 0;
    t = t < 0 ? 0 : t > 1 ? 1 : t;
    const dx = px - (ax + abx * t), dy = py - (ay + aby * t), dz = pz - (az + abz * t);
    return Math.sqrt(dx * dx + dy * dy + dz * dz);
  },
  $: (sel, root) => (root || document).querySelector(sel),
  $$: (sel, root) => Array.from((root || document).querySelectorAll(sel)),
};

/* ---------- Armazenamento (localStorage com reserva em memória) ---------- */
const Store = {
  mem: {},
  get(k, def) {
    try {
      const v = localStorage.getItem('fu_' + k);
      if (v !== null) return JSON.parse(v);
    } catch (e) { /* sem storage */ }
    return k in Store.mem ? Store.mem[k] : def;
  },
  set(k, v) {
    Store.mem[k] = v;
    try { localStorage.setItem('fu_' + k, JSON.stringify(v)); } catch (e) { /* ignora */ }
  },
};

/* ---------- Controles padrão (podem ser remapeados em Configurações) ---------- */
const ACTIONS = [
  { id: 'left',       label: 'Mover para a esquerda',  def: ['KeyA'] },
  { id: 'right',      label: 'Mover para a direita',   def: ['KeyD'] },
  { id: 'up',         label: 'Contornar (fundo da tela)', def: ['KeyW'] },
  { id: 'down',       label: 'Contornar (frente da tela)', def: ['KeyS'] },
  { id: 'jab',        label: 'Soco rápido',            def: ['KeyJ'] },
  { id: 'heavyPunch', label: 'Soco forte',             def: ['KeyK'] },
  { id: 'kick',       label: 'Chute (baixo)',          def: ['KeyL'] },
  { id: 'heavyKick',  label: 'Chute forte (alto)',     def: ['KeyU'] },
  { id: 'block',      label: 'Defesa (segurar)',       def: ['KeyI'] },
  { id: 'dodge',      label: 'Esquiva',                def: ['Space'] },
  { id: 'run',        label: 'Corrida (segurar)',      def: ['ShiftLeft'] },
  { id: 'grab',       label: 'Agarrão',                def: ['KeyE'] },
  { id: 'pause',      label: 'Pausar',                 def: ['Escape', 'KeyP'] },
];

const IS_TOUCH = typeof window !== 'undefined' && (('ontouchstart' in window) || (typeof navigator !== 'undefined' && navigator.maxTouchPoints > 0));

const Settings = {
  data: { sound: true, volume: 0.6, quality: IS_TOUCH ? 'baixa' : 'media', touch: 'auto', rounds: 3, roundTime: 60, bindings: {} },
  load() {
    const s = Store.get('settings', null);
    if (s) Object.assign(Settings.data, s);
    Settings.data.bindings = Settings.data.bindings || {};
  },
  save() { Store.set('settings', Settings.data); },
};

/* ---------- Qualidade gráfica (desempenho) ---------- */
const QUALITY = {
  baixa: { name: 'Baixa', shadows: false, smap: 512, pr: 0.75, lights: false, crowd: 0.35, lambert: true, aa: false },
  media: { name: 'Média', shadows: true, smap: 1024, pr: 1, lights: true, crowd: 0.7, lambert: false, aa: false },
  alta:  { name: 'Alta',  shadows: true, smap: 2048, pr: 2, lights: true, crowd: 1, lambert: false, aa: true },
};
const Quality = { cfg() { return QUALITY[Settings.data.quality] || QUALITY.media; } };
/* Material padrão do jogo: em "Baixa" usa Lambert (bem mais leve para a GPU) */
function mkMat(o) {
  if (Quality.cfg().lambert) { const c = Object.assign({}, o); delete c.roughness; delete c.metalness; return new THREE.MeshLambertMaterial(c); }
  return new THREE.MeshStandardMaterial(o);
}

/* ---------- Nome legível de uma tecla ---------- */
function keyLabel(code) {
  if (!code) return '—';
  if (code.startsWith('Key')) return code.slice(3);
  if (code.startsWith('Digit')) return code.slice(5);
  const m = { Space: 'Espaço', ShiftLeft: 'Shift', ShiftRight: 'Shift', ControlLeft: 'Ctrl', ControlRight: 'Ctrl', AltLeft: 'Alt', AltRight: 'Alt',
    Escape: 'Esc', Enter: 'Enter', ArrowUp: '↑', ArrowDown: '↓', ArrowLeft: '←', ArrowRight: '→', Tab: 'Tab', Backspace: '⌫' };
  return m[code] || code;
}

/* ---------- Entrada de teclado ---------- */
const Input = {
  down: new Set(),
  queue: [],            // ações pressionadas desde o último flush
  capture: null,        // função usada ao remapear teclas
  active: false,        // true quando o jogo (luta) está em andamento
  norm(code) { return code === 'ShiftRight' ? 'ShiftLeft' : code === 'ControlRight' ? 'ControlLeft' : code === 'AltRight' ? 'AltLeft' : code; },
  codes(action) {
    const b = Settings.data.bindings[action];
    if (b && b.length) return b;
    return ACTIONS.find((a) => a.id === action).def;
  },
  actionsFor(code) {
    code = Input.norm(code);
    return ACTIONS.filter((a) => Input.codes(a.id).some((c) => Input.norm(c) === code)).map((a) => a.id);
  },
  isDown(action) { return Input.codes(action).some((c) => Input.down.has(Input.norm(c))); },
  flush() { const q = Input.queue; Input.queue = []; return q; },
  press(action) { Input.queue.push(action); },       // usado também em testes automáticos
  onKeyDown(e) {
    if (Input.capture) { e.preventDefault(); Input.capture(e.code); return; }
    const tag = e.target && e.target.tagName;
    if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
    const code = Input.norm(e.code);
    const acts = Input.actionsFor(code);
    if (Input.active && acts.length) e.preventDefault();
    if (!Input.down.has(code)) {
      Input.down.add(code);
      acts.forEach((a) => { if (a === 'pause') { if (Input.onPause) Input.onPause(); } else Input.queue.push(a); });
    } else if (e.repeat && Input.active && acts.length) { /* ignora repetição */ }
  },
  onKeyUp(e) { Input.down.delete(Input.norm(e.code)); },
  init() {
    window.addEventListener('keydown', Input.onKeyDown);
    window.addEventListener('keyup', Input.onKeyUp);
    window.addEventListener('blur', () => Input.down.clear());
  },
};

/* ---------- Som procedural (WebAudio, sem arquivos externos) ---------- */
const Sound = {
  ctx: null, master: null, noise: null, ok: true, crowd: null,
  init() {
    if (Sound.ctx || !Sound.ok) return;
    try {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) { Sound.ok = false; return; }
      Sound.ctx = new AC();
      Sound.master = Sound.ctx.createGain();
      Sound.master.gain.value = Settings.data.sound ? Settings.data.volume : 0;
      Sound.master.connect(Sound.ctx.destination);
      const len = Sound.ctx.sampleRate * 1.5;
      const buf = Sound.ctx.createBuffer(1, len, Sound.ctx.sampleRate);
      const d = buf.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
      Sound.noise = buf;
    } catch (e) { Sound.ok = false; }
  },
  resume() { if (Sound.ctx && Sound.ctx.state === 'suspended') Sound.ctx.resume(); },
  applyVolume() { if (Sound.master) Sound.master.gain.value = Settings.data.sound ? Settings.data.volume : 0; },
  tone(o) {
    if (!Sound.ctx) return;
    const c = Sound.ctx, t0 = c.currentTime + (o.delay || 0);
    const osc = c.createOscillator(), g = c.createGain();
    osc.type = o.type || 'sine';
    osc.frequency.setValueAtTime(o.f1, t0);
    if (o.f2) osc.frequency.exponentialRampToValueAtTime(Math.max(1, o.f2), t0 + o.dur);
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(o.vol || 0.3, t0 + (o.att || 0.005));
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + o.dur);
    osc.connect(g); g.connect(Sound.master);
    osc.start(t0); osc.stop(t0 + o.dur + 0.05);
  },
  burst(o) {
    if (!Sound.ctx || !Sound.noise) return;
    const c = Sound.ctx, t0 = c.currentTime + (o.delay || 0);
    const src = c.createBufferSource(); src.buffer = Sound.noise;
    const f = c.createBiquadFilter(); f.type = o.ftype || 'lowpass';
    f.frequency.setValueAtTime(o.f1, t0);
    if (o.f2) f.frequency.exponentialRampToValueAtTime(Math.max(20, o.f2), t0 + o.dur);
    f.Q.value = o.q || 0.8;
    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.exponentialRampToValueAtTime(o.vol || 0.3, t0 + (o.att || 0.004));
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + o.dur);
    src.connect(f); f.connect(g); g.connect(Sound.master);
    src.start(t0, Math.random() * 0.5); src.stop(t0 + o.dur + 0.05);
  },
  play(name, k) {
    if (!Sound.ctx || !Settings.data.sound) return;
    k = k || 1;
    switch (name) {
      case 'whoosh': Sound.burst({ ftype: 'bandpass', f1: 500, f2: 2200, dur: 0.14, vol: 0.10 * k, q: 0.7, att: 0.05 }); break;
      case 'punch':
        Sound.tone({ f1: 160, f2: 50, dur: 0.14, vol: 0.5 * k, type: 'triangle' });
        Sound.burst({ f1: 2500, f2: 300, dur: 0.1, vol: 0.45 * k }); break;
      case 'kick':
        Sound.tone({ f1: 110, f2: 38, dur: 0.2, vol: 0.65 * k, type: 'triangle' });
        Sound.burst({ f1: 1800, f2: 200, dur: 0.15, vol: 0.5 * k }); break;
      case 'block':
        Sound.tone({ f1: 320, f2: 180, dur: 0.07, vol: 0.18, type: 'square' });
        Sound.burst({ ftype: 'bandpass', f1: 1200, dur: 0.07, vol: 0.2 }); break;
      case 'dodge': Sound.burst({ ftype: 'highpass', f1: 1800, f2: 4000, dur: 0.18, vol: 0.07, att: 0.06 }); break;
      case 'grab': Sound.burst({ f1: 900, dur: 0.1, vol: 0.2 }); Sound.tone({ f1: 200, f2: 120, dur: 0.1, vol: 0.2, type: 'triangle' }); break;
      case 'slam':
        Sound.tone({ f1: 90, f2: 28, dur: 0.45, vol: 0.9, type: 'triangle' });
        Sound.burst({ f1: 1400, f2: 120, dur: 0.3, vol: 0.55 }); break;
      case 'ko':
        Sound.tone({ f1: 70, f2: 24, dur: 0.9, vol: 0.9, type: 'sine' });
        Sound.burst({ f1: 900, f2: 80, dur: 0.7, vol: 0.5 });
        Sound.crowdCheer(1.6); break;
      case 'bell':
        [0, 0.28].forEach((d) => {
          Sound.tone({ f1: 880, dur: 1.4, vol: 0.22, delay: d, type: 'sine' });
          Sound.tone({ f1: 1760, dur: 0.9, vol: 0.1, delay: d, type: 'sine' });
          Sound.tone({ f1: 2640, dur: 0.5, vol: 0.05, delay: d, type: 'sine' });
        }); break;
      case 'click': Sound.tone({ f1: 700, f2: 500, dur: 0.05, vol: 0.12, type: 'square' }); break;
      case 'select': Sound.tone({ f1: 520, f2: 880, dur: 0.09, vol: 0.14, type: 'square' }); break;
      case 'step': Sound.burst({ f1: 300, dur: 0.05, vol: 0.05 }); break;
      case 'win':
        [523, 659, 784, 1046].forEach((f, i) => Sound.tone({ f1: f, dur: 0.35, vol: 0.2, delay: i * 0.13, type: 'triangle' })); break;
      case 'lose':
        [392, 330, 262].forEach((f, i) => Sound.tone({ f1: f, dur: 0.45, vol: 0.2, delay: i * 0.2, type: 'sawtooth' })); break;
      default: break;
    }
  },
  crowdCheer(len) {
    if (!Sound.ctx) return;
    Sound.burst({ ftype: 'bandpass', f1: 700, f2: 1100, dur: len, vol: 0.12, att: 0.4, q: 0.5 });
  },
  crowdStart() {
    if (!Sound.ctx || !Sound.noise || Sound.crowd) return;
    const c = Sound.ctx, src = c.createBufferSource();
    src.buffer = Sound.noise; src.loop = true;
    const f = c.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = 600; f.Q.value = 0.4;
    const g = c.createGain(); g.gain.value = 0.035;
    src.connect(f); f.connect(g); g.connect(Sound.master); src.start();
    Sound.crowd = { src, g };
  },
  crowdStop() { if (Sound.crowd) { try { Sound.crowd.src.stop(); } catch (e) { /* */ } Sound.crowd = null; } },
};
