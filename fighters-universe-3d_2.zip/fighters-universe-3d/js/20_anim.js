/* =====================================================================
   MÓDULO 20 — Animação: poses, interpolação e tabela de golpes
   Uma pose é um objeto com todas as chaves de POSE_KEYS (ângulos em radianos).
   Arma: S=ombro (x=levantar à frente, y=varrer à frente, z=abrir), El=cotovelo (flexão)
   Perna: H=quadril (x=levantar à frente, y=varrer, z=abrir), K=joelho (flexão), A=tornozelo, Pl=peso de "plantio" no chão
   ===================================================================== */

const POSE_KEYS = ['y', 'hRy', 'sRx', 'sRy', 'sRz', 'hdRx', 'hdRy', 'hdRz',
  'lSx', 'lSy', 'lSz', 'lEl', 'rSx', 'rSy', 'rSz', 'rEl',
  'lHx', 'lHy', 'lHz', 'lK', 'lA', 'lPl', 'lLift', 'rHx', 'rHy', 'rHz', 'rK', 'rA', 'rPl', 'rLift',
  'tRx', 'tRz', 'bx', 'by', 'bz'];

const ZERO = {}; POSE_KEYS.forEach((k) => { ZERO[k] = 0; });

/* Guarda padrão (lutador destro: perna e mão esquerdas à frente) */
const GUARD = Object.assign({}, ZERO, {
  y: -0.07, hRy: -0.22, sRx: 0.10, sRy: -0.12, hdRx: 0.14, hdRy: 0.34,
  lSx: 0.70, lSz: 0.22, lEl: 1.95, rSx: 0.60, rSz: 0.12, rEl: 2.15,
  lHx: 0.38, lHz: 0.10, rHx: -0.28, rHz: 0.14, lPl: 1, rPl: 1,
});

const P = (o) => Object.assign({}, GUARD, o || {});
const poseCopy = (p) => Object.assign({}, p);
function poseLerp(a, b, t, out) {
  out = out || {};
  for (let i = 0; i < POSE_KEYS.length; i++) { const k = POSE_KEYS[i]; out[k] = a[k] + (b[k] - a[k]) * t; }
  return out;
}

const BLOCK_POSE = P({ y: -0.12, sRx: 0.25, hdRx: 0.32, lSx: 1.25, lSz: 0.10, lEl: 2.4, rSx: 1.2, rSz: 0.08, rEl: 2.45 });

/* ---------- Poses-chave dos golpes (relativas à guarda) ---------- */
const X_JAB    = { lSx: 1.96, lSz: 0.6, lEl: 0, sRy: -0.51, hRy: -0.3, hdRy: 0.5, y: -0.08 };
const X_CROSS  = { rSx: 1.91, rSz: 0.5, rEl: 0, sRy: 0.61, hRy: 0.14, hdRy: 0.1, rHx: -0.05, y: -0.09 };
const X_HOOK   = { lSz: 1.68, lSy: 1.24, lSx: 0.25, lEl: 0.8, sRy: -0.2, hRy: 0.1, y: -0.08 };
const X_UPPER  = { y: -0.02, sRx: 0.0, rSx: 1.37, rEl: 0.6, rSz: 0.5, sRy: 0.56, hRy: 0.15 };
const X_FRONT  = { lPl: 0, lHx: 1.67, lK: 0.15, lA: 0.5, sRx: -0.28, y: -0.04 };
const X_LOW    = { rPl: 0, rHx: 0.91, rHz: 0.49, rHy: 0.52, rK: 0.24, hRy: 0.53, sRy: 0.3, sRz: -0.2, sRx: 0.1, y: -0.1 };
const X_HIGH   = { rPl: 0, rHx: 0.65, rHz: 1.79, rHy: 0.95, rK: 0.26, hRy: 0.9, sRz: -0.55, sRy: 0.2, y: -0.04 };
const X_KNEE   = { rPl: 0, rHx: 1.71, rK: 1.6, rA: 0.6, rHz: 0.3, hRy: 0.45, sRx: 0.3, lSx: 1.0, rSx: 1.0, lEl: 1.6, rEl: 1.6, y: -0.02 };

/* Cada golpe: fr = [[tempo, deslocamentos-da-guarda], ...]; active = janela em que o golpe pode acertar;
   cancel = janela em que um novo botão encadeia o combo; lunge = [t0,t1,distância] avanço do corpo. */
const MOVES = {
  jab: { name: 'Jab', type: 'punch', limb: 'handL', cost: 4, dur: 0.34, active: [0.10, 0.19], cancel: [0.15, 0.30], dmg: 4.5, stun: 0.30, bstun: 0.16, push: 1.6, r: 0.12,
    lunge: [0.03, 0.12, 0.22], freeChain: true, snd: 'whoosh', hit: 'punch',
    chain: { jab: 'jab', heavyPunch: 'cross', kick: 'lowKick', heavyKick: 'highKick' },
    fr: [[0.05, { lSx: 0.95, lEl: 1.4, lSz: 0.2, sRy: -0.2 }], [0.11, X_JAB], [0.19, X_JAB], [0.34, {}]] },
  cross: { name: 'Direto', type: 'punch', limb: 'handR', cost: 7, dur: 0.50, active: [0.15, 0.25], cancel: [0.23, 0.42], dmg: 8, stun: 0.38, bstun: 0.22, push: 3.2, r: 0.125,
    lunge: [0.05, 0.16, 0.34], snd: 'whoosh', hit: 'punch',
    chain: { jab: 'hook', heavyPunch: 'uppercut', kick: 'lowKick', heavyKick: 'highKick' },
    fr: [[0.07, { rSx: 0.8, rEl: 1.8, sRy: -0.3, hRy: -0.35 }], [0.15, X_CROSS], [0.25, X_CROSS], [0.5, {}]] },
  hook: { name: 'Gancho', type: 'punch', limb: 'handL', cost: 7, dur: 0.48, active: [0.17, 0.27], cancel: [0.25, 0.40], dmg: 7.5, stun: 0.38, bstun: 0.22, push: 3.0, r: 0.13,
    lunge: [0.06, 0.18, 0.32], snd: 'whoosh', hit: 'punch',
    chain: { jab: 'jab', heavyPunch: 'uppercut', kick: 'lowKick', heavyKick: 'highKick' },
    fr: [[0.08, { lSz: 1.35, lSy: -0.2, lSx: 0.2, lEl: 1.7, sRy: -0.3, hRy: -0.3 }], [0.17, X_HOOK], [0.27, X_HOOK], [0.48, {}]] },
  uppercut: { name: 'Uppercut', type: 'punch', limb: 'handR', cost: 9, dur: 0.54, active: [0.18, 0.28], cancel: [0.28, 0.42], dmg: 9.5, stun: 0.45, bstun: 0.26, push: 3.6, r: 0.13, knock: true,
    lunge: [0.06, 0.18, 0.32], snd: 'whoosh', hit: 'punch',
    chain: { heavyKick: 'highKick', kick: 'lowKick', jab: 'jab' },
    fr: [[0.09, { y: -0.16, sRx: 0.3, rSx: 0.35, rEl: 1.7, sRy: -0.2 }], [0.18, X_UPPER], [0.28, X_UPPER], [0.54, {}]] },
  frontKick: { name: 'Chute frontal', type: 'kick', limb: 'footL', cost: 7, dur: 0.58, active: [0.19, 0.29], cancel: [0.30, 0.44], dmg: 5.5, stun: 0.32, bstun: 0.2, push: 5.2, r: 0.13,
    lunge: [0.06, 0.2, 0.18], snd: 'whoosh', hit: 'kick',
    chain: { heavyPunch: 'cross', jab: 'jab' },
    fr: [[0.10, { lPl: 0, lHx: 1.1, lK: 1.9, sRx: -0.1 }], [0.19, X_FRONT], [0.29, X_FRONT], [0.58, {}]] },
  lowKick: { name: 'Chute baixo', type: 'kick', limb: 'footR', cost: 7, dur: 0.56, active: [0.21, 0.32], cancel: [0.30, 0.44], dmg: 6, stun: 0.32, bstun: 0.2, push: 2.2, r: 0.14, legHit: true,
    lunge: [0.08, 0.22, 0.2], snd: 'whoosh', hit: 'kick',
    chain: { heavyKick: 'highKick', heavyPunch: 'cross', jab: 'jab' },
    fr: [[0.12, { rPl: 0, rHx: -0.5, rHz: 0.45, rK: 0.6, hRy: -0.5, sRy: -0.4, sRz: -0.1 }], [0.22, X_LOW], [0.32, X_LOW], [0.56, {}]] },
  highKick: { name: 'Chute alto', type: 'kick', limb: 'footR', cost: 12, dur: 0.70, active: [0.27, 0.37], cancel: [0.4, 0.4], dmg: 11, stun: 0.5, bstun: 0.28, push: 4.6, r: 0.14, knock: true,
    lunge: [0.1, 0.26, 0.2], snd: 'whoosh', hit: 'kick', chain: {},
    fr: [[0.14, { rPl: 0, rHx: 0.0, rHz: 1.2, rK: 1.5, hRy: -0.5, sRz: -0.3, sRy: -0.3 }], [0.27, X_HIGH], [0.37, X_HIGH], [0.7, {}]] },
  knee: { name: 'Joelhada', type: 'knee', limb: 'kneeR', cost: 9, dur: 0.52, active: [0.16, 0.27], cancel: [0.26, 0.40], dmg: 9, stun: 0.42, bstun: 0.24, push: 2.6, r: 0.15,
    lunge: [0.04, 0.16, 0.3], snd: 'whoosh', hit: 'kick',
    chain: { jab: 'jab', heavyPunch: 'cross' },
    fr: [[0.08, { rPl: 0, rHx: 0.6, rK: 1.7, sRx: 0.2 }], [0.17, X_KNEE], [0.27, X_KNEE], [0.52, {}]] },
};

/* Pré-processa os quadros (poses completas) */
Object.keys(MOVES).forEach((id) => {
  const mv = MOVES[id]; mv.id = id;
  mv.frames = [{ t: 0, p: P() }].concat(mv.fr.map((f) => ({ t: f[0], p: P(f[1]) })));
});

const _tmpPose = {};
function sampleFrames(frames, t, out) {
  out = out || {};
  if (t >= frames[frames.length - 1].t) return poseLerp(frames[frames.length - 1].p, frames[frames.length - 1].p, 0, out);
  let i = 0;
  while (i < frames.length - 2 && t >= frames[i + 1].t) i++;
  const a = frames[i], b = frames[i + 1];
  return poseLerp(a.p, b.p, U.smooth((t - a.t) / (b.t - a.t)), out);
}

/* Qual golpe um botão aciona (botões de ataque) */
const ATTACK_ACTIONS = ['jab', 'heavyPunch', 'kick', 'heavyKick'];
function pickMove(action, forward) {
  switch (action) {
    case 'jab': return 'jab';
    case 'heavyPunch': return 'cross';
    case 'kick': return forward ? 'frontKick' : 'lowKick';
    case 'heavyKick': return forward ? 'knee' : 'highKick';
    default: return null;
  }
}

/* Combos de referência mostrados no treinamento */
const COMBO_LIST = [
  ['jab', 'jab', 'heavyPunch'], ['jab', 'heavyPunch', 'jab'], ['jab', 'heavyPunch', 'jab', 'heavyPunch'],
  ['heavyPunch', 'jab', 'heavyPunch'], ['jab', 'kick', 'heavyKick'], ['kick', 'heavyKick'], ['heavyPunch', 'heavyKick'],
];
