/* =====================================================================
   MÓDULO 50 — Arenas 3D (procedurais): Academia, Arena profissional, Ringue clandestino
   buildArena(id, shadows) -> { group, bounds, clamp(pos, r), update(dt, t), dispose(), bg, fog }
   ===================================================================== */

const ARENAS = [
  { id: 'academia', name: 'Academia de luta', desc: 'Tatame, sacos de pancada e espelhos.', c1: '#3a4a66', c2: '#d9a441' },
  { id: 'arena', name: 'Arena profissional', desc: 'Ringue, torcida e luzes de transmissão.', c1: '#1c2a6b', c2: '#ff3b4a' },
  { id: 'clandestino', name: 'Ringue clandestino', desc: 'Galpão, jaula de arame e fogo nos barris.', c1: '#3b2a22', c2: '#ff7a1a' },
];

function rtex(w, h, draw, repX, repY) {
  const t = canvasTex(w, h, draw);
  if (repX) { t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(repX, repY || repX); }
  return t;
}
function textBanner(text, w, h, bg, fg, font, sub) {
  return rtex(w, h, (g) => {
    g.fillStyle = bg; g.fillRect(0, 0, w, h);
    g.fillStyle = fg; g.font = font; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(text, w / 2, h / 2);
    if (sub) { g.font = '600 ' + Math.round(h * 0.12) + 'px sans-serif'; g.fillText(sub, w / 2, h * 0.82); }
  });
}

function buildArena(id, Q) {
  const T = THREE, group = new T.Group();
  const M = (c, r, m) => mkMat({ color: c, roughness: r === undefined ? 0.8 : r, metalness: m || 0 });
  const B = (c) => new T.MeshBasicMaterial(typeof c === 'object' && c.map ? c : { color: c });
  const add = (g, mat, x, y, z, shadow) => { const o = new T.Mesh(g, mat); o.position.set(x || 0, y || 0, z || 0); if (shadow) o.castShadow = true; group.add(o); return o; };
  const box = (w, h, d, mat, x, y, z, sh) => add(new T.BoxGeometry(w, h, d), mat, x, y, z, sh);
  const cyl = (rt, rb, h, mat, x, y, z, seg, sh) => add(new T.CylinderGeometry(rt, rb, h, seg || 16), mat, x, y, z, sh);
  const plane = (w, h, mat, x, y, z, rx, ry) => { const o = add(new T.PlaneGeometry(w, h), mat, x, y, z); o.rotation.x = rx || 0; o.rotation.y = ry || 0; return o; };
  const upd = []; const lights = [];
  const sun = (x, y, z, int, col) => {
    const l = new T.DirectionalLight(col || 0xffffff, int); l.position.set(x, y, z); l.target.position.set(0, 0, 0);
    if (Q.shadows) { l.castShadow = true; l.shadow.mapSize.set(Q.smap, Q.smap); const c = l.shadow.camera; c.left = -6; c.right = 6; c.top = 6; c.bottom = -6; c.near = 1; c.far = 30; l.shadow.bias = -0.0006; }
    group.add(l); group.add(l.target); lights.push(l); return l;
  };
  const point = (x, y, z, col, int, dist) => { if (!Q.lights) return { intensity: 0 }; const l = new T.PointLight(col, int, dist); l.position.set(x, y, z); group.add(l); lights.push(l); return l; };
  const crowd = (rows, r0, dr, y0, dy, gap, palette, skins, dark, ground) => {
    const pos = []; gap = gap / Q.crowd;
    for (let r = 0; r < rows; r++) { const rad = r0 + r * dr, n = Math.floor(2 * Math.PI * rad / gap); for (let i = 0; i < n; i++) { const a = i / n * Math.PI * 2 + (r % 2) * 0.05; pos.push([Math.cos(a) * rad, y0 + r * dy, Math.sin(a) * rad, a]); } }
    const bodies = new T.InstancedMesh(new T.BoxGeometry(0.46, 0.62, 0.34), M('#ffffff', 0.9), pos.length);
    const heads = new T.InstancedMesh(new T.SphereGeometry(0.15, 8, 6), M('#ffffff', 0.8), pos.length);
    const m4 = new T.Matrix4(), col = new T.Color();
    pos.forEach((p, i) => {
      bodies.setMatrixAt(i, m4.makeRotationY(-p[3] - Math.PI / 2).setPosition(p[0], p[1] + 0.4, p[2]));
      heads.setMatrixAt(i, m4.makeRotationY(0).setPosition(p[0], p[1] + 0.9, p[2]));
      bodies.setColorAt(i, col.set(dark ? U.pick(['#1a1a1f', '#262630', '#2f2a24', '#1f2430']) : U.pick(palette)));
      heads.setColorAt(i, col.set(U.pick(skins)));
    });
    bodies.frustumCulled = false; heads.frustumCulled = false; group.add(bodies); group.add(heads);
    return { pos, bodies, heads, m4 };
  };

  let bounds, bg = 0x10131c, fogC = 0x10131c, fogN = 14, fogF = 40;

  if (id === 'academia') {
    bg = 0x1b2030; fogC = 0x1b2030; fogN = 18; fogF = 45;
    const wood = rtex(256, 256, (g) => { for (let i = 0; i < 8; i++) { g.fillStyle = i % 2 ? '#8a5f3a' : '#7d5532'; g.fillRect(0, i * 32, 256, 32); g.fillStyle = 'rgba(0,0,0,.25)'; g.fillRect(0, i * 32, 256, 2); } for (let i = 0; i < 240; i++) { g.fillStyle = 'rgba(0,0,0,.06)'; g.fillRect(Math.random() * 256, Math.random() * 256, 30, 1); } }, 8, 8);
    const floor = plane(30, 30, M('#ffffff', 0.7), 0, 0, 0, -Math.PI / 2); floor.material.map = wood; floor.receiveShadow = true;
    const mat = rtex(512, 512, (g) => { g.fillStyle = '#2a3f6b'; g.fillRect(0, 0, 512, 512); g.fillStyle = '#c0392b'; g.fillRect(16, 16, 480, 480); g.fillStyle = '#e8dcc0'; g.fillRect(28, 28, 456, 456);
      g.strokeStyle = 'rgba(0,0,0,.18)'; g.lineWidth = 3; for (let i = 1; i < 4; i++) { g.beginPath(); g.moveTo(28 + i * 114, 28); g.lineTo(28 + i * 114, 484); g.moveTo(28, 28 + i * 114); g.lineTo(484, 28 + i * 114); g.stroke(); }
      g.strokeStyle = '#c0392b'; g.lineWidth = 8; g.beginPath(); g.arc(256, 256, 120, 0, 7); g.stroke(); g.fillStyle = '#c0392b'; g.font = '700 38px sans-serif'; g.textAlign = 'center'; g.fillText('FU', 256, 270); });
    const tat = plane(8.4, 8.4, M('#ffffff', 0.9), 0, 0.012, 0, -Math.PI / 2); tat.material.map = mat; tat.receiveShadow = true;
    const wallM = M('#3a4254', 0.9), trimM = M('#d9a441', 0.6);
    [[0, -12, 0], [0, 12, Math.PI], [-12, 0, Math.PI / 2], [12, 0, -Math.PI / 2]].forEach(([x, z, ry]) => {
      plane(24, 7, wallM, x, 3.5, z, 0, ry); const tr = box(24, 0.25, 0.25, trimM, x, 1.2, z); tr.rotation.y = ry; tr.position.x = x * 0.995; tr.position.z = z * 0.995;
    });
    // espelhos (parede dos fundos) e quadros
    const mirror = M('#9fb4cf', 0.08, 0.9);
    for (let i = -3; i <= 3; i++) { const m = box(2.6, 2.6, 0.06, mirror, i * 3, 2.6, -11.9); m.material = mirror; box(2.7, 2.7, 0.04, trimM, i * 3, 2.6, -11.93); }
    const banner = textBanner('FIGHTERS UNIVERSE', 512, 128, '#12151e', '#d9a441', '700 56px sans-serif', 'ACADEMIA DE LUTA');
    plane(6, 1.5, B({ map: banner }), 0, 5.6, 11.9, 0, Math.PI); plane(6, 1.5, B({ map: banner }), -11.9, 5.6, 0, 0, Math.PI / 2);
    // sacos de pancada
    [[-8, -6], [-5.5, -9], [8, -7], [9, 2]].forEach(([x, z]) => { cyl(0.012, 0.012, 3, M('#888', 0.4, 0.8), x, 5, z, 6); const s = cyl(0.3, 0.3, 1.3, M('#b3321f', 0.7), x, 2.1, z, 18, true); box(0.06, 0.06, 0.06, M('#222'), x, 6.5, z); });
    // pesos, bancos, caixotes
    box(3, 0.9, 0.5, M('#2b2f3a', 0.5, 0.4), 9, 0.45, 8, true); for (let i = 0; i < 5; i++) cyl(0.18, 0.18, 0.08, M('#111', 0.4, 0.6), 8 + i * 0.5, 0.95, 8, 14);
    box(1.4, 0.45, 0.5, M('#6b4a2b'), -8, 0.22, 7, true); box(1.4, 0.45, 0.5, M('#6b4a2b'), -8, 0.22, 8.2, true);
    for (let i = 0; i < 3; i++) box(1.6, 0.25, 1.1, M(['#c0392b', '#2a3f6b', '#2e8b57'][i], 0.9), 10, 0.13 + i * 0.25, -9, true);
    for (let i = -4; i <= 4; i++) { box(0.9, 0.12, 0.12, M('#fff'), i * 2.6, 6.4, -4); box(0.9, 0.12, 0.12, M('#fff'), i * 2.6, 6.4, 5); }
    const L0 = new T.HemisphereLight(0xdfe8ff, 0x6b4a2b, 0.75); group.add(L0); lights.push(L0);
    sun(4, 11, 6, 0.8, 0xfff2dd); point(-6, 5, 0, 0xffd9a0, 0.45, 18); point(6, 5, 0, 0xcfe0ff, 0.4, 18);
    bounds = { type: 'rect', hx: 3.8, hz: 3.8 };
  }

  if (id === 'arena') {
    bg = 0x05070f; fogC = 0x070a16; fogN = 20; fogF = 60;
    const hall = plane(80, 80, M('#0c0f1a', 0.9), 0, -1.12, 0, -Math.PI / 2); hall.receiveShadow = true;
    const canvas = rtex(512, 512, (g) => { g.fillStyle = '#e9edf5'; g.fillRect(0, 0, 512, 512);
      g.fillStyle = '#d92b3d'; g.fillRect(0, 0, 150, 150); g.fillStyle = '#2f6fe0'; g.fillRect(362, 362, 150, 150);
      g.strokeStyle = '#0d1230'; g.lineWidth = 10; g.strokeRect(14, 14, 484, 484); g.fillStyle = '#0d1230'; g.font = '700 54px sans-serif'; g.textAlign = 'center'; g.fillText('FIGHTERS', 256, 240); g.fillText('UNIVERSE', 256, 300);
      g.strokeStyle = 'rgba(13,18,48,.25)'; g.lineWidth = 3; g.beginPath(); g.arc(256, 256, 150, 0, 7); g.stroke(); });
    box(8.6, 1.1, 8.6, M('#10131f', 0.8), 0, -0.56, 0, false).receiveShadow = true;
    const mat = plane(8.2, 8.2, M('#ffffff', 0.85), 0, 0.01, 0, -Math.PI / 2); mat.material.map = canvas; mat.receiveShadow = true;
    const skirt = textBanner('FIGHTERS UNIVERSE', 512, 64, '#101830', '#ff3b4a', '700 34px sans-serif');
    [[0, 4.32, 0], [0, -4.32, Math.PI], [4.32, 0, Math.PI / 2], [-4.32, 0, -Math.PI / 2]].forEach(([a, b, ry]) => { const p = plane(8.6, 1.0, B({ map: skirt }), ry % Math.PI ? a : a, -0.56, ry % Math.PI ? b : b, 0, 0); p.position.set(Math.abs(a) > 1 ? a : 0, -0.56, Math.abs(b) > 1 ? b : 0); p.rotation.y = ry; });
    const pc = ['#d92b3d', '#2f6fe0', '#e9edf5', '#e9edf5'];
    [[-3.9, -3.9], [3.9, -3.9], [3.9, 3.9], [-3.9, 3.9]].forEach(([x, z], i) => { cyl(0.1, 0.1, 1.5, M('#9aa3b5', 0.3, 0.8), x, 0.75, z, 12, true); box(0.3, 1.0, 0.3, M(pc[i], 0.7), x, 0.8, z); });
    const rc = ['#d92b3d', '#e9edf5', '#2f6fe0'];
    for (let r = 0; r < 3; r++) { const y = 0.5 + r * 0.4, rm = M(rc[r], 0.5);
      [[0, -3.9, 0], [0, 3.9, 0], [-3.9, 0, 1], [3.9, 0, 1]].forEach(([x, z, rot]) => { const c = cyl(0.025, 0.025, 7.8, rm, x, y, z, 8); if (rot) c.rotation.x = Math.PI / 2; else c.rotation.z = Math.PI / 2; }); }
    // arquibancadas + torcida
    for (let r = 0; r < 6; r++) { const rad = 9.5 + r * 1.3, y = -1.1 + r * 0.55; const rg = new T.RingGeometry(rad - 0.7, rad + 0.7, 64); const ring = add(rg, M('#14182a', 0.9), 0, y + 0.3, 0); ring.rotation.x = -Math.PI / 2;
      const ri = add(new T.CylinderGeometry(rad - 0.7, rad - 0.7, 0.6, 64, 1, true), M('#0f1220', 0.9), 0, y, 0); ri.material.side = T.DoubleSide; }
    const cd = crowd(6, 9.7, 1.3, -1.1 + 0.3, 0.55, 0.78, ['#d92b3d', '#2f6fe0', '#e9edf5', '#f2b705', '#18a999', '#8a4fff', '#ff7a1a'], ['#fbe0cc', '#e0ac86', '#c68a62', '#8a5230', '#4a2a17'], false);
    // telão e holofotes
    const scr = textBanner('FIGHTERS UNIVERSE 3D', 512, 256, '#0d1230', '#ff3b4a', '700 54px sans-serif', 'LUTA PELO CINTURÃO');
    [[0, 1], [0, -1], [1, 0], [-1, 0]].forEach(([a, b]) => { const p = plane(5.2, 2.6, B({ map: scr }), a * 2.6, 7.2, b * 2.6, 0, 0); p.rotation.y = Math.atan2(a, b); });
    box(5.6, 0.4, 5.6, M('#0a0c14', 0.5, 0.5), 0, 8.8, 0); box(5.6, 0.3, 5.6, M('#0a0c14'), 0, 5.7, 0);
    [[-6, -6], [6, -6], [6, 6], [-6, 6]].forEach(([x, z], i) => {
      if (Q.lights) { const sp = new T.SpotLight(i % 2 ? 0xbcd2ff : 0xffe0c0, 0.9, 40, 0.5, 0.6); sp.position.set(x, 11, z); sp.target.position.set(0, 0, 0); group.add(sp); group.add(sp.target); lights.push(sp); }
      box(0.5, 0.5, 0.8, M('#111'), x, 11, z);
    });
    const L0 = new T.HemisphereLight(0x8fa0ff, 0x151a30, 0.55); group.add(L0); lights.push(L0);
    sun(3, 12, 5, 0.85, 0xffffff);
    let tt = 0; upd.push((dt) => { tt += dt; if (Math.floor(tt * 6) % 2 === 0) return; for (let i = 0; i < cd.pos.length; i += 3) { const p = cd.pos[i]; cd.heads.setMatrixAt(i, cd.m4.makeRotationY(0).setPosition(p[0], p[1] + 0.9 + Math.abs(Math.sin(tt * 3 + i)) * 0.12, p[2])); } cd.heads.instanceMatrix.needsUpdate = true; });
    bounds = { type: 'rect', hx: 3.6, hz: 3.6 };
  }

  if (id === 'clandestino') {
    bg = 0x0c0907; fogC = 0x120d0a; fogN = 10; fogF = 34;
    const conc = rtex(256, 256, (g) => { g.fillStyle = '#3a3733'; g.fillRect(0, 0, 256, 256); for (let i = 0; i < 700; i++) { g.fillStyle = 'rgba(' + (Math.random() < 0.5 ? '0,0,0' : '255,255,255') + ',' + (Math.random() * 0.07) + ')'; g.fillRect(Math.random() * 256, Math.random() * 256, 1 + Math.random() * 14, 1 + Math.random() * 4); } for (let i = 0; i < 8; i++) { g.fillStyle = 'rgba(40,10,10,.25)'; g.beginPath(); g.arc(Math.random() * 256, Math.random() * 256, 10 + Math.random() * 24, 0, 7); g.fill(); } }, 8, 8);
    const floor = plane(60, 60, M('#ffffff', 0.95), 0, 0, 0, -Math.PI / 2); floor.material.map = conc; floor.receiveShadow = true;
    const ringTex = rtex(512, 512, (g) => { g.clearRect(0, 0, 512, 512); g.strokeStyle = '#c0392b'; g.lineWidth = 14; g.beginPath(); g.arc(256, 256, 236, 0, 7); g.stroke(); g.lineWidth = 6; g.beginPath(); g.arc(256, 256, 130, 0, 7); g.stroke(); g.fillStyle = '#c0392b'; g.font = '700 70px sans-serif'; g.textAlign = 'center'; g.fillText('SEM', 256, 250); g.fillText('REGRAS', 256, 320); });
    const disc = plane(8.6, 8.6, new T.MeshBasicMaterial({ map: ringTex, transparent: true, depthWrite: false }), 0, 0.015, 0, -Math.PI / 2);
    const brick = rtex(256, 128, (g) => { g.fillStyle = '#2b1d17'; g.fillRect(0, 0, 256, 128); for (let r = 0; r < 8; r++) for (let c = -1; c < 8; c++) { g.fillStyle = 'hsl(' + (12 + Math.random() * 10) + ',' + (30 + Math.random() * 15) + '%,' + (20 + Math.random() * 10) + '%)'; g.fillRect(c * 32 + (r % 2) * 16 + 1, r * 16 + 1, 30, 14); } g.fillStyle = '#e8d44a'; g.globalAlpha = 0.5; g.font = '700 28px sans-serif'; g.fillText('FU', 190, 90); g.globalAlpha = 1; }, 10, 3);
    const wall = add(new T.CylinderGeometry(13, 13, 7, 32, 1, true), M('#ffffff', 0.95), 0, 3.5, 0); wall.material.map = brick; wall.material.side = T.DoubleSide;
    box(26, 0.4, 0.4, M('#1a1a1a', 0.5, 0.7), 0, 6.9, 0); box(0.4, 0.4, 26, M('#1a1a1a', 0.5, 0.7), 0, 6.9, 0);
    for (let i = -2; i <= 2; i++) { cyl(0.18, 0.18, 26, M('#4a4036', 0.5, 0.7), 0, 6.2, i * 4, 10).rotation.z = Math.PI / 2; }
    // jaula octogonal
    const fenceT = rtex(64, 64, (g) => { g.clearRect(0, 0, 64, 64); g.strokeStyle = '#9aa0a8'; g.lineWidth = 3; for (let i = -64; i < 128; i += 16) { g.beginPath(); g.moveTo(i, 0); g.lineTo(i + 64, 64); g.moveTo(i + 64, 0); g.lineTo(i, 64); g.stroke(); } }, 6, 2);
    const fm = new T.MeshBasicMaterial({ map: fenceT, transparent: true, alphaTest: 0.3, side: T.DoubleSide });
    const R = 4.4, side = 2 * R * Math.sin(Math.PI / 8);
    for (let i = 0; i < 8; i++) { const a = i / 8 * Math.PI * 2 + Math.PI / 8; const x = Math.cos(a) * R, z = Math.sin(a) * R; const p = plane(side, 2.4, fm, x, 1.2, z, 0, 0); p.rotation.y = -a + Math.PI / 2;
      const a2 = i / 8 * Math.PI * 2; cyl(0.07, 0.07, 2.6, M('#555b63', 0.4, 0.8), Math.cos(a2) * R / Math.cos(Math.PI / 8) * 1.0, 1.3, Math.sin(a2) * R / Math.cos(Math.PI / 8), 8, true); }
    const topRing = add(new T.TorusGeometry(R / Math.cos(Math.PI / 8) * 0.99, 0.05, 6, 8), M('#555b63', 0.4, 0.8), 0, 2.4, 0); topRing.rotation.x = Math.PI / 2; topRing.rotation.z = Math.PI / 8;
    // barris com fogo, lâmpadas
    const fires = [];
    [[7, 0.5], [-7, 3], [2, -7.5], [-3, 7.5]].forEach(([x, z], i) => { cyl(0.45, 0.4, 1.1, M(['#6b3a22', '#2d4a5a', '#5a2222', '#3a3a3a'][i], 0.6, 0.5), x, 0.55, z, 14, true); const f = add(new T.ConeGeometry(0.34, 0.9, 8), new T.MeshBasicMaterial({ color: 0xff8a2a, transparent: true, opacity: 0.85 }), x, 1.5, z); const l = point(x, 1.8, z, 0xff7a1a, 1.2, 12); fires.push({ f, l, ph: Math.random() * 9 }); });
    const bulbs = [];
    [[-3, -3], [3, -3], [0, 3.5]].forEach(([x, z]) => { cyl(0.01, 0.01, 2.2, M('#111'), x, 5.8, z, 4); const b = add(new T.SphereGeometry(0.16, 10, 8), new T.MeshBasicMaterial({ color: 0xffe2a0 }), x, 4.6, z); const l = point(x, 4.4, z, 0xffd9a0, 0.65, 16); bulbs.push({ b, l, ph: Math.random() * 9 }); });
    const cd = crowd(4, 6.2, 1.1, 0, 0.0, 0.9, [], ['#6b3d22', '#c68a62', '#a8693f'], true);
    const L0 = new T.HemisphereLight(0xb08a6a, 0x120c08, 0.55); group.add(L0); lights.push(L0);
    sun(2, 10, 3, 0.55, 0xffd9b0);
    let tt = 0; upd.push((dt) => { tt += dt; fires.forEach((o) => { const k = 0.85 + Math.sin(tt * 18 + o.ph) * 0.1 + Math.sin(tt * 7.3 + o.ph) * 0.1; o.l.intensity = 1.2 * k; o.f.scale.set(1, k, 1); }); bulbs.forEach((o) => { o.l.intensity = 0.65 * (0.9 + Math.sin(tt * 11 + o.ph) * 0.06 + (Math.random() < 0.01 ? -0.4 : 0)); }); });
    bounds = { type: 'circle', r: 3.9 };
  }

  const arena = {
    id, group, bounds, bg, fogC, fogN, fogF, lights,
    clamp(p, r) {
      const b = bounds;
      if (b.type === 'rect') { p.x = U.clamp(p.x, -b.hx + r, b.hx - r); p.z = U.clamp(p.z, -b.hz + r, b.hz - r); }
      else { const d = Math.hypot(p.x, p.z), m = b.r - r; if (d > m) { p.x *= m / d; p.z *= m / d; } }
    },
    update(dt) { for (let i = 0; i < upd.length; i++) upd[i](dt); },
    dispose() { group.traverse((o) => { if (o.geometry) o.geometry.dispose(); if (o.material) { if (o.material.map) o.material.map.dispose(); o.material.dispose(); } }); },
  };
  return arena;
}
