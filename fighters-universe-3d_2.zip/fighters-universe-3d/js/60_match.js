/* =====================================================================
   MÓDULO 60 — Luta: efeitos (FX), câmera dinâmica, rounds, regras de vitória
   ===================================================================== */

class FX {
  constructor(scene) {
    this.scene = scene; this.parts = []; this.flashes = [];
    this.geo = new THREE.SphereGeometry(0.035, 6, 5);
    const COL = { hit: 0xffe9a0, crit: 0xff4a2a, block: 0x7fd6ff, ko: 0xffffff };
    this.mats = {}; this.fmats = {}; this.fgeo = new THREE.SphereGeometry(1, 10, 8);
    Object.keys(COL).forEach((k) => { this.mats[k] = new THREE.MeshBasicMaterial({ color: COL[k] }); this.fmats[k] = new THREE.MeshBasicMaterial({ color: COL[k], transparent: true, opacity: 0.8 }); });
    for (let i = 0; i < 60; i++) { const m = new THREE.Mesh(this.geo, this.mats.hit); m.visible = false; scene.add(m); this.parts.push({ m, vx: 0, vy: 0, vz: 0, life: 0, max: 1 }); }
    for (let i = 0; i < 6; i++) { const m = new THREE.Mesh(this.fgeo, this.fmats.hit); m.visible = false; scene.add(m); this.flashes.push({ m, life: 0, max: 0.14, size: 0.3 }); }
  }
  burst(x, y, z, kind, n, power) {
    const mat = this.mats[kind] || this.mats.hit; let c = 0;
    for (const p of this.parts) {
      if (p.life > 0) continue;
      p.m.material = mat; p.m.visible = true; p.m.position.set(x, y, z);
      const a = Math.random() * 6.28, e = Math.random() * 2 - 0.6, s = power * (0.5 + Math.random());
      p.vx = Math.cos(a) * s; p.vy = e * s + 1; p.vz = Math.sin(a) * s; p.life = p.max = 0.25 + Math.random() * 0.25;
      if (++c >= n) break;
    }
    const f = this.flashes.find((q) => q.life <= 0);
    if (f) { f.m.material = this.fmats[kind] || this.fmats.hit; f.m.visible = true; f.m.position.set(x, y, z); f.life = f.max = 0.14; f.size = 0.12 + power * 0.05; }
  }
  update(dt) {
    for (const p of this.parts) {
      if (p.life <= 0) continue; p.life -= dt;
      if (p.life <= 0) { p.m.visible = false; continue; }
      p.vy -= 9 * dt; p.m.position.x += p.vx * dt; p.m.position.y += p.vy * dt; p.m.position.z += p.vz * dt;
      const s = p.life / p.max; p.m.scale.set(s, s, s);
    }
    for (const f of this.flashes) {
      if (f.life <= 0) continue; f.life -= dt;
      if (f.life <= 0) { f.m.visible = false; continue; }
      const k = 1 - f.life / f.max; const s = f.size * (0.4 + k); f.m.scale.set(s, s, s); f.fm = f.m.material; f.m.material.opacity = 0.8 * (1 - k);
    }
  }
  dispose() { this.geo.dispose(); this.fgeo.dispose(); Object.values(this.mats).forEach((m) => m.dispose()); Object.values(this.fmats).forEach((m) => m.dispose()); }
}

const NOOP_HUD = new Proxy({}, { get: () => () => {} });

class Match {
  /* opts: p1, p2 (cfg), arena, ai ('facil'..'mestre' | 'parado' | 'defende'), training, rounds (1|3), roundTime, hud, renderer, onEnd(result), aspect */
  constructor(o) {
    this.o = o; this.hud = o.hud || NOOP_HUD; this.training = !!o.training;
    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(38, o.aspect || 16 / 9, 0.1, 120);
    this.arena = buildArena(o.arena, Quality.cfg());
    this.scene.background = new THREE.Color(this.arena.bg); this.scene.fog = new THREE.Fog(this.arena.fogC, this.arena.fogN, this.arena.fogF);
    this.scene.add(this.arena.group);
    const hooks = { sound: (n, f) => { if (n === 'step' && f !== this.f1) return; Sound.play(n); }, thrown: (a, v, r) => this.onThrown(a, v, r) };
    this.f1 = new Fighter(o.p1, { hooks }); this.f2 = new Fighter(o.p2, { hooks });
    this.scene.add(this.f1.root); this.scene.add(this.f2.root);
    this.fx = new FX(this.scene);
    this.camF = { x: 0, z: -1 }; this.camAng = Math.PI; this.shake = 0; this.hitstop = 0; this.ts = 1;
    this.ctl1 = new PlayerController(() => this.camF);
    this.ctl2 = new AIController(o.ai || 'normal', this.f2);
    this.roundsToWin = this.training ? 99 : Math.ceil((o.rounds || 3) / 2);
    this.roundTime = this.training ? 0 : (o.roundTime || 60);
    this.wins = [0, 0]; this.round = 0; this.history = []; this.totalTime = 0; this.ended = false; this.finished = false;
    this.hud.setup && this.hud.setup(this);
    this.startRound();
  }

  startRound() {
    this.round++; this.phase = 'intro'; this.pt = 0; this.timeLeft = this.roundTime; this.loser = null; this.winnerSide = 0;
    const sx = this.arena.bounds.type === 'rect' ? 1.1 : 1.1;
    this.f1.reset(-sx, 0, Math.PI / 2); this.f2.reset(sx, 0, -Math.PI / 2);
    this.f1.canAct = this.f2.canAct = false; this.ts = 1; this.camIntro = true;
    this.fightStarted = false;
    this.hud.banner && this.hud.banner(this.training ? 'TREINAMENTO' : 'ROUND ' + this.round, this.training ? '' : (this.wins[0] + this.wins[1] === 0 ? '' : this.wins[0] + ' x ' + this.wins[1]), 'round', 1500);
  }

  /* ----------------------------- laço principal ----------------------------- */
  update(rdt) {
    if (this.finished) return;
    let dt = rdt;
    if (this.hitstop > 0) { this.hitstop -= rdt; dt = rdt * 0.04; }
    dt *= this.ts;
    this.pt += rdt;
    const f1 = this.f1, f2 = this.f2;

    // fases
    if (this.phase === 'intro') {
      if (!this.fightStarted && this.pt >= 1.5) { this.fightStarted = true; this.hud.banner && this.hud.banner('LUTAR!', '', 'fight', 800); Sound.play('bell'); }
      if (this.pt >= 1.9) { this.phase = 'fight'; this.pt = 0; f1.canAct = f2.canAct = true; this.camIntro = false; }
    } else if (this.phase === 'fight') {
      if (!this.training) {
        this.timeLeft -= rdt; this.totalTime += rdt;
        if (this.timeLeft <= 0) { this.timeLeft = 0; this.endRound('time'); }
      } else {
        this.ctl2 && (f2.hp = Math.max(f2.hp, 1)); if (f2.state === 'idle' && f2.hp < f2.maxHp) f2.hp = Math.min(f2.maxHp, f2.hp + 12 * rdt);
        f1.hp = Math.min(f1.maxHp, f1.hp + 6 * rdt); f2.st = Math.min(f2.maxSt, f2.st + 20 * rdt);
      }
    } else if (this.phase === 'ko' || this.phase === 'time') {
      if (this.pt > 1.4) this.ts = 1;
      if (this.pt >= 3.0) this.finishRound();
    } else if (this.phase === 'roundEnd') {
      if (this.pt >= 2.6) { if (this.wins[this.winnerSide - 1] >= this.roundsToWin) this.endMatch(); else this.startRound(); }
    } else if (this.phase === 'matchEnd') {
      if (this.pt >= 3.4 && !this.finished) { this.finished = true; this.o.onEnd && this.o.onEnd(this.result()); }
    }

    // entradas
    const i1 = this.ctl1.intent(dt, f2, f1), i2 = this.ctl2.intent(dt, f1);
    if (this.phase !== 'fight') { i1.press = []; i1.mx = i1.mz = 0; i1.block = false; i2.press = []; i2.mx = i2.mz = 0; i2.block = false; }
    f1.update(dt, i1, f2); f2.update(dt, i2, f1);
    this.bodies(dt);
    f1.applyVisual(); f2.applyVisual();
    if (this.phase === 'fight' || this.phase === 'ko') {
      const r1 = f1.strikeCheck(f2), r2 = f2.strikeCheck(f1);
      if (r1) this.onStrike(r1); if (r2) this.onStrike(r2);
    }
    this.fx.update(rdt); this.arena.update(rdt);
    this.updateCamera(rdt);
    if (this.shake > 0) this.shake = Math.max(0, this.shake - rdt * 2.2);
    this.hud.update && this.hud.update(this);
  }

  bodies(dt) {
    const a = this.f1, b = this.f2;
    const locked = (f) => f.state === 'grabbed' || f.state === 'throw';
    if (!(locked(a) || locked(b))) {
      const dx = b.pos.x - a.pos.x, dz = b.pos.z - a.pos.z, d = Math.hypot(dx, dz) || 0.001, min = 0.64 * (a.S + b.S) / 2;
      if (d < min) { const k = (min - d) / 2 / d; a.pos.x -= dx * k; a.pos.z -= dz * k; b.pos.x += dx * k; b.pos.z += dz * k; }
    }
    if (!locked(a)) this.arena.clamp(a.pos, 0.3); if (!locked(b)) this.arena.clamp(b.pos, 0.3);
    if (locked(a) || locked(b)) { const att = locked(a) && a.state === 'throw' ? a : b, v = att.victim; if (v) this.arena.clamp(v.pos, 0.2); }
  }

  /* ----------------------------- eventos de golpe ----------------------------- */
  onStrike(r) {
    const att = r.att, def = r.def, mv = r.move;
    const k = r.kind;
    if (k === 'block') { this.fx.burst(r.x, r.y, r.z, 'block', 6, 2.2); Sound.play('block'); this.shake = Math.max(this.shake, 0.25); this.hitstop = 0.03; return; }
    if (k === 'guardbreak') { this.fx.burst(r.x, r.y, r.z, 'crit', 14, 4); Sound.play('slam', 0.6); this.shake = 0.9; this.hitstop = 0.09; this.hud.popup && this.hud.popup(this.proj(r.x, r.y, r.z), 'GUARDA QUEBRADA', 'crit'); return; }
    const big = mv.dmg >= 8;
    this.fx.burst(r.x, r.y, r.z, r.crit ? 'crit' : 'hit', r.crit ? 16 : big ? 12 : 8, r.crit ? 4.5 : big ? 3.4 : 2.4);
    Sound.play(mv.hit === 'kick' ? 'kick' : 'punch', big ? 1.2 : 0.9);
    this.shake = Math.max(this.shake, big ? 0.7 : 0.4); this.hitstop = Math.min(0.1, 0.03 + r.dmg * 0.0045);
    const pr = this.proj(r.x, r.y, r.z);
    this.hud.popup && this.hud.popup(pr, (r.crit ? 'CRÍTICO ' : '') + Math.round(r.dmg), r.crit ? 'crit' : (def === this.f1 ? 'taken' : 'hit'));
    if (att === this.f1 && att.combo >= 2) this.hud.combo && this.hud.combo(att.combo);
    if (k === 'ko') this.onKO(def, att);
  }
  onThrown(att, v, r) {
    this.fx.burst(v.pos.x, 0.2, v.pos.z, 'ko', 14, 3.5); Sound.play('slam'); this.shake = 1; this.hitstop = 0.08;
    this.hud.popup && this.hud.popup(this.proj(v.pos.x, 1.2, v.pos.z), 'QUEDA ' + Math.round(r.dmg), v === this.f1 ? 'taken' : 'crit');
    if (v.state === 'ko') this.onKO(v, att);
  }
  onKO(def, att) {
    if (this.training) { def.hp = 1; return; }
    if (this.phase === 'ko') return;
    this.loser = def; this.winnerSide = def === this.f1 ? 2 : 1; this.endRound('ko');
    this.ts = 0.28; Sound.play('ko'); this.shake = 1.2;
    this.fx.burst(def.pos.x, 1.2, def.pos.z, 'ko', 20, 4);
  }
  endRound(kind) {
    if (this.phase === 'ko' || this.phase === 'time' || this.phase === 'roundEnd') return;
    this.phase = kind === 'ko' ? 'ko' : 'time'; this.pt = 0; this.f1.canAct = this.f2.canAct = false;
    if (kind === 'time') {
      const a = this.f1.hp / this.f1.maxHp, b = this.f2.hp / this.f2.maxHp;
      this.winnerSide = a > b ? 1 : b > a ? 2 : (this.f1.stat.dmg >= this.f2.stat.dmg ? 1 : 2);
      this.hud.banner && this.hud.banner('FIM DO TEMPO', '', 'ko', 2500); Sound.play('bell');
    } else this.hud.banner && this.hud.banner('K.O.!', '', 'ko', 3000);
    this.ko = kind === 'ko';
  }
  finishRound() {
    const w = this.winnerSide === 1 ? this.f1 : this.f2; w.winning = true; w.canAct = false;
    this.wins[this.winnerSide - 1]++; this.history.push({ winner: this.winnerSide, ko: this.ko });
    this.phase = 'roundEnd'; this.pt = 0; this.ts = 1;
    const matchOver = this.wins[this.winnerSide - 1] >= this.roundsToWin;
    if (this.winnerSide === 1) Sound.play(matchOver ? 'win' : 'select'); else if (matchOver) Sound.play('lose');
    this.hud.banner && this.hud.banner(matchOver ? (this.winnerSide === 1 ? 'VITÓRIA!' : 'DERROTA') : (this.winnerSide === 1 ? 'ROUND SEU' : 'ROUND DO ADVERSÁRIO'), matchOver ? w.name : this.wins[0] + ' x ' + this.wins[1], this.winnerSide === 1 ? 'win' : 'lose', 2400);
  }
  endMatch() { this.phase = 'matchEnd'; this.pt = 0; }
  result() {
    const s = (f) => ({ hits: f.stat.hits, tried: f.stat.tried, dmg: Math.round(f.stat.dmg), maxCombo: f.stat.maxCombo, blocked: f.stat.blocked, throws: f.stat.throws });
    return { winner: this.wins[0] > this.wins[1] ? 1 : 2, wins: this.wins.slice(), history: this.history, p1: s(this.f1), p2: s(this.f2), time: Math.round(this.totalTime), flawless: this.wins[1] === 0 };
  }

  /* ----------------------------- câmera ----------------------------- */
  proj(x, y, z) {
    const v = new THREE.Vector3(x, y, z).project(this.camera);
    const W = (this.o.width && this.o.width()) || 1280, H = (this.o.height && this.o.height()) || 720;
    return { x: (v.x * 0.5 + 0.5) * W, y: (-v.y * 0.5 + 0.5) * H };
  }
  updateCamera(dt) {
    const a = this.f1.pos, b = this.f2.pos, cam = this.camera;
    const mx = (a.x + b.x) / 2, mz = (a.z + b.z) / 2;
    let dx = b.x - a.x, dz = b.z - a.z; const dist = Math.hypot(dx, dz) || 1; dx /= dist; dz /= dist;
    let ang = Math.atan2(dz, -dx) + 0.26;            // câmera de lado (P1 à esquerda da tela)
    const vf = cam.fov * Math.PI / 180, hf = 2 * Math.atan(Math.tan(vf / 2) * cam.aspect);
    let D = Math.max(4.2, (dist + 2.3) / 2 / Math.tan(hf / 2)), h = 1.45 + D * 0.1, ty = 1.0, tx = mx, tz = mz;
    if (this.camIntro) { const k = U.smooth(this.pt / 1.9); ang += (1 - k) * 1.5; D = D * (1.25 - 0.25 * k); h = U.lerp(0.9, h, k); }
    if ((this.phase === 'ko' || this.phase === 'time') && this.loser) { const l = this.loser.pos; const k = U.smooth(this.pt / 1.2); tx = U.lerp(mx, l.x, k * 0.6); tz = U.lerp(mz, l.z, k * 0.6); D *= (1 - 0.3 * k); h = U.lerp(h, 1.2, k); ang += 0.4 * k; }
    if (this.phase === 'roundEnd' || this.phase === 'matchEnd') { const w = this.winnerSide === 1 ? this.f1.pos : this.f2.pos; const k = U.smooth(this.pt / 1.0); tx = U.lerp(mx, w.x, k * 0.8); tz = U.lerp(mz, w.z, k * 0.8); D *= (1 - 0.4 * k); h = U.lerp(h, 1.3, k); ang += 0.5 * k; ty = 1.2; }
    this.camAng = this.camIntro ? ang : U.dampAngle(this.camAng, ang, 4.5, dt);
    this.camD = this.camD === undefined || this.camIntro ? D : U.damp(this.camD, D, 3, dt); this.camH = this.camH === undefined || this.camIntro ? h : U.damp(this.camH, h, 3, dt);
    this.camT = this.camT || { x: tx, z: tz }; this.camT.x = this.camIntro ? tx : U.damp(this.camT.x, tx, 6, dt); this.camT.z = this.camIntro ? tz : U.damp(this.camT.z, tz, 6, dt);
    const sx = Math.sin(this.camAng), sz = Math.cos(this.camAng);
    this.camF.x = sx; this.camF.z = sz;
    const sk = this.shake * 0.05;
    cam.position.set(this.camT.x - sx * this.camD + (Math.random() - 0.5) * sk, this.camH + (Math.random() - 0.5) * sk, this.camT.z - sz * this.camD + (Math.random() - 0.5) * sk);
    cam.lookAt(new THREE.Vector3(this.camT.x, ty, this.camT.z));
  }
  resize(aspect) { this.camera.aspect = aspect; this.camera.updateProjectionMatrix(); }

  dispose() { this.f1.dispose(); this.f2.dispose(); this.fx.dispose(); this.arena.dispose(); Sound.crowdStop(); }
}
