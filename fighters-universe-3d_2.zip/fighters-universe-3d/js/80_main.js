/* =====================================================================
   MÓDULO 80 — Aplicação: renderizador, laço principal, fluxo menu → luta → resultado
   ===================================================================== */

const App = {
  renderer: null, stage: null, match: null, paused: false, last: 0, cfg: null,
  init() {
    Settings.load(); Profile.load(); Input.init();
    if (typeof THREE === 'undefined') return UI.fatal('A biblioteca Three.js não foi carregada. Verifique sua conexão com a internet e recarregue a página.');
    try {
      const canvas = $id('gl');
      const Q = Quality.cfg();
      App.renderer = new THREE.WebGLRenderer({ canvas, antialias: Q.aa, powerPreference: 'high-performance' });
      App.renderer.shadowMap.enabled = true; App.renderer.shadowMap.type = Q.aa ? THREE.PCFSoftShadowMap : THREE.PCFShadowMap;
    } catch (e) { return UI.fatal('Seu navegador não conseguiu iniciar o WebGL (gráficos 3D). Tente atualizar o navegador ou ativar a aceleração por hardware.'); }
    App.stage = new Stage(); UI.init(App.stage); Touch.init();
    window.addEventListener('resize', App.resize); App.resize();
    const cv = $id('gl');
    cv.addEventListener('pointerdown', (e) => { cv.focus(); window.focus(); App.stage.pointer('down', e); try { cv.setPointerCapture(e.pointerId); } catch (x) { /* */ } });
    cv.addEventListener('pointermove', (e) => App.stage.pointer('move', e));
    cv.addEventListener('pointerup', (e) => App.stage.pointer('up', e));
    cv.addEventListener('wheel', (e) => { App.stage.pointer('wheel', e); if (App.stage.interactive) e.preventDefault(); }, { passive: false });
    window.addEventListener('pointerdown', () => { Sound.init(); Sound.resume(); }, { once: false });
    Input.onPause = () => App.togglePause();
    UI.go('main');
    requestAnimationFrame(App.frame);
  },
  size() { return [window.innerWidth || 1280, window.innerHeight || 720]; },
  basePR() { return Math.min(window.devicePixelRatio || 1, Quality.cfg().pr); },
  resize() {
    const [w, h2] = App.size(); App.renderer.setPixelRatio(App.pr || App.basePR()); App.renderer.setSize(w, h2, false);
    App.stage.camera.aspect = w / h2; App.stage.camera.updateProjectionMatrix(); App.stage.ow = 0;
    if (App.match) App.match.resize(w / h2);
  },
  frame(now) {
    const dt = Math.min(0.05, (now - (App.last || now)) / 1000); App.last = now;
    try {
      if (App.match) {
        if (!App.paused) { App.match.update(dt); App.adapt(dt); }
        App.renderer.render(App.match.scene, App.match.camera);
      } else {
        const [w, h2] = App.size(); App.stage.applyOffset(w, h2, UI.panelEl());
        App.stage.update(dt); App.renderer.render(App.stage.scene, App.stage.camera);
      }
    } catch (e) { if (!App.errShown) { App.errShown = true; console.error(e); } }
    requestAnimationFrame(App.frame);
  },
  /* Resolução dinâmica: se a luta ficar abaixo de ~37 fps, reduz a resolução automaticamente */
  adapt(dt) {
    App.ema = App.ema ? App.ema * 0.92 + dt * 0.08 : dt;
    if (App.ema > 0.027) { App.slow = (App.slow || 0) + dt; if (App.slow > 1.2 && (App.pr || App.basePR()) > 0.5) { App.pr = Math.max(0.5, (App.pr || App.basePR()) * 0.82); App.resize(); App.slow = 0; App.ema = 0.02; } } else App.slow = 0;
  },
  startMatch(cfg) {
    Sound.init(); Sound.resume(); App.cfg = cfg; App.pr = null; App.ema = 0; App.slow = 0; App.resize(); Touch.show(true);
    if (App.match) App.disposeMatch();
    UI.hideAll(); const [w, h2] = App.size();
    const opts = Object.assign({}, cfg, { hud: HUD, aspect: w / h2, width: () => App.size()[0], height: () => App.size()[1], onEnd: (r) => App.onEnd(r) });
    App.match = new Match(opts); App.paused = false; HUD.show(true); Input.active = true; Input.down.clear(); Input.flush();
    if (cfg.arena !== 'academia') Sound.crowdStart();
    $id('s-main').classList.remove('on'); $id('s-setup').classList.remove('on');
    if (document.activeElement && document.activeElement.blur) document.activeElement.blur(); $id('gl').focus();
  },
  disposeMatch() { Touch.show(false); App.match.dispose(); App.match = null; Input.active = false; HUD.show(false); $id('popups').innerHTML = ''; $id('banner').className = ''; },
  onEnd(r) {
    Input.active = false; Touch.show(false);
    if (!App.cfg.training) { const rec = Profile.d.record; if (r.winner === 1) rec.w++; else rec.l++; Profile.save(); }
    UI.showResult(r, App.cfg);
  },
  togglePause() { if (!App.match || App.match.finished || $id('s-result').classList.contains('on')) return; if (App.paused) App.resume(); else App.pause(); },
  pause() { Touch.show(false); App.paused = true; Input.active = false; Input.down.clear(); UI.overlay('pause'); Sound.play('click'); },
  resume() { if (UI.ov === 'settings') UI.closeOverlay(true); $id('s-pause').classList.remove('on'); UI.ov = null; App.paused = false; Input.active = true; Input.down.clear(); Input.flush(); Touch.show(true); $id('gl').focus(); },
  restart() { const c = App.cfg; $id('s-result').classList.remove('on'); $id('s-pause').classList.remove('on'); App.startMatch(c); },
  quit(to) {
    $id('s-result').classList.remove('on'); $id('s-pause').classList.remove('on'); UI.ov = null; App.disposeMatch(); App.paused = false;
    UI.go(to || 'main'); Sound.crowdStop();
  },
};
UI.onOverlayClose = () => { if (App.match && App.paused) { $id('s-pause').classList.add('on'); UI.ov = 'pause'; } };
