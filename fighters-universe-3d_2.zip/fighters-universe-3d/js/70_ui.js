/* =====================================================================
   MÓDULO 70 — Interface: perfil, palco 3D (menu/editor), editor, seleção, HUD, ajustes
   ===================================================================== */

const h = (tag, attrs, ...kids) => {
  const e = document.createElement(tag);
  if (attrs) for (const k in attrs) {
    const v = attrs[k];
    if (k === 'class') e.className = v; else if (k === 'style') e.style.cssText = v;
    else if (k.slice(0, 2) === 'on') e.addEventListener(k.slice(2), v);
    else if (v !== false && v != null) e.setAttribute(k, v === true ? '' : v);
  }
  kids.flat(9).forEach((c) => { if (c == null || c === false) return; e.appendChild(typeof c === 'object' ? c : document.createTextNode(String(c))); });
  return e;
};
const $id = (id) => document.getElementById(id);

/* ---------- Perfil salvo (lutadores do jogador, selecionado, recorde) ---------- */
const Profile = {
  d: { roster: [], selected: null, record: { w: 0, l: 0 } },
  load() {
    const s = Store.get('profile', null);
    if (s && s.roster && s.roster.length) { Profile.d = s; Profile.d.record = Profile.d.record || { w: 0, l: 0 }; }
    else { const f = defaultFighter(); Profile.d = { roster: [f], selected: f.id, record: { w: 0, l: 0 } }; Profile.save(); }
  },
  save() { Store.set('profile', Profile.d); },
  get(id) { return Profile.d.roster.find((f) => f.id === id); },
  selected() { return Profile.get(Profile.d.selected) || Profile.d.roster[0]; },
  upsert(cfg) {
    const c = U.clone(cfg), i = Profile.d.roster.findIndex((f) => f.id === c.id);
    if (i >= 0) Profile.d.roster[i] = c; else Profile.d.roster.push(c);
    Profile.save();
  },
  remove(id) {
    Profile.d.roster = Profile.d.roster.filter((f) => f.id !== id);
    if (!Profile.d.roster.length) Profile.d.roster.push(defaultFighter());
    if (!Profile.get(Profile.d.selected)) Profile.d.selected = Profile.d.roster[0].id;
    Profile.save();
  },
};

/* ---------- Palco 3D (menu, editor e seleção de luta) ---------- */
class Stage {
  constructor() {
    const T = THREE;
    this.scene = new T.Scene(); this.scene.background = new T.Color(0x070a18); this.scene.fog = new T.Fog(0x070a18, 9, 24);
    this.camera = new T.PerspectiveCamera(32, 16 / 9, 0.1, 60);
    this.scene.add(new T.HemisphereLight(0xa8baff, 0x1a1030, 0.75));
    const key = new T.DirectionalLight(0xffffff, 0.95); key.position.set(2.5, 5, 4); key.target.position.set(0, 1, 0);
    if (Quality.cfg().shadows) { key.castShadow = true; key.shadow.mapSize.set(1024, 1024); const c = key.shadow.camera; c.left = -3; c.right = 3; c.top = 3; c.bottom = -3; c.near = 1; c.far = 14; key.shadow.bias = -0.0008; }
    this.scene.add(key); this.scene.add(key.target);
    const rb = new T.PointLight(0x2f7bff, 1.4, 12); rb.position.set(-3.2, 2.2, -2); this.scene.add(rb);
    const rr = new T.PointLight(0xff3b4a, 1.4, 12); rr.position.set(3.2, 2.2, -2); this.scene.add(rr);
    const plat = new T.Mesh(new T.CylinderGeometry(2.3, 2.4, 0.2, 48), mkMat({ color: 0x12182f, roughness: 0.5, metalness: 0.5 })); plat.position.y = -0.1; plat.receiveShadow = true; this.scene.add(plat);
    const r1 = new T.Mesh(new T.TorusGeometry(2.3, 0.03, 8, 64), new T.MeshBasicMaterial({ color: 0x2f7bff })); r1.rotation.x = Math.PI / 2; r1.position.y = 0.005; this.scene.add(r1);
    const r2 = new T.Mesh(new T.TorusGeometry(2.55, 0.02, 8, 64), new T.MeshBasicMaterial({ color: 0xff3b4a })); r2.rotation.x = Math.PI / 2; r2.position.y = -0.1; this.scene.add(r2);
    const fl = new T.Mesh(new T.PlaneGeometry(40, 40), mkMat({ color: 0x080b1a, roughness: 0.9 })); fl.rotation.x = -Math.PI / 2; fl.position.y = -0.21; this.scene.add(fl);
    this.puppets = []; this.t = 0; this.th = 0.45; this.ph = 1.38; this.rad = 5.2; this.ty = 0.95; this.goal = { rad: 5.2, ty: 0.95 };
    this.auto = 0.22; this.mode = 'menu'; this.drag = null; this.interactive = false; this.anim = true;
  }
  setFighters(cfgs) {
    this.puppets.forEach((p) => { this.scene.remove(p.rig.root); p.rig.dispose(); });
    this.puppets = cfgs.map((c) => { const rig = buildRig(c); this.scene.add(rig.root); return { rig, cfg: c }; });
    this.layout();
  }
  rebuild(i, cfg) {
    const old = this.puppets[i]; if (!old) return;
    this.scene.remove(old.rig.root); old.rig.dispose();
    const rig = buildRig(cfg); this.scene.add(rig.root); this.puppets[i] = { rig, cfg }; this.layout();
  }
  layout() {
    const n = this.puppets.length;
    this.puppets.forEach((p, i) => { p.rig.root.position.set(n === 2 ? (i ? 0.9 : -0.9) : 0, 0, 0); p.rig.root.rotation.y = n === 2 ? (i ? -Math.PI / 2 : Math.PI / 2) : 0; p.baseYaw = p.rig.root.rotation.y; });
  }
  focus(kind) {
    const S = this.puppets[0] ? this.puppets[0].rig.S : 1;
    if (kind === 'face') { this.goal.rad = 1.25 * S + 0.3; this.goal.ty = 1.6 * S; }
    else if (kind === 'back') { this.goal.rad = 4.6 * S + 0.6; this.goal.ty = 0.95 * S; this.th = Math.PI + 0.45; }
    else { this.goal.rad = 4.6 * S + 0.6; this.goal.ty = 0.95 * S; this.th = 0.45; }
  }
  setTwo(on) { this.goal.rad = on ? 6.4 : 5.2; this.goal.ty = on ? 1.0 : 0.95; if (on) this.th = 0; }
  update(dt) {
    this.t += dt;
    this.puppets.forEach((p, i) => {
      const t = this.t + i * 1.3; let pose = P({ y: GUARD.y + Math.sin(t * 2.4) * 0.006, sRx: 0.1 + Math.sin(t * 2.4) * 0.01 });
      if (this.anim && this.mode !== 'editor') {
        const cyc = 4.6, c = t % cyc, id = ['jab', 'cross', 'highKick', 'hook'][Math.floor(t / cyc) % 4], mv = MOVES[id];
        if (c < mv.dur) pose = sampleFrames(mv.frames, c, {});
      }
      applyPose(p.rig, pose);
    });
    if (this.mode === 'menu' && !this.drag) this.th += this.auto * dt;
    this.rad = U.damp(this.rad, this.goal.rad, 5, dt); this.ty = U.damp(this.ty, this.goal.ty, 5, dt);
    const sp = Math.sin(this.ph), c = this.camera;
    c.position.set(this.rad * sp * Math.sin(this.th), this.ty + this.rad * Math.cos(this.ph) * 0.9, this.rad * sp * Math.cos(this.th));
    c.lookAt(new THREE.Vector3(0, this.ty, 0));
  }
  applyOffset(W, H, el) {
    let dx = 0, dy = 0;
    if (el) {
      const r = el.getBoundingClientRect();
      if (r.width > W * 0.85) { dy = (r.top - H) / 2 + 0; dy = -(H - r.top) / 2; }       // painel embaixo
      else if (r.left < W / 2) dx = r.right / 2;                                       // painel à esquerda
    }
    if (Math.abs(dx - (this.ox || 0)) > 0.5 || Math.abs(dy - (this.oy || 0)) > 0.5 || this.ow !== W || this.oh !== H) {
      this.ox = dx; this.oy = dy; this.ow = W; this.oh = H;
      if (dx || dy) this.camera.setViewOffset(W, H, -dx, -dy, W, H); else this.camera.clearViewOffset();
    }
  }
  pointer(type, e) {
    if (!this.interactive) return;
    if (type === 'down') this.drag = { x: e.clientX, y: e.clientY };
    else if (type === 'move' && this.drag) { this.th -= (e.clientX - this.drag.x) * 0.008; this.ph = U.clamp(this.ph - (e.clientY - this.drag.y) * 0.004, 0.6, 1.75); this.drag = { x: e.clientX, y: e.clientY }; }
    else if (type === 'up') this.drag = null;
    else if (type === 'wheel') this.goal.rad = U.clamp(this.goal.rad + e.deltaY * 0.004, 1.0, 8);
  }
}

/* ---------- Esquema do editor (declarativo: adicionar campo = adicionar linha) ---------- */
const ED_TABS = [
  { id: 'id', label: 'Identidade', fields: [
    { t: 'text', k: 'name', label: 'Nome', max: 16 }, { t: 'text', k: 'nick', label: 'Apelido', max: 14 },
    { t: 'range', k: 'age', label: 'Idade fictícia', min: 18, max: 60, unit: ' anos' },
    { t: 'seg', k: 'sex', label: 'Sexo', opts: OPT.sex, after: 'sex' },
    { t: 'seg', k: 'build', label: 'Tipo físico', opts: OPT.build, after: 'build' } ] },
  { id: 'body', label: 'Corpo', fields: [
    { t: 'range', k: 'height', label: 'Altura', min: 150, max: 210, unit: ' cm' }, { t: 'range', k: 'muscle', label: 'Musculatura', min: 0, max: 100 },
    { t: 'range', k: 'fat', label: 'Peso / gordura', min: 0, max: 100 }, { t: 'range', k: 'shoulders', label: 'Ombros', min: 0, max: 100 },
    { t: 'range', k: 'legs', label: 'Comprimento das pernas', min: 0, max: 100 }, { t: 'range', k: 'arms', label: 'Comprimento dos braços', min: 0, max: 100 },
    { t: 'color', k: 'skin', label: 'Cor da pele', pal: PALETTE.skin },
    { t: 'sel', k: 'tattoo', label: 'Tatuagem', opts: OPT.tattoo }, { t: 'color', k: 'tattooColor', label: 'Cor da tatuagem', pal: PALETTE.tattoo },
    { t: 'sel', k: 'scar', label: 'Cicatriz', opts: OPT.scar } ] },
  { id: 'face', label: 'Rosto', fields: [
    { t: 'range', k: 'headSize', label: 'Tamanho da cabeça', min: 0, max: 100 }, { t: 'range', k: 'faceWidth', label: 'Largura do rosto', min: 0, max: 100 }, { t: 'range', k: 'noseSize', label: 'Nariz', min: 0, max: 100 },
    { t: 'seg', k: 'eyeShape', label: 'Olhos', opts: OPT.eyes }, { t: 'color', k: 'eyeColor', label: 'Cor dos olhos', pal: PALETTE.eyes },
    { t: 'seg', k: 'brows', label: 'Sobrancelhas', opts: OPT.brows }, { t: 'seg', k: 'mouth', label: 'Boca', opts: OPT.mouth },
    { t: 'sel', k: 'hairStyle', label: 'Penteado', opts: OPT.hair }, { t: 'color', k: 'hairColor', label: 'Cor do cabelo', pal: PALETTE.hair },
    { t: 'sel', k: 'beard', label: 'Barba', opts: OPT.beard }, { t: 'color', k: 'beardColor', label: 'Cor da barba', pal: PALETTE.hair } ] },
  { id: 'cloth', label: 'Roupas', fields: [
    { t: 'sel', k: 'shirt', label: 'Camisa', opts: OPT.shirt }, { t: 'color', k: 'shirtColor', label: 'Cor da camisa', pal: PALETTE.cloth },
    { t: 'sel', k: 'pants', label: 'Calça / shorts', opts: OPT.pants }, { t: 'color', k: 'pantsColor', label: 'Cor da calça', pal: PALETTE.cloth }, { t: 'color', k: 'trimColor', label: 'Cor do detalhe', pal: PALETTE.cloth },
    { t: 'sel', k: 'gloves', label: 'Luvas', opts: OPT.gloves }, { t: 'color', k: 'glovesColor', label: 'Cor das luvas', pal: PALETTE.cloth },
    { t: 'sel', k: 'boots', label: 'Calçados', opts: OPT.boots }, { t: 'color', k: 'bootsColor', label: 'Cor dos calçados', pal: PALETTE.cloth },
    { t: 'sel', k: 'headAcc', label: 'Acessório de cabeça', opts: OPT.headAcc }, { t: 'color', k: 'headAccColor', label: 'Cor do acessório', pal: PALETTE.cloth },
    { t: 'sel', k: 'bodyAcc', label: 'Acessório de corpo', opts: OPT.bodyAcc }, { t: 'color', k: 'bodyAccColor', label: 'Cor do acessório', pal: PALETTE.cloth } ] },
  { id: 'fight', label: 'Luta', custom: true },
];

const Editor = {
  draft: null, saved: '', tab: 'id', stage: null,
  open(stage) {
    Editor.stage = stage; Editor.draft = U.clone(Profile.selected()); Editor.saved = JSON.stringify(Editor.draft); Editor.tab = 'id';
    Editor.refreshRoster(); Editor.renderTabs(); Editor.renderBody(); stage.setFighters([Editor.draft]); stage.focus('full');
  },
  dirty() { return JSON.stringify(Editor.draft) !== Editor.saved; },
  refreshRoster() {
    const sel = $id('ed-sel'); sel.innerHTML = '';
    Profile.d.roster.forEach((f) => sel.appendChild(h('option', { value: f.id }, f.name + (f.id === Profile.d.selected ? '  ★' : ''))));
    if (!Profile.get(Editor.draft.id)) sel.appendChild(h('option', { value: Editor.draft.id }, Editor.draft.name + ' (novo)'));
    sel.value = Editor.draft.id;
  },
  changed(rebuild) { if (rebuild !== false) Editor.stage.rebuild(0, Editor.draft); },
  renderTabs() {
    const t = $id('ed-tabs'); t.innerHTML = '';
    ED_TABS.forEach((tb) => t.appendChild(h('button', { class: 'tab' + (tb.id === Editor.tab ? ' on' : ''), onclick: () => { Editor.tab = tb.id; Editor.renderTabs(); Editor.renderBody(); Sound.play('click'); } }, tb.label)));
  },
  renderBody() {
    const body = $id('ed-body'); body.innerHTML = ''; const tb = ED_TABS.find((x) => x.id === Editor.tab);
    if (tb.custom) return Editor.renderFight(body);
    tb.fields.forEach((f) => body.appendChild(Editor.field(f)));
  },
  field(f) {
    const d = Editor.draft, wrap = h('div', { class: 'fld' });
    if (f.t === 'text') {
      wrap.appendChild(h('label', null, f.label)); wrap.appendChild(h('input', { type: 'text', maxlength: f.max, value: d[f.k], oninput: (e) => { d[f.k] = e.target.value; } }));
    } else if (f.t === 'range') {
      const val = h('span', { class: 'val' }, d[f.k] + (f.unit || ''));
      wrap.appendChild(h('label', null, f.label, val));
      wrap.appendChild(h('input', { type: 'range', min: f.min, max: f.max, value: d[f.k], oninput: (e) => { d[f.k] = +e.target.value; val.textContent = d[f.k] + (f.unit || ''); Editor.changed(); } }));
    } else if (f.t === 'sel') {
      const s = h('select', { onchange: (e) => { d[f.k] = e.target.value; Editor.changed(); } }, f.opts.map((o) => h('option', { value: o[0] }, o[1]))); s.value = d[f.k];
      wrap.appendChild(h('label', null, f.label)); wrap.appendChild(s);
    } else if (f.t === 'seg') {
      const seg = h('div', { class: 'seg' });
      f.opts.forEach((o) => seg.appendChild(h('button', { class: d[f.k] === o[0] ? 'on' : '', onclick: () => {
        d[f.k] = o[0]; if (f.after === 'build') Object.assign(d, BUILD_PRESETS[o[0]]);
        if (f.after === 'sex') { d.height = o[0] === 'F' ? Math.min(d.height, 170) : d.height; }
        Editor.changed(); Editor.renderBody(); } }, o[1])));
      wrap.appendChild(h('div', { class: 'lab' }, f.label)); wrap.appendChild(seg);
    } else if (f.t === 'color') {
      const sw = h('div', { class: 'sw' }), cur = d[f.k] || (f.k === 'beardColor' ? d.hairColor : '#ffffff');
      f.pal.forEach((c) => sw.appendChild(h('button', { style: 'background:' + c, class: cur.toLowerCase() === c ? 'on' : '', 'aria-label': c, onclick: () => { d[f.k] = c; Editor.changed(); Editor.renderBody(); } })));
      sw.appendChild(h('input', { type: 'color', value: /^#[0-9a-f]{6}$/i.test(cur) ? cur : '#ffffff', 'aria-label': 'Cor personalizada', oninput: (e) => { d[f.k] = e.target.value; Editor.changed(); } }));
      wrap.appendChild(h('div', { class: 'lab' }, f.label)); wrap.appendChild(sw);
    }
    return wrap;
  },
  renderFight(body) {
    const d = Editor.draft;
    body.appendChild(h('div', { class: 'sec' }, 'Estilo de luta'));
    const cards = h('div', { class: 'cards' });
    Object.keys(STYLES).forEach((k) => cards.appendChild(h('button', { class: 'card' + (d.style === k ? ' on' : ''), onclick: () => { d.style = k; Editor.renderBody(); Sound.play('select'); } }, h('b', null, STYLES[k].name), h('span', null, STYLES[k].desc))));
    body.appendChild(cards);
    body.appendChild(h('div', { class: 'sec', style: 'margin-top:18px' }, 'Atributos'));
    const used = () => Object.values(d.attrs).reduce((a, b) => a + b, 0);
    const pool = h('div', { class: 'pool' }); body.appendChild(pool);
    const rows = {};
    const refresh = () => { pool.innerHTML = ''; pool.appendChild(document.createTextNode('Pontos livres: ')); pool.appendChild(h('b', null, ATTR_POOL - used())); ATTRS.forEach(([k]) => { rows[k].v.textContent = d.attrs[k]; rows[k].b.style.width = (d.attrs[k] / ATTR_MAX * 100) + '%'; }); };
    ATTRS.forEach(([k, label, tip]) => {
      const v = h('span', null, ''), b = h('i', null), r = h('div', { class: 'attr', title: tip },
        h('span', null, label), h('div', { class: 'bar' }, b), v,
        h('button', { 'aria-label': 'Diminuir ' + label, onclick: () => { if (d.attrs[k] > ATTR_MIN) { d.attrs[k]--; refresh(); } } }, '−'),
        h('button', { 'aria-label': 'Aumentar ' + label, onclick: () => { if (d.attrs[k] < ATTR_MAX && used() < ATTR_POOL) { d.attrs[k]++; refresh(); } } }, '+'));
      rows[k] = { v, b }; body.appendChild(r); body.appendChild(h('div', { style: 'color:var(--mute);font-size:14px;margin:-4px 0 10px' }, tip));
    });
    refresh();
  },
  randomize() {
    const d = Editor.draft, r = (o) => U.pick(o)[0], c = (p) => U.pick(p);
    Object.assign(d, { skin: c(PALETTE.skin), hairStyle: r(OPT.hair), hairColor: c(PALETTE.hair), beard: d.sex === 'F' ? 'nenhuma' : r(OPT.beard), eyeColor: c(PALETTE.eyes), eyeShape: r(OPT.eyes), brows: r(OPT.brows), mouth: r(OPT.mouth),
      shirt: r(OPT.shirt), shirtColor: c(PALETTE.cloth), pants: r(OPT.pants), pantsColor: c(PALETTE.cloth), trimColor: c(PALETTE.cloth), gloves: r(OPT.gloves), glovesColor: c(PALETTE.cloth), boots: r(OPT.boots), bootsColor: c(PALETTE.cloth),
      headAcc: r(OPT.headAcc), headAccColor: c(PALETTE.cloth), bodyAcc: r(OPT.bodyAcc), bodyAccColor: c(PALETTE.cloth), tattoo: r(OPT.tattoo), scar: r(OPT.scar), height: U.randInt(160, 196), muscle: U.randInt(15, 90), fat: U.randInt(5, 70), shoulders: U.randInt(30, 80) });
    d.beardColor = d.hairColor; Editor.changed(); Editor.renderBody();
  },
  save(select) {
    const d = Editor.draft; d.name = (d.name || '').trim() || 'Sem nome'; d.nick = (d.nick || '').trim();
    Profile.upsert(d); if (select) Profile.d.selected = d.id; Profile.save();
    Editor.saved = JSON.stringify(d); Editor.refreshRoster(); UI.toast(select ? d.name + ' será seu lutador' : 'Lutador salvo');
  },
  load(id) { const f = Profile.get(id); if (!f) return; Editor.draft = U.clone(f); Editor.saved = JSON.stringify(Editor.draft); Editor.renderBody(); Editor.stage.rebuild(0, Editor.draft); },
  init() {
    $id('ed-sel').addEventListener('change', (e) => { const go = () => Editor.load(e.target.value); if (Editor.dirty()) UI.confirm('Descartar alterações não salvas?', go, () => { e.target.value = Editor.draft.id; }); else go(); });
    $id('ed-new').onclick = () => { const go = () => { Editor.draft = defaultFighter({ name: 'Lutador ' + (Profile.d.roster.length + 1), nick: '' }); Editor.saved = ''; Editor.refreshRoster(); Editor.renderBody(); Editor.stage.rebuild(0, Editor.draft); }; Sound.play('click'); if (Editor.dirty()) UI.confirm('Descartar alterações não salvas?', go); else go(); };
    $id('ed-save').onclick = () => { Sound.play('select'); Editor.save(false); };
    $id('ed-use').onclick = () => { Sound.play('select'); Editor.save(true); };
    $id('ed-rand').onclick = () => { Sound.play('click'); Editor.randomize(); };
    $id('ed-del').onclick = () => { Sound.play('click'); if (!Profile.get(Editor.draft.id)) return UI.toast('Este lutador ainda não foi salvo'); UI.confirm('Excluir "' + Editor.draft.name + '"?', () => { Profile.remove(Editor.draft.id); Editor.open(Editor.stage); UI.toast('Lutador excluído'); }); };
    $id('ed-back').onclick = () => { Sound.play('click'); if (Editor.dirty()) UI.confirm('Sair sem salvar as alterações?', () => UI.go('main')); else UI.go('main'); };
    U.$$('[data-cam]').forEach((b) => { b.onclick = () => { Sound.play('click'); Editor.stage.focus(b.dataset.cam); }; });
  },
};

/* ---------- Seleção de luta (combate rápido / treinamento) ---------- */
const Setup = {
  mode: 'quick', meId: null, oppIdx: 0, arena: 'arena', diff: 'normal', rounds: 3, dummy: 'parado', list: [],
  open(mode, stage) {
    Setup.mode = mode; Setup.stage = stage; Setup.meId = Profile.d.selected; Setup.rounds = Settings.data.rounds;
    Setup.buildList(); Setup.oppIdx = Math.min(Setup.oppIdx, Setup.list.length - 1);
    $id('su-title').textContent = mode === 'training' ? 'Treinamento' : 'Combate rápido'; Setup.render(); Setup.refresh3D();
  },
  buildList() { Setup.list = makeRoster().concat(Profile.d.roster.filter((f) => f.id !== Setup.meId)); },
  me() { return Profile.get(Setup.meId) || Profile.selected(); },
  opp() { return Setup.list[Setup.oppIdx]; },
  refresh3D() { Setup.stage.setFighters([Setup.me(), Setup.opp()]); Setup.stage.setTwo(true); },
  miniStats(c) { const f = h('div'); ATTRS.forEach(([k, l]) => f.appendChild(h('div', { class: 'mini' }, h('span', null, l), h('div', { class: 'bar' }, h('i', { style: 'width:' + c.attrs[k] / ATTR_MAX * 100 + '%' })), h('span', null, c.attrs[k])))); return f; },
  card(el, c, extra) {
    el.innerHTML = ''; el.appendChild(h('div', { class: 'nm' }, c.name)); el.appendChild(h('div', { class: 'nk' }, c.nick ? '“' + c.nick + '” · ' + c.age + ' anos' : c.age + ' anos'));
    el.appendChild(h('span', { class: 'chip' }, STYLES[c.style].name)); el.appendChild(Setup.miniStats(c)); if (extra) el.appendChild(extra);
  },
  render() {
    const me = Setup.me(), opp = Setup.opp();
    const sel = h('select', { 'aria-label': 'Seu lutador', onchange: (e) => { Setup.meId = e.target.value; Setup.buildList(); Setup.oppIdx = Math.min(Setup.oppIdx, Setup.list.length - 1); Setup.render(); Setup.refresh3D(); } }, Profile.d.roster.map((f) => h('option', { value: f.id }, f.name))); sel.value = me.id;
    Setup.card($id('su-me'), me, h('div', { class: 'vs-row' }, sel, h('button', { class: 'btn', onclick: () => UI.go('editor') }, h('span', null, 'Editar'))));
    const nav = h('div', { class: 'vs-row' }, h('button', { class: 'btn', 'aria-label': 'Adversário anterior', onclick: () => { Setup.oppIdx = (Setup.oppIdx + Setup.list.length - 1) % Setup.list.length; Sound.play('click'); Setup.render(); Setup.stage.rebuild(1, Setup.opp()); } }, h('span', null, '◀')),
      h('span', { style: 'flex:1;text-align:center;color:var(--mute)' }, (Setup.oppIdx + 1) + ' / ' + Setup.list.length),
      h('button', { class: 'btn', 'aria-label': 'Próximo adversário', onclick: () => { Setup.oppIdx = (Setup.oppIdx + 1) % Setup.list.length; Sound.play('click'); Setup.render(); Setup.stage.rebuild(1, Setup.opp()); } }, h('span', null, '▶')));
    Setup.card($id('su-opp'), opp, nav);
    const ap = $id('su-arenas'); ap.innerHTML = '';
    ARENAS.forEach((a) => ap.appendChild(h('button', { class: Setup.arena === a.id ? 'on' : '', style: 'background:linear-gradient(120deg,' + a.c1 + ',' + a.c2 + ')', onclick: () => { Setup.arena = a.id; Sound.play('click'); Setup.render(); } }, h('b', null, a.name), h('span', null, a.desc))));
    const seg = (el, label, opts, cur, set) => { el.innerHTML = ''; el.appendChild(h('div', { class: 'lab' }, label)); const s = h('div', { class: 'seg' }); opts.forEach(([v, t]) => s.appendChild(h('button', { class: cur === v ? 'on' : '', onclick: () => { set(v); Sound.play('click'); Setup.render(); } }, t))); el.appendChild(s); };
    if (Setup.mode === 'quick') {
      seg($id('su-opt1'), 'Dificuldade', Object.keys(AI_LEVELS).map((k) => [k, AI_LEVELS[k].name]), Setup.diff, (v) => { Setup.diff = v; });
      seg($id('su-opt2'), 'Rounds', [[1, '1'], [3, 'Melhor de 3']], Setup.rounds, (v) => { Setup.rounds = v; Settings.data.rounds = v; Settings.save(); });
    } else {
      seg($id('su-opt1'), 'Adversário de treino', [['parado', 'Parado'], ['defende', 'Defende'], ['facil', 'Ataca (fácil)']], Setup.dummy, (v) => { Setup.dummy = v; });
      $id('su-opt2').innerHTML = '';
    }
  },
  start() {
    const training = Setup.mode === 'training';
    App.startMatch({ p1: U.clone(Setup.me()), p2: U.clone(Setup.opp()), arena: Setup.arena, ai: training ? Setup.dummy : Setup.diff, training, rounds: Setup.rounds, roundTime: Settings.data.roundTime });
  },
  init() { $id('su-go').onclick = () => { Sound.play('bell'); Setup.start(); }; $id('su-back').onclick = () => { Sound.play('click'); UI.go('main'); }; },
};

/* ---------- Configurações (controles remapeáveis, som, gráficos) ---------- */
const SettingsUI = {
  cap: null, from: 'main',
  open(from) { SettingsUI.from = from; SettingsUI.render(); UI.overlay('settings'); },
  render() {
    const box = $id('set-box'); box.innerHTML = '';
    box.appendChild(h('h2', null, 'Controles e opções'));
    const grid = h('div', { class: 'set-grid' });
    const col1 = h('div'); col1.appendChild(h('div', { class: 'sec' }, 'Teclado (clique para alterar)'));
    ACTIONS.forEach((a) => {
      const codes = Input.codes(a.id);
      const b = h('button', { class: SettingsUI.cap === a.id ? 'cap' : '', onclick: () => SettingsUI.rebind(a.id) }, SettingsUI.cap === a.id ? 'Pressione…' : keyLabel(codes[0]) + (codes[1] ? ' / ' + keyLabel(codes[1]) : ''));
      col1.appendChild(h('div', { class: 'krow' }, h('span', null, a.label), b));
    });
    col1.appendChild(h('p', { style: 'color:var(--mute);font-size:15px;margin-top:10px;line-height:1.35' }, 'Dica: segure a direção para frente (rumo ao oponente) junto com o chute para um chute frontal, ou com o chute forte para uma joelhada. Encadeie botões durante o golpe para fazer combos.'));
    const col2 = h('div'); col2.appendChild(h('div', { class: 'sec' }, 'Opções'));
    const S = Settings.data;
    const sw = (label, opts, cur, set) => { const w = h('div', { class: 'fld' }, h('div', { class: 'lab' }, label)); const s = h('div', { class: 'seg' }); opts.forEach(([v, t]) => s.appendChild(h('button', { class: cur === v ? 'on' : '', onclick: () => { set(v); Settings.save(); SettingsUI.render(); } }, t))); w.appendChild(s); return w; };
    col2.appendChild(sw('Som', [[true, 'Ligado'], [false, 'Desligado']], S.sound, (v) => { S.sound = v; Sound.applyVolume(); }));
    const vol = h('div', { class: 'fld' }, h('label', null, 'Volume', h('span', { class: 'val' }, Math.round(S.volume * 100) + '%')), h('input', { type: 'range', min: 0, max: 100, value: Math.round(S.volume * 100), oninput: (e) => { S.volume = e.target.value / 100; Sound.applyVolume(); e.target.previousSibling.lastChild.textContent = e.target.value + '%'; }, onchange: () => { Settings.save(); Sound.play('punch'); } }));
    col2.appendChild(vol);
    col2.appendChild(sw('Qualidade gráfica', [['baixa', 'Baixa'], ['media', 'Média'], ['alta', 'Alta']], S.quality, (v) => { S.quality = v; App.pr = null; }));
    col2.appendChild(h('p', { style: 'color:var(--mute);font-size:14px;margin:-8px 0 14px' }, 'Se estiver travando, escolha Baixa (vale a partir da próxima luta). A resolução também se ajusta sozinha.'));
    col2.appendChild(sw('Controles na tela (toque)', [['auto', 'Automático'], ['on', 'Sempre'], ['off', 'Nunca']], S.touch, (v) => { S.touch = v; }));
    col2.appendChild(h('div', { class: 'fld' }, h('button', { class: 'btn', onclick: () => { try { const d = document.documentElement; if (document.fullscreenElement) document.exitFullscreen(); else if (d.requestFullscreen) d.requestFullscreen(); } catch (e) { /* */ } } }, h('span', null, 'Tela cheia'))));
    col2.appendChild(sw('Rounds por luta', [[1, '1'], [3, 'Melhor de 3']], S.rounds, (v) => { S.rounds = v; }));
    col2.appendChild(sw('Tempo do round', [[45, '45 s'], [60, '60 s'], [90, '90 s'], [99, '99 s']], S.roundTime, (v) => { S.roundTime = v; }));
    grid.appendChild(col1); grid.appendChild(col2); box.appendChild(grid);
    box.appendChild(h('div', { style: 'margin-top:16px' }, h('button', { class: 'btn blue', onclick: () => { Sound.play('click'); UI.closeOverlay(); } }, h('span', null, 'Fechar')),
      h('button', { class: 'btn', onclick: () => { Settings.data.bindings = {}; Settings.save(); SettingsUI.render(); } }, h('span', null, 'Restaurar teclas padrão'))));
  },
  rebind(action) {
    SettingsUI.cap = action; SettingsUI.render();
    Input.capture = (code) => {
      Input.capture = null; SettingsUI.cap = null;
      if (code !== 'Escape') {
        const nc = Input.norm(code), old = Input.codes(action).slice();
        ACTIONS.forEach((o) => { if (o.id !== action) { const cs = Input.codes(o.id); if (cs.some((c) => Input.norm(c) === nc)) { Settings.data.bindings[o.id] = cs.map((c) => (Input.norm(c) === nc ? old[0] : c)); } } });
        Settings.data.bindings[action] = [nc].concat(old.slice(1).filter((c) => Input.norm(c) !== nc)); Settings.save();
      }
      SettingsUI.render();
    };
  },
};

/* ---------- HUD de combate ---------- */
const HUD = {
  lag: [1, 1], last: 0,
  setup(m) {
    $id('h1n').textContent = m.f1.name; $id('h1k').textContent = m.f1.nick || ''; $id('h2n').textContent = m.f2.name; $id('h2k').textContent = m.f2.nick || '';
    HUD.lag = [1, 1];
    [['h1p', 0], ['h2p', 1]].forEach(([id, i]) => { const el = $id(id); el.innerHTML = ''; if (!m.training) for (let k = 0; k < m.roundsToWin; k++) el.appendChild(h('div', { class: 'pip' })); });
    const tr = $id('train'); tr.style.display = m.training ? 'block' : 'none'; tr.innerHTML = '';
    if (m.training) {
      const kb = (a) => h('span', { class: 'kbd' }, keyLabel(Input.codes(a)[0]));
      const names = { jab: 'Jab', heavyPunch: 'Direto', kick: 'Chute baixo', heavyKick: 'Chute alto', block: 'Defesa', dodge: 'Esquiva', grab: 'Agarrão', run: 'Corrida' };
      tr.appendChild(h('h3', null, 'Golpes'));
      ['jab', 'heavyPunch', 'kick', 'heavyKick', 'block', 'dodge', 'grab', 'run'].forEach((a) => tr.appendChild(h('div', null, kb(a), names[a])));
      tr.appendChild(h('h3', { style: 'margin-top:10px' }, 'Combos'));
      COMBO_LIST.forEach((c) => tr.appendChild(h('div', null, c.map((a) => kb(a)))));
      tr.appendChild(h('div', { style: 'margin-top:6px;color:var(--mute)' }, 'Esc: pausar'));
    }
    $id('hud-hint').textContent = m.training ? '' : '';
  },
  show(on) { $id('hud').classList.toggle('on', on); },
  update(m) {
    const set = (id, v) => { $id(id).style.width = (U.clamp(v, 0, 1) * 100) + '%'; };
    const a = m.f1.hp / m.f1.maxHp, b = m.f2.hp / m.f2.maxHp;
    HUD.lag[0] = Math.max(a, HUD.lag[0] - 0.012); HUD.lag[1] = Math.max(b, HUD.lag[1] - 0.012);
    set('h1f', a); set('h2f', b); set('h1l', HUD.lag[0]); set('h2l', HUD.lag[1]);
    set('h1s', m.f1.st / m.f1.maxSt); set('h2s', m.f2.st / m.f2.maxSt);
    $id('h1sb').classList.toggle('low', m.f1.exhausted); $id('h2sb').classList.toggle('low', m.f2.exhausted);
    $id('timer').textContent = m.training ? '∞' : Math.ceil(m.timeLeft);
    $id('rlbl').textContent = m.training ? 'TREINO' : 'ROUND ' + m.round;
    [['h1p', 0], ['h2p', 1]].forEach(([id, i]) => U.$$('.pip', $id(id)).forEach((p, k) => p.classList.toggle('on', k < m.wins[i])));
  },
  banner(text, sub, cls, ms) {
    const b = $id('banner'); b.className = cls; b.innerHTML = ''; b.appendChild(document.createTextNode(text)); if (sub) b.appendChild(h('small', null, sub));
    b.style.setProperty('--ms', ms + 'ms'); void b.offsetWidth; b.classList.add('show');
  },
  popup(p, text, cls) {
    const e = h('div', { class: 'pop ' + cls, style: 'left:' + p.x + 'px;top:' + p.y + 'px' }, text); $id('popups').appendChild(e); setTimeout(() => e.remove(), 950);
  },
  combo(n) { const c = $id('combo'); c.innerHTML = ''; c.appendChild(document.createTextNode(n + ' hits')); c.appendChild(h('small', null, 'COMBO')); c.classList.remove('show'); void c.offsetWidth; c.classList.add('show'); },
};

/* ---------- Controle de telas ---------- */
const UI = {
  cur: null, stage: null, tt: 0,
  init(stage) {
    UI.stage = stage;
    U.$$('[data-go]').forEach((b) => { b.onclick = () => { Sound.init(); Sound.resume(); Sound.play('select'); UI.go(b.dataset.go); }; });
    Editor.init(); Setup.init();
    $id('pa-resume').onclick = () => App.resume(); $id('pa-restart').onclick = () => App.restart(); $id('pa-quit').onclick = () => App.quit();
    $id('pa-controls').onclick = () => SettingsUI.open('pause');
  },
  screens: ['main', 'editor', 'setup'],
  go(name) {
    UI.cur = name === 'quick' || name === 'training' ? 'setup' : name; const st = UI.stage;
    UI.screens.concat(['settings']).forEach((n) => $id('s-' + n).classList.remove('on'));
    UI.closeOverlay(true);
    if (name === 'settings') { UI.cur = 'main'; $id('s-main').classList.add('on'); st.mode = 'menu'; SettingsUI.open('main'); return; }
    const scr = name === 'quick' || name === 'training' ? 'setup' : name;
    $id('s-' + scr).classList.add('on'); st.interactive = name === 'editor'; st.mode = name === 'editor' ? 'editor' : name === 'main' ? 'menu' : 'setup';
    if (name === 'main') { st.setFighters([Profile.selected()]); st.focus('full'); st.th = 0.45; const r = Profile.d.record; $id('main-foot').innerHTML = ''; $id('main-foot').appendChild(h('span', null, 'Lutador atual: ', h('b', null, Profile.selected().name), '  ·  Vitórias ', h('b', null, r.w), '  Derrotas ', h('b', null, r.l))); }
    if (name === 'editor') Editor.open(st);
    if (name === 'quick' || name === 'training') Setup.open(name, st);
  },
  panelEl() { return UI.cur === 'main' ? U.$('.menu-col') : UI.cur === 'editor' ? $id('ed-panel') : null; },
  overlay(name) { $id('s-' + name).classList.add('on'); UI.ov = name; },
  closeOverlay(silent) { if (UI.ov) { $id('s-' + UI.ov).classList.remove('on'); UI.ov = null; } SettingsUI.cap = null; Input.capture = null; if (!silent && UI.onOverlayClose) UI.onOverlayClose(); },
  hideAll() { UI.screens.concat(['pause', 'result', 'settings', 'modal']).forEach((n) => $id('s-' + n).classList.remove('on')); UI.ov = null; },
  toast(msg) { const t = $id('toast'); t.textContent = msg; t.classList.add('show'); clearTimeout(UI.tt); UI.tt = setTimeout(() => t.classList.remove('show'), 1800); },
  confirm(msg, yes, no) {
    const box = $id('modal-box'); box.innerHTML = '';
    const close = () => $id('s-modal').classList.remove('on');
    box.appendChild(h('h2', { style: 'font-size:32px' }, msg));
    box.appendChild(h('button', { class: 'btn red', onclick: () => { close(); yes && yes(); } }, h('span', null, 'Confirmar')));
    box.appendChild(h('button', { class: 'btn ghost', onclick: () => { close(); no && no(); } }, h('span', null, 'Cancelar')));
    $id('s-modal').classList.add('on');
  },
  fatal(msg) { $id('fatal-msg').textContent = msg; $id('fatal').classList.add('on'); },
  showResult(r, opts) {
    const box = $id('res-box'), win = r.winner === 1; box.innerHTML = '';
    box.appendChild(h('h2', { class: win ? 'win' : 'lose' }, win ? 'Vitória!' : 'Derrota'));
    box.appendChild(h('p', { style: 'color:var(--mute);font-size:18px' }, opts.p1.name + ' ' + r.wins[0] + ' × ' + r.wins[1] + ' ' + opts.p2.name + (r.flawless && win ? '  ·  Vitória perfeita' : '')));
    const acc = (s) => (s.tried ? Math.round(s.hits / s.tried * 100) + '%' : '—');
    const st = h('div', { class: 'stats' }, h('span', { class: 'h' }, ''), h('span', { class: 'h a' }, opts.p1.name), h('span', { class: 'h c' }, opts.p2.name));
    [['Golpes que acertaram', (s) => s.hits], ['Precisão', acc], ['Dano causado', (s) => s.dmg], ['Maior combo', (s) => s.maxCombo], ['Defesas', (s) => s.blocked], ['Quedas', (s) => s.throws]].forEach(([l, f]) => st.appendChild(h('span', null, l)) && st.appendChild(h('b', { class: 'a' }, f(r.p1))) && st.appendChild(h('b', { class: 'c' }, f(r.p2))));
    box.appendChild(st);
    box.appendChild(h('button', { class: 'btn red', onclick: () => App.restart() }, h('span', null, 'Revanche')));
    box.appendChild(h('button', { class: 'btn blue', onclick: () => App.quit('quick') }, h('span', null, 'Trocar adversário')));
    box.appendChild(h('button', { class: 'btn ghost', onclick: () => App.quit('main') }, h('span', null, 'Menu principal')));
    $id('s-result').classList.add('on');
  },
};
