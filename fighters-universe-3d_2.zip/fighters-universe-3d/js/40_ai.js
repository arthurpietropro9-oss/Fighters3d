/* =====================================================================
   MÓDULO 40 — Inteligência artificial e controle humano (ambos geram "intents")
   intent = { mx, mz (direção no mundo), along, block, run, press:[ações] }
   ===================================================================== */

const AI_LEVELS = {
  facil:   { name: 'Fácil',   react: 0.55, pBlock: 0.20, pDodge: 0.03, aggr: 0.35, comboP: 0.25, cd: [1.1, 2.0], grabP: 0.02 },
  normal:  { name: 'Normal',  react: 0.36, pBlock: 0.45, pDodge: 0.08, aggr: 0.55, comboP: 0.50, cd: [0.7, 1.4], grabP: 0.06 },
  dificil: { name: 'Difícil', react: 0.22, pBlock: 0.65, pDodge: 0.15, aggr: 0.75, comboP: 0.70, cd: [0.45, 1.0], grabP: 0.10 },
  mestre:  { name: 'Mestre',  react: 0.14, pBlock: 0.80, pDodge: 0.22, aggr: 0.90, comboP: 0.85, cd: [0.3, 0.7], grabP: 0.14 },
};

class AIController {
  /* level: chave de AI_LEVELS ou 'parado' / 'defende' (bonecos de treino) */
  constructor(level, fighter) {
    this.dummy = level === 'parado' || level === 'defende';
    this.dummyBlock = level === 'defende';
    this.L = AI_LEVELS[this.dummy ? 'facil' : level] || AI_LEVELS.normal;
    this.f = fighter;
    const style = fighter.cfg.style;
    this.ideal = style === 'lutalivre' ? 0.95 : style === 'muaythai' ? 1.05 : 1.2;
    this.cd = U.rand(0.6, 1.4); this.seq = []; this.seqI = 0; this.chainOK = false;
    this.react = 0; this.noticed = false; this.blockT = 0; this.wantDodge = false;
    this.strafe = 1; this.strafeT = 0; this.prevState = 'idle'; this.oppBlockT = 0;
    this.weights = this.styleSeqs(style);
  }
  styleSeqs(style) {
    const punch = [['jab'], ['jab', 'heavyPunch'], ['jab', 'jab', 'heavyPunch'], ['heavyPunch'], ['jab', 'heavyPunch', 'jab', 'heavyPunch'], ['heavyPunch', 'jab', 'heavyPunch']];
    const kick = [['kick'], ['kick', 'heavyKick'], ['heavyKick'], ['jab', 'kick', 'heavyKick'], ['heavyPunch', 'heavyKick']];
    const k = { boxe: 0.12, kickboxing: 0.5, karate: 0.45, muaythai: 0.6, lutalivre: 0.2, mma: 0.4 }[style] || 0.4;
    return { punch, kick, k };
  }

  intent(dt, opp) {
    const f = this.f, L = this.L;
    const I = { mx: 0, mz: 0, along: 0, block: false, run: false, press: [] };
    if (this.dummy) { I.block = this.dummyBlock; return I; }
    if (!f.canAct || !opp.alive) return I;
    const d = f.dist, dx = f.dirx, dz = f.dirz, px = dz, pz = -dx;

    // percepção do ataque do oponente (com tempo de reação)
    const oppAtk = opp.state === 'attack' && opp.moveT < opp.move.active[1] + 0.05;
    if (oppAtk && d < 1.8) {
      this.react += dt;
      if (!this.noticed && this.react >= L.react) {
        this.noticed = true; const r = Math.random();
        if (r < L.pDodge && f.st > 14) this.wantDodge = true; else if (r < L.pDodge + L.pBlock) this.blockT = 0.5 + Math.random() * 0.35;
      }
    } else { this.react = 0; this.noticed = false; }
    if (opp.isBlocking) this.oppBlockT += dt; else this.oppBlockT = 0;
    if (f.prevHitState === 'blockstun' && f.state === 'idle' && Math.random() < 0.5) this.cd = Math.min(this.cd, 0.12);
    f.prevHitState = f.state;

    if (this.blockT > 0) { this.blockT -= dt; I.block = true; }
    if (this.wantDodge) { this.wantDodge = false; I.press.push('dodge'); I.mx = px * (Math.random() < 0.5 ? 1 : -1); I.mz = pz * (I.mx ? 1 : 1); if (Math.random() < 0.5) { I.mx = -dx; I.mz = -dz; } return I; }

    // espaçamento e circulação
    let along = 0;
    const tired = f.st < 22;
    if (opp.state === 'down' || opp.state === 'getup') along = d > 1.6 ? 0.5 : 0;
    else if (d > this.ideal + 0.3) along = 1; else if (d < this.ideal - 0.3) along = -0.7;
    if (tired && d < 1.6) { along = -0.6; I.block = true; }
    this.strafeT -= dt; if (this.strafeT <= 0) { this.strafe = U.pick([-1, 0, 1, 1, -1]); this.strafeT = U.rand(0.6, 1.8); }
    const side = this.strafe * 0.6;
    I.mx = dx * along + px * side; I.mz = dz * along + pz * side; I.run = d > 2.6 && along > 0;
    I.along = along;
    if (I.block) { I.mx *= 0.5; I.mz *= 0.5; }

    // sequência de golpes
    this.cd -= dt;
    if (f.state === 'idle') {
      if (this.seq.length) { this.seq = []; this.cd = U.rand(L.cd[0], L.cd[1]); }
      const hpOpp = opp.hp / opp.maxHp; const aggr = L.aggr * (hpOpp < 0.3 ? 1.3 : 1) * (tired ? 0.3 : 1);
      if (this.cd <= 0 && !I.block && opp.state !== 'down' && opp.state !== 'getup' && opp.state !== 'ko') {
        if (this.oppBlockT > 0.7 && d < 1.0 && Math.random() < L.grabP * 6) { I.press.push('grab'); this.cd = U.rand(L.cd[0], L.cd[1]); }
        else if (d <= 1.4 && Math.random() < aggr) this.startSeq(I, d);
        else if (d <= 1.55 && d > 1.3 && Math.random() < aggr * 0.5) { I.press.push(Math.random() < 0.6 ? 'kick' : 'jab'); I.along = 1; this.cd = U.rand(L.cd[0], L.cd[1]); }
        else this.cd = 0.15;
      }
    } else if (f.state === 'attack') {
      if (!this.seq.length) return I;
      if (f.cancelOpen && this.seqI < this.seq.length && this.chainOK) { I.press.push(this.seq[this.seqI++]); }
    }
    return I;
  }
  startSeq(I, d) {
    const W = this.weights, pool = Math.random() < W.k ? W.kick : W.punch;
    this.seq = U.pick(pool).slice(); this.seqI = 1; this.chainOK = Math.random() < this.L.comboP || this.seq.length === 1;
    I.press.push(this.seq[0]);
    if (this.f.cfg.style === 'muaythai' && d < 0.95 && this.seq[0] === 'heavyKick') I.along = 1; // joelhada
    this.cd = 0;
  }
}

/* Controle do jogador: converte teclas em intent relativo à câmera */
class PlayerController {
  constructor(getCamForward) { this.camF = getCamForward; }
  intent(dt, opp, f) {
    const cf = this.camF(); // vetor frontal horizontal da câmera {x,z}
    const rx = -cf.z, rz = cf.x; // direita da câmera
    const ix = (Input.isDown('right') ? 1 : 0) - (Input.isDown('left') ? 1 : 0);
    const iz = (Input.isDown('up') ? 1 : 0) - (Input.isDown('down') ? 1 : 0);
    let mx = rx * ix + cf.x * iz, mz = rz * ix + cf.z * iz;
    const m = Math.hypot(mx, mz); if (m > 1) { mx /= m; mz /= m; }
    return { mx, mz, along: m > 0.05 ? (mx * f.dirx + mz * f.dirz) / Math.max(m, 1) : 0, block: Input.isDown('block'), run: Input.isDown('run'), press: Input.flush().filter((a) => a !== 'pause') };
  }
}
