/* =====================================================================
   MÓDULO 05 — Dados: opções do editor, estilos de luta, lutadores prontos
   ===================================================================== */

const OPT = {
  sex:    [['M', 'Masculino'], ['F', 'Feminino']],
  build:  [['magro', 'Magro'], ['atletico', 'Atlético'], ['musculoso', 'Musculoso'], ['pesado', 'Pesado']],
  hair:   [['careca', 'Careca'], ['raspado', 'Raspado'], ['curto', 'Curto'], ['espetado', 'Espetado'], ['moicano', 'Moicano'],
           ['afro', 'Black power'], ['rabo', 'Rabo de cavalo'], ['coque', 'Coque'], ['longo', 'Longo'], ['trancas', 'Tranças']],
  beard:  [['nenhuma', 'Sem barba'], ['rala', 'Barba rala'], ['bigode', 'Bigode'], ['cavanhaque', 'Cavanhaque'], ['cheia', 'Barba cheia']],
  brows:  [['normal', 'Normais'], ['grossa', 'Grossas'], ['fina', 'Finas'], ['brava', 'Bravas']],
  eyes:   [['normal', 'Normais'], ['estreito', 'Estreitos'], ['grande', 'Grandes']],
  mouth:  [['neutra', 'Neutra'], ['sorriso', 'Sorriso'], ['seria', 'Séria']],
  shirt:  [['nenhuma', 'Sem camisa'], ['top', 'Top esportivo'], ['regata', 'Regata'], ['camiseta', 'Camiseta'], ['moletom', 'Manga longa'], ['kimono', 'Kimono']],
  pants:  [['boxe', 'Shorts de boxe'], ['mma', 'Bermuda MMA'], ['thai', 'Shorts muay thai'], ['treino', 'Calça de treino'], ['kimono', 'Calça de kimono']],
  gloves: [['boxe', 'Luvas de boxe'], ['mma', 'Luvas de MMA'], ['faixas', 'Faixas de mão'], ['nenhuma', 'Sem luvas']],
  boots:  [['nenhuma', 'Descalço'], ['tenis', 'Tênis'], ['botas', 'Botas de boxe']],
  headAcc: [['nenhum', 'Nenhum'], ['testeira', 'Testeira'], ['bandana', 'Bandana'], ['oculos', 'Óculos escuros'], ['mascara', 'Máscara de luta livre'], ['capacete', 'Protetor de cabeça']],
  bodyAcc: [['nenhum', 'Nenhum'], ['cinto', 'Faixa na cintura'], ['corrente', 'Corrente'], ['cinturao', 'Cinturão de campeão']],
  tattoo: [['nenhuma', 'Nenhuma'], ['tribal', 'Tribal nos braços'], ['manga', 'Manga fechada'], ['peito_asas', 'Asas no peito'], ['caveira', 'Caveira no peito'], ['estrelas', 'Estrelas']],
  scar:   [['nenhuma', 'Nenhuma'], ['sobrancelha', 'Sobrancelha'], ['bochecha', 'Bochecha'], ['olho', 'Olho'], ['peito', 'Peito']],
};

const PALETTE = {
  skin: ['#fbe0cc', '#f1c9a5', '#e0ac86', '#c68a62', '#a8693f', '#8a5230', '#6b3d22', '#4a2a17'],
  hair: ['#0d0a08', '#2b1b12', '#5a3a22', '#8b5a2b', '#c9a15a', '#e8d9a8', '#b3321f', '#8a8f99', '#f2f2f2', '#2f6fe0'],
  eyes: ['#2a1a10', '#5a3a1e', '#2e6b9e', '#3f8f5a', '#7a7f86', '#7a4aa8'],
  cloth: ['#f5f5f5', '#14141a', '#d62839', '#2f6fe0', '#18a999', '#f2b705', '#ff7a1a', '#8a4fff', '#e84a9b', '#6b7280', '#3a2a1c', '#8fd14f'],
  tattoo: ['#15151c', '#1c2a4a', '#3a1c1c', '#2a3a2a'],
};

/* Estilos de luta: multiplicadores de dano por tipo de golpe */
const STYLES = {
  boxe:       { name: 'Boxe',        punch: 1.20, kick: 0.70, knee: 0.70, grab: 0.80, speed: 1.04, desc: 'Socos +20%, chutes −30%. Combinações rápidas de mãos.' },
  kickboxing: { name: 'Kickboxing',  punch: 1.05, kick: 1.15, knee: 1.00, grab: 0.80, speed: 1.00, desc: 'Equilíbrio entre socos e chutes (+15%).' },
  karate:     { name: 'Karatê',      punch: 1.00, kick: 1.10, knee: 0.90, grab: 0.70, speed: 1.10, desc: 'Golpes mais velozes (+10%) e chutes precisos.' },
  muaythai:   { name: 'Muay Thai',   punch: 0.95, kick: 1.25, knee: 1.40, grab: 1.10, speed: 0.97, desc: 'Chutes +25% e joelhadas devastadoras (+40%).' },
  lutalivre:  { name: 'Luta livre',  punch: 0.85, kick: 0.80, knee: 0.90, grab: 1.50, speed: 0.95, desc: 'Agarrões e quedas +50%; golpes em pé mais fracos.' },
  mma:        { name: 'MMA',         punch: 1.05, kick: 1.05, knee: 1.05, grab: 1.15, speed: 1.00, desc: 'Versátil: pequenos bônus em tudo.' },
};

const ATTRS = [
  ['forca', 'Força', 'Aumenta o dano dos golpes'],
  ['velocidade', 'Velocidade', 'Movimento e golpes mais rápidos'],
  ['resistencia', 'Resistência', 'Mais vida, mais fôlego e recuperação'],
  ['defesa', 'Defesa', 'Reduz o dano recebido e o gasto ao bloquear'],
  ['tecnica', 'Técnica', 'Combos mais fáceis, críticos e menos gasto de fôlego'],
];
const ATTR_POOL = 45, ATTR_MIN = 1, ATTR_MAX = 20;

const BUILD_PRESETS = {
  magro:     { muscle: 22, fat: 12, shoulders: 42 },
  atletico:  { muscle: 52, fat: 28, shoulders: 52 },
  musculoso: { muscle: 88, fat: 30, shoulders: 72 },
  pesado:    { muscle: 58, fat: 82, shoulders: 62 },
};

function defaultFighter(over) {
  const f = {
    id: U.uid(), name: 'Novato', nick: 'Promessa', age: 24, sex: 'M', build: 'atletico',
    height: 178, muscle: 52, fat: 28, shoulders: 52, legs: 50, arms: 50, headSize: 50,
    skin: '#e0ac86',
    hairStyle: 'curto', hairColor: '#2b1b12', beard: 'nenhuma',
    eyeColor: '#5a3a1e', eyeShape: 'normal', brows: 'normal', mouth: 'neutra', noseSize: 50, faceWidth: 50,
    shirt: 'nenhuma', shirtColor: '#f5f5f5',
    pants: 'boxe', pantsColor: '#2f6fe0', trimColor: '#f5f5f5',
    gloves: 'boxe', glovesColor: '#d62839',
    boots: 'botas', bootsColor: '#14141a',
    headAcc: 'nenhum', headAccColor: '#d62839', bodyAcc: 'nenhum', bodyAccColor: '#f2b705',
    tattoo: 'nenhuma', tattooColor: '#15151c', scar: 'nenhuma',
    style: 'boxe',
    attrs: { forca: 9, velocidade: 9, resistencia: 9, defesa: 9, tecnica: 9 },
    ai: null,
  };
  return Object.assign(f, over || {});
}

/* Lutadores prontos (adversários). tier = força relativa 1..6 */
function makeRoster() {
  const A = (f, v, r, d, t) => ({ forca: f, velocidade: v, resistencia: r, defesa: d, tecnica: t });
  return [
    defaultFighter({ id: 'npc_rafa', name: 'Rafa Mendes', nick: 'Trovão', age: 27, height: 182, muscle: 70, fat: 25, skin: '#c68a62', hairStyle: 'raspado', hairColor: '#0d0a08',
      beard: 'bigode', brows: 'grossa', pants: 'boxe', pantsColor: '#18a999', trimColor: '#f2b705', gloves: 'boxe', glovesColor: '#f2b705', boots: 'botas', bootsColor: '#14141a',
      style: 'boxe', attrs: A(8, 8, 8, 7, 6), tier: 1 }),
    defaultFighter({ id: 'npc_kenji', name: 'Kenji Takeda', nick: 'Sombra', age: 31, height: 174, muscle: 48, fat: 18, skin: '#f1c9a5', hairStyle: 'curto', hairColor: '#0d0a08',
      eyeShape: 'estreito', brows: 'brava', shirt: 'kimono', shirtColor: '#f5f5f5', pants: 'kimono', pantsColor: '#f5f5f5', gloves: 'nenhuma', boots: 'nenhuma',
      bodyAcc: 'cinto', bodyAccColor: '#14141a', headAcc: 'testeira', headAccColor: '#d62839', style: 'karate', attrs: A(9, 12, 8, 9, 10), tier: 2 }),
    defaultFighter({ id: 'npc_dana', name: 'Dana Lopes', nick: 'Víbora', age: 26, sex: 'F', build: 'atletico', height: 168, muscle: 45, fat: 20, shoulders: 45, legs: 58, skin: '#a8693f',
      hairStyle: 'rabo', hairColor: '#0d0a08', eyeShape: 'grande', mouth: 'sorriso', shirt: 'top', shirtColor: '#8a4fff', pants: 'mma', pantsColor: '#14141a', trimColor: '#8a4fff',
      gloves: 'mma', glovesColor: '#8a4fff', boots: 'nenhuma', tattoo: 'estrelas', tattooColor: '#15151c', style: 'mma', attrs: A(9, 11, 10, 10, 11), tier: 3 }),
    defaultFighter({ id: 'npc_nok', name: 'Nok Srisai', nick: 'Aço', age: 29, height: 172, muscle: 62, fat: 14, skin: '#c68a62', hairStyle: 'raspado', hairColor: '#0d0a08',
      brows: 'brava', pants: 'thai', pantsColor: '#d62839', trimColor: '#f2b705', gloves: 'faixas', glovesColor: '#f5f5f5', boots: 'nenhuma', headAcc: 'testeira', headAccColor: '#f2b705',
      tattoo: 'tribal', tattooColor: '#15151c', style: 'muaythai', attrs: A(12, 11, 11, 9, 11), tier: 4 }),
    defaultFighter({ id: 'npc_igor', name: 'Igor Volkov', nick: 'Urso', age: 34, height: 193, muscle: 82, fat: 62, shoulders: 78, skin: '#fbe0cc', hairStyle: 'careca',
      beard: 'cheia', beardColor: '#5a3a22', hairColor: '#5a3a22', brows: 'grossa', shirt: 'nenhuma', pants: 'treino', pantsColor: '#14141a', trimColor: '#d62839', gloves: 'faixas', glovesColor: '#f5f5f5',
      boots: 'botas', bootsColor: '#d62839', tattoo: 'manga', tattooColor: '#1c2a4a', style: 'lutalivre', attrs: A(16, 7, 14, 12, 9), tier: 5 }),
    defaultFighter({ id: 'npc_luchador', name: 'El Fénix', nick: 'Máscara', age: 33, height: 176, muscle: 66, fat: 24, skin: '#a8693f',
      headAcc: 'mascara', headAccColor: '#f2b705', pants: 'mma', pantsColor: '#2f6fe0', trimColor: '#f2b705', gloves: 'nenhuma', boots: 'botas', bootsColor: '#f2b705',
      bodyAcc: 'cinturao', style: 'lutalivre', attrs: A(12, 13, 10, 11, 12), tier: 4 }),
    defaultFighter({ id: 'npc_marco', name: 'Marco Silva', nick: 'Relâmpago', age: 25, height: 180, muscle: 56, fat: 20, skin: '#6b3d22', hairStyle: 'moicano', hairColor: '#b3321f',
      shirt: 'regata', shirtColor: '#14141a', pants: 'mma', pantsColor: '#ff7a1a', trimColor: '#14141a', gloves: 'mma', glovesColor: '#ff7a1a', boots: 'tenis', bootsColor: '#f5f5f5',
      headAcc: 'oculos', style: 'kickboxing', attrs: A(11, 14, 11, 10, 12), tier: 4 }),
    defaultFighter({ id: 'npc_vovo', name: 'Seu Zé', nick: 'Mestre', age: 58, height: 170, muscle: 40, fat: 40, skin: '#8a5230', hairStyle: 'careca', beard: 'cavanhaque', beardColor: '#f2f2f2', hairColor: '#f2f2f2',
      shirt: 'camiseta', shirtColor: '#6b7280', pants: 'treino', pantsColor: '#6b7280', trimColor: '#f5f5f5', gloves: 'faixas', boots: 'tenis', bootsColor: '#14141a',
      style: 'karate', attrs: A(10, 10, 12, 16, 17), tier: 6 }),
  ];
}
