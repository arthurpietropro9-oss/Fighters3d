/* =====================================================================
   MÓDULO 30 — Lutador: estados, movimento, golpes, defesa, dano e colisão
   ===================================================================== */

function deriveStats(cfg) {
  const a = cfg.attrs, st = STYLES[cfg.style] || STYLES.mma;
  return {
    maxHp: Math.round(100 + a.resistencia * 3), maxSt: 80 + a.resistencia * 4, stRegen: 11 + a.resistencia * 0.7,
    dmgMul: 0.7 + a.forca * 0.03, speedMul: (0.88 + a.velocidade * 0.012) * st.speed,
    def: a.defesa * 0.015, critP: 0.02 + a.tecnica * 0.006, costMul: 1.2 - a.tecnica * 0.02, cancelBonus: a.tecnica * 0.004, style: st,
  };
}

const WALK = 1.9, RUN = 3.7, THROW_DUR = 1.15;
const BUFFERED = ['jab', 'heavyPunch', 'kick', 'heavyKick', 'dodge', 'grab'];

class Fighter {
  constructor(cfg, opts) {
    opts = opts || {};
    this.cfg = cfg; this.name = cfg.name; this.nick = cfg.nick;
    this.stats = deriveStats(cfg);
    this.rig = buildRig(cfg); this.root = this.rig.root; this.S = this.rig.S;
    this.pos = new THREE.Vector3(); this.kv = new THREE.Vector3(); this.yaw = 0;
    this.hooks = opts.hooks || {};
    this.maxHp = this.stats.maxHp; this.maxSt = this.stats.maxSt;
    this.hb = {}; this._v = new THREE.Vector3();
    this.reset(0, 0, 0);
  }

  reset(x, z, yaw) {
    this.pos.set(x, 0, z); this.kv.set(0, 0, 0); this.yaw = yaw;
    this.hp = this.maxHp; this.st = this.maxSt; this.stDelay = 0;
    this.state = 'idle'; this.stateT = 0; this.time = Math.random() * 6;
    this.move = null; this.moveT = 0; this.moveHit = false; this.whooshed = false; this.chainN = 0;
    this.buffer = null; this.blocking = false; this.invuln = 0; this.slow = 0; this.counterT = 0;
    this.stunT = 0; this.hitInfo = { zone: 'torso', amp: 1, side: 1 }; this.downTimer = 0; this.victim = null; this.grabP = 0; this.throwT = 0; this.grabT = 0; this.thrown = false; this.grabTried = false;
    this.canAct = true; this.winning = false; this.combo = 0; this.comboT = 0;
    this.pose = P(); this.from = P(); this.blendT = 1; this.blendDur = 0.1;
    this.loco = { amt: 0, fwd: 0, side: 0, run: 0, phase: 0 };
    this.dirx = 0; this.dirz = 1; this.dist = 2; this.dodgeDir = { x: 0, z: 0 };
    this.tipPrev = null;
    this.stat = { hits: 0, tried: 0, dmg: 0, maxCombo: 0, blocked: 0, throws: 0 };
    this.applyVisual();
  }

  get tScale() { return this.stats.speedMul * (this.exhausted ? 0.88 : 1); }
  get exhausted() { return this.st < 8; }
  get cancelOpen() { return this.state === 'attack' && this.moveT >= this.move.cancel[0] && this.moveT <= this.move.cancel[1] + this.stats.cancelBonus && (this.moveHit || !!this.move.freeChain); }
  get isBlocking() { return (this.state === 'idle' && this.blocking) || this.state === 'blockstun'; }
  get busy() { return this.state !== 'idle'; }
  get alive() { return this.hp > 0; }

  setState(s, blend) {
    this.state = s; this.stateT = 0;
    this.from = poseCopy(this.pose); this.blendT = 0; this.blendDur = blend === undefined ? 0.08 : blend;
  }
  toIdle() { this.move = null; this.setState('idle', 0.1); }

  /* ------------------------------ atualização ------------------------------ */
  update(dt, intent, opp) {
    this.stateT += dt; this.time += dt;
    if (this.invuln > 0) this.invuln -= dt;
    if (this.slow > 0) this.slow -= dt;
    if (this.stDelay > 0) this.stDelay -= dt;
    if (this.counterT > 0) this.counterT -= dt;
    if (this.comboT > 0) { this.comboT -= dt; if (this.comboT <= 0) this.combo = 0; }
    const dx = opp.pos.x - this.pos.x, dz = opp.pos.z - this.pos.z;
    const dist = Math.hypot(dx, dz) || 0.001;
    this.dist = dist; this.dirx = dx / dist; this.dirz = dz / dist;

    if (intent.press) for (let i = 0; i < intent.press.length; i++) { if (BUFFERED.indexOf(intent.press[i]) >= 0) this.buffer = { a: intent.press[i], t: 0.3 }; }
    if (this.buffer) { this.buffer.t -= dt; if (this.buffer.t <= 0) this.buffer = null; }

    switch (this.state) {
      case 'idle': this.uIdle(dt, intent, opp); break;
      case 'attack': this.uAttack(dt, intent); break;
      case 'hit': this.stunT -= dt; if (this.stunT <= 0) this.toIdle(); break;
      case 'blockstun': this.stunT -= dt; if (this.stunT <= 0) this.toIdle(); break;
      case 'dodge': if (this.stateT >= 0.42) { this.counterT = 0.7; this.toIdle(); } break;
      case 'grab': this.uGrab(dt, opp); break;
      case 'throw': this.uThrow(dt); break;
      case 'grabbed': break;
      case 'down': if (this.stateT >= this.downTimer) this.setState('getup', 0.1); break;
      case 'getup': if (this.stateT >= 0.55) this.toIdle(); break;
      default: break; // ko
    }

    // empurrões (knockback / esquiva) e recuperação de fôlego
    const decay = Math.exp(-7 * dt);
    this.pos.x += this.kv.x * dt; this.pos.z += this.kv.z * dt; this.kv.x *= decay; this.kv.z *= decay;
    if (this.stDelay <= 0 && this.state !== 'ko') this.st = Math.min(this.maxSt, this.st + this.stats.stRegen * (this.isBlocking ? 0.3 : 1) * dt);

    // orientação: sempre olhando para o oponente
    const noTurn = this.state === 'down' || this.state === 'ko' || this.state === 'grabbed' || this.state === 'throw' || this.state === 'getup';
    if (!noTurn) {
      const rate = this.state === 'idle' ? 14 : 6;
      this.yaw = U.dampAngle(this.yaw, Math.atan2(this.dirx, this.dirz), rate, dt);
    }
    this.updatePose(dt);
  }

  /* Anda em volta do oponente mantendo a distância (strafe circular) */
  moveAround(dt, ux, uz, speed) {
    const along = ux * this.dirx + uz * this.dirz, side = ux * this.dirz - uz * this.dirx;
    this.pos.x += this.dirx * along * speed * dt; this.pos.z += this.dirz * along * speed * dt;
    this._opp = this._opp || null;
    return { along, side };
  }

  uIdle(dt, intent, opp) {
    const can = this.canAct;
    this.blocking = can && !!intent.block && this.st > 0;
    if (can && this.buffer) {
      const a = this.buffer.a;
      if (a === 'dodge') { this.buffer = null; if (this.st >= 10) { this.startDodge(intent); return; } }
      else if (a === 'grab') { this.buffer = null; if (this.st >= 8) { this.startGrab(); return; } }
      else { const id = pickMove(a, (intent.along || 0) > 0.45); this.buffer = null; this.chainN = 0; this.startMove(id); return; }
    }
    let mx = intent.mx || 0, mz = intent.mz || 0; const mag = Math.min(1, Math.hypot(mx, mz));
    const L = this.loco; let along = 0, side = 0, run = 0;
    if (can && mag > 0.05) {
      const len = Math.hypot(mx, mz) || 1; mx /= len; mz /= len;
      const wantRun = !!intent.run && this.st > 6 && !this.blocking;
      run = wantRun ? 1 : 0;
      let speed = (wantRun ? RUN : WALK) * this.stats.speedMul * (this.blocking ? 0.5 : 1) * (this.slow > 0 ? 0.7 : 1) * (this.exhausted ? 0.85 : 1) * mag;
      along = mx * this.dirx + mz * this.dirz; side = mx * this.dirz - mz * this.dirx;
      if (along < 0) speed *= 0.82;
      if (wantRun) { this.st = Math.max(0, this.st - 9 * dt); this.stDelay = 0.6; }
      // componente radial + órbita (mantém a distância ao circular)
      this.pos.x += this.dirx * along * speed * dt; this.pos.z += this.dirz * along * speed * dt;
      const d = Math.max(this.dist, 0.6), delta = -side * speed * dt / d;
      const rx = this.pos.x - opp.pos.x, rz = this.pos.z - opp.pos.z, c = Math.cos(delta), s = Math.sin(delta);
      this.pos.x = opp.pos.x + rx * c + rz * s; this.pos.z = opp.pos.z - rx * s + rz * c;
      L.phase += dt * (3.2 + speed * 1.8);
    }
    const target = can && mag > 0.05 ? 1 : 0;
    L.amt = U.damp(L.amt, target, 12, dt); L.fwd = U.damp(L.fwd, along, 10, dt); L.side = U.damp(L.side, side, 10, dt); L.run = U.damp(L.run, run, 8, dt);
    // passo sonoro
    const sg = Math.sin(L.phase) > 0; if (this._sg !== undefined && sg !== this._sg && L.amt > 0.6 && this.hooks.sound) this.hooks.sound('step', this);
    this._sg = sg;
  }

  startMove(id) {
    const mv = MOVES[id]; if (!mv) return;
    this.st = Math.max(0, this.st - mv.cost * this.stats.costMul); this.stDelay = 0.7;
    this.move = mv; this.moveT = 0; this.moveHit = false; this.whooshed = false; this.chainN++; this.tipPrev = null; this.stat.tried++;
    this.setState('attack', 0.05);
  }

  uAttack(dt, intent) {
    const mv = this.move, ts = this.tScale, prev = this.moveT;
    this.moveT += dt * ts;
    if (!this.whooshed && this.moveT >= mv.active[0] - 0.05) { this.whooshed = true; if (this.hooks.sound) this.hooks.sound('whoosh', this); }
    const lg = mv.lunge;
    if (lg && this.moveT > lg[0] && prev < lg[1]) {
      const a = Math.max(prev, lg[0]), b = Math.min(this.moveT, lg[1]);
      const adv = lg[2] * (b - a) / (lg[1] - lg[0]);
      if (this.dist > 0.62) { this.pos.x += this.dirx * adv; this.pos.z += this.dirz * adv; }
    }
    if (this.buffer && this.cancelOpen) {
      const nid = mv.chain[this.buffer.a];
      if (nid && this.st > 1) { this.buffer = null; this.startMove(nid); return; }
    }
    if (intent.block && this.moveT >= mv.active[1] + (mv.dur - mv.active[1]) * 0.55) { this.blocking = true; this.toIdle(); return; }
    if (this.moveT >= mv.dur) this.toIdle();
  }

  startDodge(intent) {
    this.st = Math.max(0, this.st - 12); this.stDelay = 0.6;
    let mx = intent.mx || 0, mz = intent.mz || 0; const m = Math.hypot(mx, mz);
    if (m > 0.2) { mx /= m; mz /= m; } else { mx = -this.dirx; mz = -this.dirz; }
    this.dodgeDir = { x: mx, z: mz }; this.kv.set(mx * 7.5, 0, mz * 7.5);
    this.invuln = Math.max(this.invuln, 0.26); this.blocking = false;
    this.setState('dodge', 0.04);
    if (this.hooks.sound) this.hooks.sound('dodge', this);
  }

  startGrab() { this.st = Math.max(0, this.st - 10); this.stDelay = 0.7; this.grabT = 0; this.grabTried = false; this.setState('grab', 0.06); }
  uGrab(dt, opp) {
    this.grabT += dt * this.tScale;
    if (!this.grabTried && this.grabT >= 0.24) {
      this.grabTried = true;
      const ok = opp.invuln <= 0 && ['idle', 'attack', 'hit', 'blockstun', 'grab'].indexOf(opp.state) >= 0 && this.dist <= 1.08 * this.S;
      if (ok) { this.beginThrow(opp); return; }
    }
    if (this.grabT >= 0.64) this.toIdle();
  }
  beginThrow(opp) {
    this.victim = opp; this.throwT = 0; this.thrown = false; this.stat.tried++;
    this.setState('throw', 0.08);
    opp.blocking = false; opp.move = null; opp.setState('grabbed', 0.08); opp.grabP = 0;
    if (this.hooks.sound) this.hooks.sound('grab', this);
  }
  uThrow(dt) {
    const v = this.victim; this.throwT += dt * this.tScale;
    const p = U.clamp(this.throwT / THROW_DUR, 0, 1);
    if (v && v.state === 'grabbed') {
      const gap = U.lerp(0.62, 0.9, U.smooth((p - 0.55) / 0.2)) * this.S;
      v.pos.x = this.pos.x + this.dirx * gap; v.pos.z = this.pos.z + this.dirz * gap;
      v.yaw = Math.atan2(-this.dirx, -this.dirz); v.grabP = p; v.kv.set(0, 0, 0);
    }
    if (!this.thrown && p >= 0.62) {
      this.thrown = true;
      if (v && v.state === 'grabbed') {
        const r = v.receiveThrow(this);
        this.stat.hits++; this.stat.throws++; this.stat.dmg += r.dmg;
        if (this.hooks.thrown) this.hooks.thrown(this, v, r);
      }
    }
    if (p >= 1) { this.victim = null; this.toIdle(); }
  }

  /* ------------------------------ dano ------------------------------ */
  receiveThrow(att) {
    const dmg = 14 * att.stats.dmgMul * att.stats.style.grab * (1 - this.stats.def);
    this.hp = Math.max(0, this.hp - dmg);
    if (this.hp <= 0) this.beginKO(att, 5); else this.beginDown(0.9);
    return { dmg };
  }
  beginDown(power) {
    this.blocking = false; this.setState('down', 0.05);
    this.downTimer = 1.0 + power * 0.5; this.invuln = this.downTimer + 0.8;
  }
  beginKO(att, push) {
    this.blocking = false; this.hp = 0; this.setState('ko', 0.05);
    this.kv.set(att.dirx * (push || 5), 0, att.dirz * (push || 5));
  }

  /* Resolve um golpe do atacante `att` que acertou a zona `zone`. Retorna dados para efeitos visuais. */
  receive(att, mv, zone, crit) {
    const st = this.stats;
    const comboN = this.state === 'hit' ? att.combo + 1 : 1;
    let dmg = mv.dmg * att.stats.dmgMul * att.stats.style[mv.type] * ({ head: 1.3, torso: 1, legs: 0.75 }[zone]) * U.rand(0.93, 1.07)
      * Math.max(0.6, 1 - 0.08 * (comboN - 1)) * (crit ? 1.5 : 1) * (att.exhausted ? 0.8 : 1) * (att.counterT > 0 ? 1.15 : 1) * (1 - st.def);
    const ax = att.dirx, az = att.dirz; // do atacante para cá
    if (this.isBlocking) {
      const chip = Math.min(this.hp - 1, dmg * 0.1);
      this.hp -= Math.max(0, chip); this.stat.blocked++;
      this.st = Math.max(0, this.st - dmg * 1.15 * (1 - st.def * 0.8)); this.stDelay = 1.0;
      this.kv.set(ax * mv.push * 0.5, 0, az * mv.push * 0.5); att.kv.set(-ax * 0.6, 0, -az * 0.6);
      if (this.st <= 0) {
        this.blocking = false; this.stunT = 0.8; this.hitInfo = { zone: 'head', amp: 1.2, side: 1 }; this.setState('hit', 0.04);
        return { kind: 'guardbreak', zone, dmg: chip };
      }
      this.stunT = mv.bstun; this.setState('blockstun', 0.03);
      return { kind: 'block', zone, dmg: chip };
    }
    this.hp = Math.max(0, this.hp - dmg);
    att.stat.hits++; att.stat.dmg += dmg; att.combo = comboN; att.comboT = 1.2; att.stat.maxCombo = Math.max(att.stat.maxCombo, comboN);
    if (zone === 'legs' || mv.legHit) this.slow = 1.6;
    const knock = !!mv.knock || (this.hp > 0 && this.hp < this.maxHp * 0.2 && mv.dmg >= 8 && Math.random() < 0.5);
    this.blocking = false;
    this.hitInfo = { zone, amp: mv.dmg >= 8 ? 1.3 : 1, side: Math.random() < 0.5 ? -1 : 1 };
    if (this.hp <= 0) { this.beginKO(att, 3 + mv.push); return { kind: 'ko', zone, dmg, crit }; }
    this.kv.set(ax * mv.push, 0, az * mv.push);
    if (knock) { this.beginDown(mv.dmg / 10); return { kind: 'knock', zone, dmg, crit, combo: comboN }; }
    this.stunT = mv.stun; this.setState('hit', 0.03);
    return { kind: 'hit', zone, dmg, crit, combo: comboN };
  }

  /* ------------------------------ colisão ------------------------------ */
  refreshBoxes() {
    const a = this.rig.anchors, h = this.hb, v = this._v, S = this.S;
    const g = (n, o) => { a[n].getWorldPosition(v); o.x = v.x; o.y = v.y; o.z = v.z; };
    ['head', 'chest', 'pelvis', 'hipL', 'hipR', 'ankleL', 'ankleR'].forEach((n) => { h[n] = h[n] || {}; g(n, h[n]); });
    h.rHead = 0.125 * S * (0.92 + this.cfg.headSize / 100 * 0.16); h.rTorso = (0.17 + this.cfg.muscle / 100 * 0.03 + this.cfg.fat / 100 * 0.03) * S; h.rLeg = 0.105 * S;
  }
  hitZone(x, y, z, r) {
    const h = this.hb;
    if (Math.hypot(x - h.head.x, y - h.head.y, z - h.head.z) <= r + h.rHead) return 'head';
    if (U.ptSeg(x, y, z, h.chest.x, h.chest.y, h.chest.z, h.pelvis.x, h.pelvis.y, h.pelvis.z) <= r + h.rTorso) return 'torso';
    if (U.ptSeg(x, y, z, h.hipL.x, h.hipL.y, h.hipL.z, h.ankleL.x, h.ankleL.y, h.ankleL.z) <= r + h.rLeg) return 'legs';
    if (U.ptSeg(x, y, z, h.hipR.x, h.hipR.y, h.hipR.z, h.ankleR.x, h.ankleR.y, h.ankleR.z) <= r + h.rLeg) return 'legs';
    return null;
  }
  /* Verificação de golpe: só durante a janela ativa, com ponto de impacto vindo da articulação animada */
  strikeCheck(opp) {
    if (this.state !== 'attack' || !this.move) return null;
    const mv = this.move, v = this._v;
    this.rig.tips[mv.limb].getWorldPosition(v);
    const cur = { x: v.x, y: v.y, z: v.z }, prev = this.tipPrev || cur; this.tipPrev = cur;
    if (this.moveHit || this.moveT < mv.active[0] || this.moveT > mv.active[1]) return null;
    if (opp.invuln > 0 || !opp.alive || opp.state === 'down' || opp.state === 'getup' || opp.state === 'grabbed') return null;
    const r = mv.r * this.S;
    const zone = opp.hitZone(cur.x, cur.y, cur.z, r) || opp.hitZone((cur.x + prev.x) / 2, (cur.y + prev.y) / 2, (cur.z + prev.z) / 2, r) || opp.hitZone(prev.x, prev.y, prev.z, r);
    if (!zone) return null;
    this.moveHit = true;
    const crit = Math.random() < this.stats.critP;
    const res = opp.receive(this, mv, zone, crit);
    res.move = mv; res.x = cur.x; res.y = cur.y; res.z = cur.z; res.att = this; res.def = opp;
    return res;
  }

  /* ------------------------------ poses ------------------------------ */
  poseIdle() {
    const g = Object.assign({}, this.blocking ? BLOCK_POSE : GUARD), t = this.time, L = this.loco;
    const br = Math.sin(t * 2.4);
    g.y += br * 0.005 + Math.sin(t * 5.2) * 0.008 * (1 - L.amt); g.sRx += br * 0.01;
    g.lSx += Math.sin(t * 2.4 + 1) * 0.03; g.rSx += Math.sin(t * 2.4 + 2) * 0.03;
    if (this.winning) return this.poseWin();
    if (L.amt > 0.02) {
      const sw = Math.sin(L.phase), a = L.amt, m = 1 + L.run * 1.1;
      g.lHx += sw * 0.34 * L.fwd * a * m; g.rHx -= sw * 0.34 * L.fwd * a * m;
      g.lHz += sw * 0.14 * L.side * a; g.rHz -= sw * 0.14 * L.side * a;
      g.lLift = Math.max(0, sw) * 0.07 * a * m; g.rLift = Math.max(0, -sw) * 0.07 * a * m;
      g.y -= Math.abs(Math.cos(L.phase)) * 0.02 * a;
      if (L.run > 0.02) {
        const r = L.run * a;
        g.sRx += 0.22 * r; g.y -= 0.03 * r;
        g.lSx = U.lerp(g.lSx, 0.5 + sw * 0.6, r); g.rSx = U.lerp(g.rSx, 0.5 - sw * 0.6, r);
        g.lEl = U.lerp(g.lEl, 1.6, r); g.rEl = U.lerp(g.rEl, 1.6, r);
      }
    }
    return g;
  }
  poseWin() {
    const t = this.time, g = P({ y: -0.02 + Math.abs(Math.sin(t * 5)) * 0.04, sRx: -0.1, hdRx: -0.2, hdRy: 0.1, hRy: 0, sRy: 0,
      lSx: 2.7, lSz: 0.45, lEl: 0.35, rSx: 2.7, rSz: 0.45, rEl: 0.35, lHx: 0.1, rHx: -0.1, lHz: 0.12, rHz: 0.12 });
    return g;
  }
  poseHit() {
    const hi = this.hitInfo, k = Math.exp(-this.stateT * 6) * hi.amp, g = P({ lSx: 0.4, rSx: 0.35, lEl: 1.5, rEl: 1.7, hdRy: 0.34 });
    if (hi.zone === 'head') { g.hdRx = -0.6 * k; g.sRx = -0.3 * k; g.hdRz = 0.25 * k * hi.side; g.y -= 0.03; }
    else if (hi.zone === 'torso') { g.sRx += 0.55 * k; g.hdRx += 0.3 * k; g.y -= 0.07 * k; }
    else { g.y -= 0.16 * k; g.sRx += 0.2 * k; }
    return g;
  }
  poseBlockHit() {
    const k = Math.exp(-this.stateT * 9), g = Object.assign({}, BLOCK_POSE);
    g.sRx -= 0.14 * k; g.y -= 0.03 * k; g.lSx += 0.1 * k; g.rSx += 0.1 * k; return g;
  }
  poseDodge() {
    const d = this.dodgeDir, k = Math.sin(Math.min(1, this.stateT / 0.42) * Math.PI);
    const back = -(d.x * this.dirx + d.z * this.dirz), side = d.x * this.dirz - d.z * this.dirx;
    return P({ y: -0.07 - 0.08 * k, sRx: 0.1 - 0.3 * back * k + 0.2 * (1 - back) * k * 0.3, sRz: -0.45 * side * k, hdRz: 0.2 * side * k, hdRx: 0.14 + 0.1 * k, lSx: 1.1, rSx: 1.0, lEl: 2.2, rEl: 2.3 });
  }
  poseGrab() {
    const u = U.smooth(this.stateT / 0.22);
    return P({ y: -0.06 - 0.03 * u, sRx: 0.1 + 0.25 * u, lSx: 0.7 + 0.9 * u, rSx: 0.6 + 1.0 * u, lSz: 0.3, rSz: 0.3, lEl: 1.95 - 1.2 * u, rEl: 2.15 - 1.4 * u, hdRx: 0.14 });
  }
  poseThrow() {
    const p = U.clamp(this.throwT / THROW_DUR, 0, 1);
    if (p < 0.55) { const u = U.smooth(p / 0.55); return P({ y: -0.06 + 0.05 * u, sRx: 0.35 - 0.7 * u, hdRx: 0.1 - 0.2 * u, lSx: 1.6 + 0.9 * u, rSx: 1.6 + 0.9 * u, lSz: 0.3, rSz: 0.3, lEl: 0.8, rEl: 0.8 }); }
    const u = U.smooth((p - 0.55) / 0.2), w = U.smooth((p - 0.75) / 0.25);
    return P({ y: -0.04 - 0.14 * u + 0.1 * w, sRx: -0.35 + 1.0 * u - 0.6 * w, hdRx: -0.1 + 0.4 * u, lSx: 2.5 - 1.4 * u, rSx: 2.5 - 1.4 * u, lSz: 0.3, rSz: 0.3, lEl: 0.8, rEl: 0.8 });
  }
  poseGrabbed() {
    const p = this.grabP, wob = Math.sin(this.time * 14) * 0.15;
    const g = P({ lPl: 0, rPl: 0, lSx: 1.4, rSx: 1.2, lSz: 0.8, rSz: 0.8, lEl: 0.6, rEl: 0.6, hdRx: -0.4, sRx: -0.2, lHx: 0.3 + wob, rHx: 0.1 - wob, lK: 0.4, rK: 0.5, y: -0.02 });
    if (p < 0.55) { const u = U.smooth(p / 0.55); g.tRx = -0.9 * u; g.by = 0.55 * u; }
    else { const u = U.smooth((p - 0.55) / 0.12); g.tRx = U.lerp(-0.9, -1.5, u); g.by = U.lerp(0.55, 0.12, u); }
    return g;
  }
  poseDown() {
    const u = U.easeOut(this.stateT / 0.4);
    return P({ lPl: 0, rPl: 0, y: 0, tRx: -1.5 * u, by: 0.12 * u, lSx: 0.15, lSz: 0.5, lEl: 0.3, rSx: 0.15, rSz: 0.5, rEl: 0.3, lHx: 0.05, rHx: 0.02, lHz: 0.12, rHz: 0.12, lK: 0.15, rK: 0.1, sRx: 0, sRy: 0, hRy: 0, hdRx: -0.25 * u, hdRy: 0 });
  }
  poseGetup() {
    const u = U.smooth(this.stateT / 0.55), d = this.poseDown(); d.tRx = -1.5 * (1 - u); d.by = 0.12 * (1 - u);
    const g = P({ y: -0.1 * (1 - u) - 0.07 * u, sRx: 0.3 * (1 - u) + 0.1 * u, tRx: d.tRx, by: d.by });
    return poseLerp(d, g, u, {});
  }

  updatePose(dt) {
    let tg;
    switch (this.state) {
      case 'attack': tg = sampleFrames(this.move.frames, this.moveT, {}); break;
      case 'hit': tg = this.poseHit(); break;
      case 'blockstun': tg = this.poseBlockHit(); break;
      case 'dodge': tg = this.poseDodge(); break;
      case 'grab': tg = this.poseGrab(); break;
      case 'throw': tg = this.poseThrow(); break;
      case 'grabbed': tg = this.poseGrabbed(); break;
      case 'down': case 'ko': tg = this.poseDown(); break;
      case 'getup': tg = this.poseGetup(); break;
      default: tg = this.poseIdle(); break;
    }
    if (this.blendT < this.blendDur) {
      this.blendT += dt;
      this.pose = poseLerp(this.from, tg, U.smooth(this.blendT / this.blendDur), this.pose === tg ? {} : this.pose);
    } else this.pose = tg;
    this.applyVisual();
  }
  applyVisual() {
    applyPose(this.rig, this.pose);
    this.root.position.set(this.pos.x, 0, this.pos.z); this.root.rotation.y = this.yaw;
    this.root.updateMatrixWorld(true);
    this.refreshBoxes();
  }
  dispose() { this.rig.dispose(); }
}
