/* =====================================================================
   MÓDULO 10 — Modelo 3D procedural e articulado do lutador
   cfg (aparência) -> rig { root, j (articulações), tips, anchors, dims }
   Convenção: lutador olha para +Z; o lado ESQUERDO dele é +X.
   ===================================================================== */

function canvasTex(w, h, draw) {
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  draw(c.getContext('2d'), w, h);
  const t = new THREE.CanvasTexture(c);
  return t;
}

/* Desenha as tatuagens em canvas transparente (textura aplicada sobre a pele) */
function tattooTexture(kind, color) {
  return canvasTex(256, 128, (g, w, h) => {
    g.clearRect(0, 0, w, h); g.strokeStyle = color; g.fillStyle = color; g.lineCap = 'round'; g.lineJoin = 'round';
    if (kind === 'tribal') {
      g.lineWidth = 9;
      for (let r = 0; r < 3; r++) { g.beginPath(); for (let x = 0; x <= w; x += 4) { const y = 30 + r * 34 + Math.sin(x / w * Math.PI * 4 + r) * 12; x ? g.lineTo(x, y) : g.moveTo(x, y); } g.stroke(); }
      for (let x = 0; x < w; x += 32) { g.beginPath(); g.moveTo(x, 10); g.lineTo(x + 16, 118); g.lineTo(x + 32, 10); g.lineWidth = 5; g.stroke(); }
    } else if (kind === 'manga') {
      g.lineWidth = 6;
      for (let y = 6; y < h; y += 14) { g.beginPath(); for (let x = 0; x <= w; x += 4) { const yy = y + Math.sin(x / w * Math.PI * 8 + y) * 5; x ? g.lineTo(x, yy) : g.moveTo(x, yy); } g.stroke(); }
      for (let i = 0; i < 40; i++) { g.beginPath(); g.arc((i * 53) % w, (i * 31) % h, 5, 0, 7); g.fill(); }
    } else if (kind === 'peito_asas') {
      g.lineWidth = 6;
      [-1, 1].forEach((s) => { for (let i = 0; i < 6; i++) { g.beginPath(); g.moveTo(w / 2 + s * 8, 70 + i * 2); g.quadraticCurveTo(w / 2 + s * (50 + i * 14), 20 + i * 8, w / 2 + s * (70 + i * 16), 40 + i * 12); g.stroke(); } });
      g.beginPath(); g.arc(w / 2, 70, 9, 0, 7); g.fill();
    } else if (kind === 'caveira') {
      g.beginPath(); g.arc(w / 2, 52, 30, 0, 7); g.fill(); g.fillRect(w / 2 - 18, 70, 36, 30);
      g.fillStyle = 'rgba(255,255,255,.9)'; g.beginPath(); g.arc(w / 2 - 12, 52, 8, 0, 7); g.arc(w / 2 + 12, 52, 8, 0, 7); g.fill();
      g.fillRect(w / 2 - 14, 84, 4, 14); g.fillRect(w / 2 - 2, 84, 4, 14); g.fillRect(w / 2 + 10, 84, 4, 14);
    } else if (kind === 'estrelas') {
      const star = (cx, cy, r) => { g.beginPath(); for (let i = 0; i < 10; i++) { const a = -Math.PI / 2 + i * Math.PI / 5, rr = i % 2 ? r * 0.45 : r; g.lineTo(cx + Math.cos(a) * rr, cy + Math.sin(a) * rr); } g.closePath(); g.fill(); };
      star(w / 2 - 40, 50, 20); star(w / 2 + 40, 50, 20); star(w / 2, 90, 16);
    }
  });
}

function buildRig(cfg) {
  const T = THREE;
  const S = cfg.height / 180;
  const m = cfg.muscle / 100, fat = cfg.fat / 100, shw = cfg.shoulders / 100, lgp = cfg.legs / 100, arp = cfg.arms / 100, hsz = cfg.headSize / 100;
  const fem = cfg.sex === 'F', thin = fem ? 0.92 : 1;

  /* ---- dimensões (unidades locais; o root é escalado por S) ---- */
  const legLen = 0.86 + (lgp - 0.5) * 0.14, thigh = legLen * 0.52, shin = legLen * 0.48, ankleH = 0.075, hipH = legLen + ankleH;
  const torsoLen = 0.54 - (lgp - 0.5) * 0.05, neckLen = 0.08;
  const upperArm = 0.31 + (arp - 0.5) * 0.06, foreArm = 0.27 + (arp - 0.5) * 0.06;
  const shoulderHalf = (0.185 + (shw - 0.5) * 0.07 + m * 0.02) * (fem ? 0.88 : 1);
  const hipHalf = 0.085 + fat * 0.01 + (fem ? 0.015 : 0);
  const uaR = (0.042 + m * 0.018 + fat * 0.008) * thin, faR = (0.034 + m * 0.01 + fat * 0.005) * thin;
  const thR = (0.072 + m * 0.02 + fat * 0.02) * thin, shR = (0.05 + m * 0.012 + fat * 0.008) * thin;
  const XR = 1.45; // razão largura/profundidade do tronco
  const prof = [ // [y, raio-profundidade]
    [0, 0.115 + fat * 0.03 + (fem ? 0.012 : 0)],
    [0.06, 0.118 + fat * 0.03 + (fem ? 0.012 : 0)],
    [0.20, 0.095 + fat * 0.06 - (fem ? 0.006 : 0)],
    [0.34, 0.108 + m * 0.015 + fat * 0.03],
    [0.42, 0.118 + m * 0.03 + fat * 0.015],
    [0.49, 0.108 + m * 0.02],
    [torsoLen + 0.01, 0.055],
  ];
  const radiusAt = (y) => {
    if (y <= prof[0][0]) return prof[0][1];
    for (let i = 1; i < prof.length; i++) if (y <= prof[i][0]) { const a = prof[i - 1], b = prof[i]; return U.lerp(a[1], b[1], (y - a[0]) / (b[0] - a[0])); }
    return prof[prof.length - 1][1];
  };
  const lathe = (y0, y1, off, n) => {
    const pts = []; n = n || 10;
    for (let i = 0; i <= n; i++) { const y = U.lerp(y0, y1, i / n); pts.push(new T.Vector2(radiusAt(y) + off, y)); }
    return new T.LatheGeometry(pts, 22);
  };

  /* ---- materiais ---- */
  const M = (c, r, mt) => mkMat({ color: c, roughness: r === undefined ? 0.7 : r, metalness: mt || 0 });
  const mSkin = M(cfg.skin, 0.68), mHair = M(cfg.hairColor, 0.55), mBeard = M(cfg.beardColor || cfg.hairColor, 0.6);
  const mShirt = M(cfg.shirtColor, 0.8), mPants = M(cfg.pantsColor, 0.6), mTrim = M(cfg.trimColor, 0.6);
  const mGlove = M(cfg.glovesColor, 0.45), mBoot = M(cfg.bootsColor, 0.55), mAcc = M(cfg.headAccColor, 0.6), mAcc2 = M(cfg.bodyAccColor, 0.5, cfg.bodyAcc === 'cinturao' || cfg.bodyAcc === 'corrente' ? 0.7 : 0);
  const mDark = M('#101014', 0.5), mWhite = M('#f4f4f4', 0.4);

  const root = new T.Group(); const tilt = new T.Group(); root.add(tilt);
  root.scale.setScalar(S);
  const hips = new T.Group(); tilt.add(hips);
  const spine = new T.Group(); hips.add(spine);
  const neck = new T.Group(); neck.position.y = torsoLen; spine.add(neck);
  const head = new T.Group(); head.position.y = neckLen; neck.add(head);

  const mesh = (g, mat, parent, x, y, z) => { const o = new T.Mesh(g, mat); o.position.set(x || 0, y || 0, z || 0); o.castShadow = true; parent.add(o); return o; };
  const ball = (r, mat, parent, x, y, z, sx, sy, sz) => { const o = mesh(new T.SphereGeometry(r, 16, 12), mat, parent, x, y, z); if (sx !== undefined) o.scale.set(sx, sy, sz); return o; };
  const box = (w, h, d, mat, parent, x, y, z) => mesh(new T.BoxGeometry(w, h, d), mat, parent, x, y, z);
  const cyl = (rt, rb, h, mat, parent, x, y, z, seg) => mesh(new T.CylinderGeometry(rt, rb, h, seg || 14, 1), mat, parent, x, y, z);
  const limb = (rt, rb, len, mat, parent) => { const g = new T.CylinderGeometry(rt, rb, len, 14, 1); g.translate(0, -len / 2, 0); return mesh(g, mat, parent); };

  /* ---- pelve e tronco ---- */
  const pelvis = ball(1, mSkin, hips, 0, 0.03, 0, (0.115 + fat * 0.03) * XR * 1.08, 0.11, 0.115 + fat * 0.03);
  const torso = mesh(lathe(0, torsoLen + 0.01, 0, 12), mSkin, spine); torso.scale.set(XR, 1, 0.92);
  // musculatura: peitoral, abdômen, deltoides
  if (m > 0.35) {
    const pc = 0.05 + m * 0.03;
    [-1, 1].forEach((sg) => ball(pc, mSkin, spine, sg * 0.075, 0.42, 0.09 + m * 0.015, 1.3, 0.9, 0.7));
  }
  if (fat > 0.55) ball(0.13 + (fat - 0.55) * 0.14, mSkin, spine, 0, 0.17, 0.045, 1.35, 1, 0.9);

  const clothesTorso = [];
  const sh = cfg.shirt;
  if (sh === 'top' || (sh === 'nenhuma' && fem)) {
    const g = lathe(0.30, 0.50, 0.01, 6); const o = mesh(g, sh === 'top' ? mShirt : mTrim, spine); o.scale.set(XR, 1, 0.92); clothesTorso.push(o);
  } else if (sh === 'regata') {
    const o = mesh(lathe(0.04, torsoLen - 0.045, 0.011, 10), mShirt, spine); o.scale.set(XR, 1, 0.92);
    [-1, 1].forEach((sg) => box(0.05, 0.1, 0.17, mShirt, spine, sg * 0.1, torsoLen - 0.02, 0));
  } else if (sh === 'camiseta' || sh === 'moletom' || sh === 'kimono') {
    const o = mesh(lathe(0.02, torsoLen - 0.005, 0.014, 10), mShirt, spine); o.scale.set(XR, 1, 0.92);
    cyl(0.062, 0.07, 0.04, mShirt, neck, 0, -0.01, 0, 14);
    if (sh === 'kimono') { // gola em V
      [-1, 1].forEach((sg) => { const b = box(0.03, 0.42, 0.012, mWhite, spine, sg * 0.05, 0.32, 0.12); b.rotation.z = sg * 0.28; });
    }
  }

  /* ---- shorts / calças (pelve + pernas) ---- */
  const pa = cfg.pants;
  const pelvP = cyl(radiusAt(0.19) + 0.013, radiusAt(0.0) + 0.016, 0.24, mPants, hips, 0, 0.06, 0, 20); pelvP.scale.set(XR, 1, 0.96);
  const waist = cyl(radiusAt(0.19) + 0.016, radiusAt(0.19) + 0.016, 0.035, mTrim, hips, 0, 0.175, 0, 20); waist.scale.set(XR, 1, 0.96);
  const pantLen = { boxe: 0.5, mma: 0.74, thai: 0.36, treino: 1.0, kimono: 1.0 }[pa] || 0.5;
  const pantFlare = (pa === 'kimono' || pa === 'treino') ? 1.18 : 1.3;

  /* ---- braço ---- */
  const arms = {};
  const makeArm = (sg) => {
    const side = sg > 0 ? 'L' : 'R';
    const sho = new T.Group(); sho.position.set(sg * shoulderHalf, torsoLen - 0.05, 0); spine.add(sho);
    ball(uaR + 0.014 + m * 0.012, mSkin, sho);
    limb(uaR, uaR * 0.86, upperArm, mSkin, sho);
    if (m > 0.3) ball(uaR * (0.85 + m * 0.25), mSkin, sho, 0, -upperArm * 0.38, 0.012, 1, 1.5, 1);
    const el = new T.Group(); el.position.y = -upperArm; sho.add(el);
    ball(faR + 0.008, mSkin, el);
    limb(faR * 1.12, faR * 0.78, foreArm, mSkin, el);
    const wr = new T.Group(); wr.position.y = -foreArm; el.add(wr);
    // mangas
    if (sh === 'camiseta') limb(uaR + 0.013, uaR + 0.017, upperArm * 0.5, mShirt, sho);
    if (sh === 'moletom' || sh === 'kimono') { limb(uaR + 0.013, uaR + 0.018, upperArm, mShirt, sho); limb(faR * 1.12 + 0.012, faR * 0.9 + 0.016, foreArm * 0.9, mShirt, el); ball(uaR + 0.018, mShirt, sho); }
    // luvas
    const gl = cfg.gloves;
    if (gl === 'boxe') {
      ball(0.088, mGlove, wr, 0, -0.092, 0.012, 1, 1.08, 1.14);
      ball(0.035, mGlove, wr, sg * 0.058, -0.07, 0.05, 1, 1.2, 1);
      cyl(faR + 0.018, faR + 0.018, 0.05, mWhite, wr, 0, -0.01, 0, 14);
    } else if (gl === 'mma') {
      ball(0.06, mGlove, wr, 0, -0.07, 0.01, 1, 1.1, 1.1);
      cyl(faR + 0.012, faR + 0.012, 0.05, mTrim, wr, 0, -0.01, 0, 14);
    } else if (gl === 'faixas') {
      ball(0.055, mWhite, wr, 0, -0.065, 0.01, 1, 1.1, 1.1);
      cyl(faR + 0.009, faR + 0.011, 0.11, mWhite, wr, 0, -0.03, 0, 14);
    } else ball(0.052, mSkin, wr, 0, -0.06, 0.008, 1, 1.1, 1.1);
    // pontos de impacto
    const tipHand = new T.Group(); tipHand.position.set(0, -0.09, 0.01); wr.add(tipHand);
    const tipElbow = new T.Group(); tipElbow.position.set(0, -0.01, -0.03); el.add(tipElbow);
    arms[side] = { sho, el, wr, tipHand, tipElbow };
  };
  makeArm(1); makeArm(-1);

  /* ---- perna ---- */
  const legs = {};
  const makeLeg = (sg) => {
    const side = sg > 0 ? 'L' : 'R';
    const hp = new T.Group(); hp.position.set(sg * hipHalf, 0, 0); hips.add(hp);
    ball(thR + 0.008, mSkin, hp);
    limb(thR, thR * 0.76, thigh, mSkin, hp);
    if (m > 0.35) ball(thR * (0.85 + m * 0.2), mSkin, hp, 0, -thigh * 0.4, 0.025, 1, 1.6, 1);
    const kn = new T.Group(); kn.position.y = -thigh; hp.add(kn);
    ball(thR * 0.78, mSkin, kn);
    limb(shR, shR * 0.7, shin, mSkin, kn);
    ball(shR * (0.9 + m * 0.2), mSkin, kn, 0, -shin * 0.28, -0.02, 1, 1.5, 1);
    const an = new T.Group(); an.position.y = -shin; kn.add(an);
    // roupa da perna
    const pl = thigh * pantLen > thigh ? 1 : 0;
    const topLen = Math.min(pantLen, 1) * (thigh + (pantLen > 0.55 ? shin * ((pantLen - 0.55) / 0.45) : 0));
    const pg = new T.CylinderGeometry(thR + 0.013, (thR * 0.76) * pantFlare + 0.014 + (pa === 'thai' ? 0.02 : 0), Math.min(topLen, thigh), 14, 1); pg.translate(0, -Math.min(topLen, thigh) / 2, 0);
    mesh(pg, mPants, hp);
    if (topLen > thigh) { const l2 = topLen - thigh; const g2 = new T.CylinderGeometry((thR * 0.76) * pantFlare + 0.012, shR * (pa === 'kimono' ? 1.5 : 1.15) + 0.012, l2, 14, 1); g2.translate(0, -l2 / 2, 0); mesh(g2, mPants, kn); }
    if (pa === 'boxe' || pa === 'mma' || pa === 'thai') { const g3 = new T.CylinderGeometry((thR * 0.76) * pantFlare + 0.016, (thR * 0.76) * pantFlare + 0.016, 0.03, 14, 1); g3.translate(0, -Math.min(topLen, thigh) + 0.012, 0); mesh(g3, mTrim, hp); }
    // calçados
    const bt = cfg.boots;
    if (bt === 'botas') {
      cyl(shR * 0.85 + 0.014, shR * 0.78 + 0.014, 0.2, mBoot, an, 0, 0.09, 0, 14);
      box(0.095, 0.075, 0.26, mBoot, an, 0, -0.035, 0.06); ball(0.052, mBoot, an, 0, -0.035, 0.18, 1, 0.85, 1.1);
      box(0.1, 0.02, 0.27, mWhite, an, 0, -0.07, 0.06);
    } else if (bt === 'tenis') {
      cyl(shR * 0.7 + 0.01, shR * 0.68 + 0.01, 0.07, mWhite, an, 0, 0.03, 0, 12);
      box(0.092, 0.06, 0.25, mBoot, an, 0, -0.04, 0.06); ball(0.05, mBoot, an, 0, -0.038, 0.18, 1, 0.8, 1.1);
      box(0.096, 0.02, 0.27, mWhite, an, 0, -0.07, 0.06);
    } else {
      box(0.085, 0.045, 0.22, mSkin, an, 0, -0.05, 0.055); ball(0.045, mSkin, an, 0, -0.05, 0.16, 1, 0.9, 1.05);
    }
    const tipFoot = new T.Group(); tipFoot.position.set(0, -0.04, 0.12); an.add(tipFoot);
    const tipShin = new T.Group(); tipShin.position.set(0, -shin * 0.72, 0.02); kn.add(tipShin);
    const tipKnee = new T.Group(); tipKnee.position.set(0, 0, 0.09); kn.add(tipKnee);
    legs[side] = { hp, kn, an, tipFoot, tipKnee, tipShin };
  };
  makeLeg(1); makeLeg(-1);

  /* ---- cabeça e rosto ---- */
  const hs = 0.92 + hsz * 0.16, fw = 0.92 + (cfg.faceWidth / 100) * 0.16;
  const HX = 0.098 * fw * hs, HY = 0.118 * hs, HZ = 0.108 * hs;
  const skull = ball(1, mSkin, head, 0, 0.095 * hs, 0.004, HX, HY, HZ);
  ball(1, mSkin, head, 0, 0.045 * hs, 0.028 * hs, HX * 0.78, HY * 0.55, HZ * 0.78); // mandíbula
  cyl(0.047, 0.052, neckLen + 0.03, mSkin, neck, 0, 0.02, 0, 12);
  const hc = 0.095 * hs; // altura do centro do crânio
  const front = (y, x) => HZ * Math.sqrt(Math.max(0.1, 1 - (x / HX) ** 2 - ((y - hc) / HY) ** 2)) * 0.96;
  const eyeY = hc + 0.012 * hs, eyeX = 0.04 * fw * hs;
  const eyeR = ({ normal: 0.015, estreito: 0.0125, grande: 0.0185 }[cfg.eyeShape] || 0.015) * hs;
  const eyeSY = cfg.eyeShape === 'estreito' ? 0.55 : 1;
  const mEye = M(cfg.eyeColor, 0.3);
  [-1, 1].forEach((sg) => {
    ball(eyeR, mWhite, head, sg * eyeX, eyeY, front(eyeY, eyeX), 1.1, eyeSY, 0.7);
    ball(eyeR * 0.62, mEye, head, sg * eyeX, eyeY, front(eyeY, eyeX) + eyeR * 0.35, 1, eyeSY, 0.6);
    ball(eyeR * 0.3, mDark, head, sg * eyeX, eyeY, front(eyeY, eyeX) + eyeR * 0.55, 1, eyeSY, 0.5);
    const bw = { normal: 0.042, grossa: 0.046, fina: 0.04, brava: 0.045 }[cfg.brows] || 0.042;
    const bh = { normal: 0.009, grossa: 0.016, fina: 0.005, brava: 0.012 }[cfg.brows] || 0.009;
    const by = eyeY + 0.026 * hs;
    const br = box(bw * hs, bh * hs, 0.012, mHair, head, sg * eyeX, by, front(by, eyeX) + 0.002);
    br.rotation.z = sg * (cfg.brows === 'brava' ? -0.38 : -0.08) * -1;
    ball(0.024 * hs, mSkin, head, sg * HX * 0.98, hc - 0.005, -0.005, 0.5, 1, 0.8); // orelhas
  });
  const nz = 0.5 + cfg.noseSize / 100 * 0.9;
  ball(0.016 * hs * nz, mSkin, head, 0, hc - 0.02 * hs, front(hc - 0.02 * hs, 0) + 0.006 * hs, 1, 1.1, 1);
  const mouthY = hc - 0.06 * hs, mz = front(mouthY, 0);
  const mMouth = M('#7a2b2b', 0.5);
  if (cfg.mouth === 'sorriso') { const t = mesh(new T.TorusGeometry(0.02 * hs, 0.004, 6, 14, Math.PI), mMouth, head, 0, mouthY + 0.01, mz + 0.002); t.rotation.z = Math.PI; }
  else box((cfg.mouth === 'seria' ? 0.034 : 0.04) * hs, 0.006, 0.01, mMouth, head, 0, mouthY, mz + 0.002);

  /* ---- cabelo ---- */
  const cap = (r, thetaLen, rotX, y, z, mat) => {
    const o = mesh(new T.SphereGeometry(1, 20, 12, 0, Math.PI * 2, 0, thetaLen), mat || mHair, head, 0, y === undefined ? hc + 0.004 : y, z === undefined ? -0.004 : z);
    o.scale.set(HX * r, HY * r, HZ * r); o.rotation.x = rotX; return o;
  };
  const hairStyle = cfg.hairStyle;
  if (cfg.headAcc !== 'mascara') {
    if (hairStyle === 'raspado') cap(1.025, Math.PI * 0.5, -0.28);
    else if (hairStyle !== 'careca') {
      if (hairStyle === 'afro') ball(0.155 * hs, mHair, head, 0, hc + 0.04, -0.015);
      else cap(1.07, Math.PI * 0.6, -0.3);
    }
    if (hairStyle === 'espetado') for (let i = 0; i < 9; i++) { const a = (i / 9) * Math.PI * 2, r = i % 2 ? 0.05 : 0.025; const c = mesh(new T.ConeGeometry(0.02, 0.07, 6), mHair, head, Math.cos(a) * r, hc + HY * 0.95 + (i % 2) * 0.01, Math.sin(a) * r - 0.01); c.rotation.set(Math.sin(a) * 0.4, 0, -Math.cos(a) * 0.4); }
    if (hairStyle === 'moicano') for (let i = 0; i < 8; i++) { const z = -0.075 + i * 0.022; box(0.026, 0.05 + 0.03 * Math.sin((i / 7) * Math.PI), 0.025, mHair, head, 0, hc + HY * Math.sqrt(Math.max(0.05, 1 - (z / HZ) ** 2)) + 0.02, z); }
    if (hairStyle === 'rabo') { ball(0.03, mHair, head, 0, hc + 0.0, -HZ * 1.0); for (let i = 0; i < 3; i++) ball(0.028 - i * 0.004, mHair, head, 0, hc - 0.03 - i * 0.045, -HZ * 1.05 - 0.01 * i, 1, 1.5, 1); }
    if (hairStyle === 'coque') ball(0.05, mHair, head, 0, hc + HY * 0.95, -0.035);
    if (hairStyle === 'longo') { box(HX * 2.0, 0.3, 0.05, mHair, head, 0, hc - 0.09, -HZ * 0.82); [-1, 1].forEach((sg) => box(0.02, 0.17, 0.09, mHair, head, sg * HX * 0.98, hc - 0.03, -0.02)); }
    if (hairStyle === 'trancas') for (let i = -2; i <= 2; i++) { const t = cyl(0.012, 0.008, 0.28, mHair, head, i * 0.034, hc - 0.07, -HZ * 0.85, 8); t.rotation.x = -0.1; }
  }

  /* ---- barba ---- */
  const bd = cfg.beard;
  if (bd === 'rala' || bd === 'cheia') {
    const o = mesh(new T.SphereGeometry(1, 18, 10, 0, Math.PI * 2, Math.PI * 0.52, Math.PI * (bd === 'cheia' ? 0.4 : 0.3)), mBeard, head, 0, hc - 0.002, 0.004);
    o.scale.set(HX * 1.04, HY * 1.04, HZ * 1.04);
    if (bd === 'rala') { mBeard.transparent = true; mBeard.opacity = 0.5; }
    else box(0.09 * hs, 0.04, 0.03, mBeard, head, 0, mouthY - 0.045 * hs, front(mouthY - 0.045 * hs, 0) - 0.012);
  }
  if (bd === 'bigode' || bd === 'cheia') box(0.07 * hs, 0.012, 0.014, mBeard, head, 0, mouthY + 0.02 * hs, mz + 0.004);
  if (bd === 'cavanhaque') { ball(0.022 * hs, mBeard, head, 0, mouthY - 0.035 * hs, front(mouthY - 0.035 * hs, 0) - 0.004, 1, 1.4, 0.8); box(0.05 * hs, 0.01, 0.012, mBeard, head, 0, mouthY + 0.02 * hs, mz + 0.004); }

  /* ---- acessórios de cabeça ---- */
  const ha = cfg.headAcc;
  if (ha === 'testeira') { const t = mesh(new T.TorusGeometry(1, 0.1, 8, 28), mAcc, head, 0, hc + HY * 0.45, 0); t.scale.set(HX * 1.02, HZ * 1.03, 1); t.rotation.x = Math.PI / 2; t.scale.set(HX * 1.04, HZ * 1.04, HY * 0.16); ball(0.025, mAcc, head, 0, hc + HY * 0.45, -HZ * 1.02); }
  if (ha === 'bandana') { cap(1.08, Math.PI * 0.52, -0.2, undefined, undefined, mAcc); ball(0.028, mAcc, head, 0, hc + 0.03, -HZ * 1.05); box(0.04, 0.09, 0.012, mAcc, head, 0.015, hc - 0.03, -HZ * 1.08); }
  if (ha === 'oculos') {
    [-1, 1].forEach((sg) => { const l = cyl(0.026 * hs, 0.026 * hs, 0.008, mDark, head, sg * eyeX, eyeY, front(eyeY, eyeX) + 0.012, 16); l.rotation.x = Math.PI / 2; box(0.01, 0.006, 0.1, mDark, head, sg * HX * 0.96, eyeY, -0.02); });
    box(0.03, 0.006, 0.006, mDark, head, 0, eyeY, front(eyeY, 0) + 0.014);
  }
  if (ha === 'mascara') {
    const o = ball(1, mAcc, head, 0, hc, 0.002, HX * 1.045, HY * 1.045, HZ * 1.045);
    const mTr = M(cfg.trimColor, 0.6);
    [-1, 1].forEach((sg) => { ball(eyeR * 2.2, mDark, head, sg * eyeX, eyeY, front(eyeY, eyeX) + 0.014, 1.2, 0.8, 0.4); ball(eyeR * 0.9, mWhite, head, sg * eyeX, eyeY, front(eyeY, eyeX) + 0.026, 1.1, eyeSY, 0.5); ball(eyeR * 0.5, mDark, head, sg * eyeX, eyeY, front(eyeY, eyeX) + 0.032, 1, eyeSY, 0.5); });
    box(0.05 * hs, 0.028, 0.012, mDark, head, 0, mouthY, mz + 0.012);
    const st = mesh(new T.TorusGeometry(1, 0.05, 6, 24), mTr, head, 0, hc + HY * 0.3, 0.0); st.rotation.x = Math.PI / 2; st.scale.set(HX * 1.05, HZ * 1.05, HY * 0.25);
    for (let i = -1; i <= 1; i++) box(0.012, 0.09, 0.006, mTr, head, i * 0.02, hc - HY * 0.1, -HZ * 1.04);
  }
  if (ha === 'capacete') {
    cap(1.1, Math.PI * 0.62, -0.1, undefined, undefined, mAcc);
    [-1, 1].forEach((sg) => { ball(0.05 * hs, mAcc, head, sg * HX * 1.05, hc - 0.02, 0.0, 0.6, 1.3, 1); ball(0.032 * hs, mAcc, head, sg * HX * 0.86, hc - 0.07 * hs, HZ * 0.55, 0.8, 1.2, 0.8); });
    box(0.06, 0.06, 0.02, mAcc, head, 0, hc + HY * 0.55, HZ * 0.9);
  }

  /* ---- acessórios de corpo ---- */
  const ba = cfg.bodyAcc;
  if (ba === 'cinto') { const b = cyl(radiusAt(0.2) + 0.024, radiusAt(0.2) + 0.024, 0.045, mAcc2, hips, 0, 0.17, 0, 20); b.scale.set(XR, 1, 0.96); box(0.04, 0.2, 0.012, mAcc2, hips, -0.05, 0.05, radiusAt(0.2) * 1.0 + 0.04); box(0.04, 0.17, 0.012, mAcc2, hips, 0.02, 0.06, radiusAt(0.2) * 1.0 + 0.045); }
  if (ba === 'corrente') { const t = mesh(new T.TorusGeometry(0.1, 0.01, 8, 24), mAcc2, spine, 0, torsoLen - 0.04, 0.03); t.rotation.x = Math.PI / 2 - 0.5; t.scale.set(1.2, 1.1, 1); ball(0.02, mAcc2, spine, 0, torsoLen - 0.2, 0.125); }
  if (ba === 'cinturao') { const b = cyl(radiusAt(0.2) + 0.026, radiusAt(0.2) + 0.026, 0.07, mDark, hips, 0, 0.16, 0, 22); b.scale.set(XR, 1, 0.96); const pl = box(0.17, 0.12, 0.02, mAcc2, hips, 0, 0.16, radiusAt(0.2) + 0.03); ball(0.022, mDark, hips, 0, 0.16, radiusAt(0.2) + 0.045, 1, 1, 0.5); }

  /* ---- tatuagens (texturas transparentes sobre a pele) ---- */
  const tk = cfg.tattoo;
  if (tk !== 'nenhuma') {
    const tex = tattooTexture(tk, cfg.tattooColor);
    const mT = new T.MeshBasicMaterial({ map: tex, transparent: true, depthWrite: false, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -2 });
    if (tk === 'tribal' || tk === 'manga') {
      ['L', 'R'].forEach((s) => {
        const a = arms[s]; const g = new T.CylinderGeometry(uaR + 0.0025, uaR * 0.86 + 0.0025, upperArm * 0.8, 16, 1, true); g.translate(0, -upperArm * 0.45, 0);
        mesh(g, mT, a.sho).castShadow = false;
        if (tk === 'manga') { const g2 = new T.CylinderGeometry(faR * 1.12 + 0.0025, faR * 0.78 + 0.0025, foreArm * 0.8, 16, 1, true); g2.translate(0, -foreArm * 0.4, 0); mesh(g2, mT, a.el).castShadow = false; }
      });
    } else {
      const y0 = tk === 'estrelas' ? 0.3 : 0.28, hh = 0.2, r = radiusAt(y0 + hh / 2) + 0.004;
      const g = new T.CylinderGeometry(r, r, hh, 24, 1, true, -0.95, 1.9); g.translate(0, y0 + hh / 2, 0);
      const o = mesh(g, mT, spine); o.scale.set(XR, 1, 0.92); o.castShadow = false;
    }
  }
  /* ---- cicatrizes ---- */
  if (cfg.scar !== 'nenhuma') {
    const mS = M('#b86a62', 0.6);
    if (cfg.scar === 'sobrancelha') { const s = box(0.006, 0.05 * hs, 0.006, mS, head, 0.04 * fw * hs, eyeY + 0.03 * hs, front(eyeY + 0.03 * hs, 0.04) + 0.003); s.rotation.z = 0.5; }
    if (cfg.scar === 'olho') { const s = box(0.006, 0.08 * hs, 0.006, mS, head, -0.04 * fw * hs, eyeY, front(eyeY, 0.04) + 0.012); s.rotation.z = -0.15; }
    if (cfg.scar === 'bochecha') for (let i = 0; i < 3; i++) { const s = box(0.04 * hs, 0.005, 0.006, mS, head, 0.055 * hs, hc - 0.03 - i * 0.012, front(hc - 0.03, 0.055) - 0.008); s.rotation.y = 0.9; s.rotation.z = 0.2; }
    if (cfg.scar === 'peito') { const s = box(0.012, 0.18, 0.008, mS, spine, 0.07, 0.38, radiusAt(0.38) * 0.92 + 0.012); s.rotation.z = 0.7; }
  }

  /* ---- âncoras (hurtboxes) ---- */
  const A = (parent, x, y, z) => { const g = new T.Group(); g.position.set(x, y, z); parent.add(g); return g; };
  const anchors = {
    head: A(head, 0, hc, 0), chest: A(spine, 0, torsoLen * 0.78, 0), pelvis: A(hips, 0, 0.06, 0),
    hipL: A(hips, hipHalf, -0.02, 0), hipR: A(hips, -hipHalf, -0.02, 0),
    ankleL: legs.L.an, ankleR: legs.R.an,
  };
  const tips = { handL: arms.L.tipHand, handR: arms.R.tipHand, elbowL: arms.L.tipElbow, elbowR: arms.R.tipElbow,
    footL: legs.L.tipFoot, footR: legs.R.tipFoot, shinL: legs.L.tipShin, shinR: legs.R.tipShin, kneeL: legs.L.tipKnee, kneeR: legs.R.tipKnee };

  // peças pequenas não projetam sombra (menos chamadas de desenho)
  root.traverse((o) => { if (o.geometry && o.castShadow && o.geometry.computeBoundingSphere) { o.geometry.computeBoundingSphere(); const bs = o.geometry.boundingSphere; if (bs && bs.radius * Math.max(o.scale.x, o.scale.y, o.scale.z) < 0.045) o.castShadow = false; } });
  const rig = {
    root, S, tips, anchors, cfg,
    j: { tilt, hips, spine, neck, head, shL: arms.L.sho, elL: arms.L.el, shR: arms.R.sho, elR: arms.R.el, hpL: legs.L.hp, knL: legs.L.kn, anL: legs.L.an, hpR: legs.R.hp, knR: legs.R.kn, anR: legs.R.an },
    dims: { hipH, thigh, shin, ankleH, torsoLen, upperArm, foreArm, headR: Math.max(HX, HZ) },
    dispose() {
      root.traverse((o) => { if (o.geometry) o.geometry.dispose(); if (o.material) { if (o.material.map) o.material.map.dispose(); o.material.dispose(); } });
    },
  };
  return rig;
}

/* Aplica uma pose (objeto com as chaves de POSE_KEYS) às articulações.
   Ângulos "espelhados": os mesmos números movem braço/perna esquerdo e direito de modo simétrico.
   Pernas com plantio (Pl>0) têm joelho/tornozelo calculados por IK para o pé ficar no chão. */
function applyPose(rig, p) {
  const j = rig.j, d = rig.dims;
  j.tilt.rotation.set(p.tRx, 0, p.tRz); j.tilt.position.set(p.bx, p.by, p.bz);
  j.hips.position.y = d.hipH + p.y; j.hips.rotation.y = p.hRy;
  j.spine.rotation.set(p.sRx, p.sRy, p.sRz);
  j.head.rotation.set(p.hdRx, p.hdRy, p.hdRz);
  j.shL.rotation.set(-p.lSx, -p.lSy, p.lSz); j.elL.rotation.x = -p.lEl;
  j.shR.rotation.set(-p.rSx, p.rSy, -p.rSz); j.elR.rotation.x = -p.rEl;
  const leg = (side, a, hy, hz, k, ank, pl, lift) => {
    const sg = side === 'L' ? 1 : -1;
    const hp = side === 'L' ? j.hpL : j.hpR, kn = side === 'L' ? j.knL : j.knR, an = side === 'L' ? j.anL : j.anR;
    const Dv = d.hipH + p.y - d.ankleH - lift * pl;
    let v = (Dv - d.thigh * Math.cos(a)) / d.shin; v = v > 1 ? 1 : v < -1 ? -1 : v;
    const kIK = a + Math.acos(v);
    const K = U.lerp(k, Math.max(0, kIK), pl);
    hp.rotation.set(-a, -sg * hy, sg * hz); kn.rotation.x = K;
    an.rotation.x = pl * (a - K) + ank;
  };
  leg('L', p.lHx, p.lHy, p.lHz, p.lK, p.lA, p.lPl, p.lLift);
  leg('R', p.rHx, p.rHy, p.rHz, p.rK, p.rA, p.rPl, p.rLift);
}
