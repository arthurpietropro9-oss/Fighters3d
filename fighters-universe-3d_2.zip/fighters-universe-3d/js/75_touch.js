/* =====================================================================
   MÓDULO 75 — Controles na tela (celular/tablet): joystick + botões
   Usa o mesmo sistema de entrada do teclado (Input), então a luta não muda.
   ===================================================================== */

const Touch = {
  el: null, knob: null, base: null, joyId: null,
  enabled() { const m = Settings.data.touch; return m === 'on' || (m !== 'off' && IS_TOUCH); },
  hold(action, on) { const c = Input.norm(Input.codes(action)[0]); if (on) Input.down.add(c); else Input.down.delete(c); },
  release() { ['left', 'right', 'up', 'down', 'block', 'run'].forEach((a) => Touch.hold(a, false)); if (Touch.knob) Touch.knob.style.transform = 'translate(0,0)'; Touch.joyId = null; U.$$('.tb.down').forEach((b) => b.classList.remove('down')); },
  show(on) { if (!Touch.el) return; const v = on && Touch.enabled(); Touch.el.classList.toggle('on', v); if (!v) Touch.release(); },
  joy(e) {
    const r = Touch.base.getBoundingClientRect(), R = r.width / 2;
    let dx = (e.clientX - (r.left + R)) / R, dy = (e.clientY - (r.top + R)) / R; const m = Math.hypot(dx, dy); if (m > 1) { dx /= m; dy /= m; }
    Touch.knob.style.transform = 'translate(' + (dx * R * 0.55) + 'px,' + (dy * R * 0.55) + 'px)';
    const T = 0.3; Touch.hold('right', dx > T); Touch.hold('left', dx < -T); Touch.hold('up', dy < -T); Touch.hold('down', dy > T);
  },
  init() {
    const root = $id('touch'); if (!root) return; Touch.el = root;
    document.body.classList.toggle('touch', Touch.enabled());
    const base = h('div', { class: 'joy' }, h('div', { class: 'knob' })); Touch.base = base; Touch.knob = base.firstChild;
    base.addEventListener('pointerdown', (e) => { e.preventDefault(); Touch.joyId = e.pointerId; try { base.setPointerCapture(e.pointerId); } catch (x) { /* */ } Touch.joy(e); });
    base.addEventListener('pointermove', (e) => { if (e.pointerId === Touch.joyId) Touch.joy(e); });
    const end = (e) => { if (e.pointerId === Touch.joyId) { Touch.joyId = null; ['left', 'right', 'up', 'down'].forEach((a) => Touch.hold(a, false)); Touch.knob.style.transform = 'translate(0,0)'; } };
    base.addEventListener('pointerup', end); base.addEventListener('pointercancel', end);
    root.appendChild(base);
    // [ação, rótulo, direita(px), embaixo(px), tipo, classe]
    const B = [['jab', 'Soco', 112, 104, 'press', 'p'], ['heavyPunch', 'Forte', 30, 104, 'press', 'p'], ['kick', 'Chute', 112, 24, 'press', 'k'], ['heavyKick', 'Alto', 30, 24, 'press', 'k'],
      ['block', 'Defesa', 198, 64, 'hold', 'd'], ['dodge', 'Esquiva', 30, 184, 'press', 'o'], ['grab', 'Agarrão', 112, 184, 'press', 'o'], ['run', 'Correr', 198, 156, 'hold', 'o']];
    B.forEach(([a, label, r, b, kind, cls]) => {
      const el = h('button', { class: 'tb ' + cls, style: 'right:calc(' + r + 'px + env(safe-area-inset-right,0px));bottom:calc(' + b + 'px + env(safe-area-inset-bottom,0px))', 'aria-label': label }, h('span', null, label));
      el.addEventListener('pointerdown', (e) => { e.preventDefault(); el.classList.add('down'); try { el.setPointerCapture(e.pointerId); } catch (x) { /* */ } if (kind === 'press') Input.press(a); else Touch.hold(a, true); });
      const up = () => { el.classList.remove('down'); if (kind === 'hold') Touch.hold(a, false); };
      el.addEventListener('pointerup', up); el.addEventListener('pointercancel', up);
      root.appendChild(el);
    });
    const p = h('button', { class: 'tb tpause', 'aria-label': 'Pausar' }, h('span', null, 'Pausa'));
    p.addEventListener('pointerdown', (e) => { e.preventDefault(); if (Input.onPause) Input.onPause(); });
    root.appendChild(p);
  },
};
