// Ajustes do projeto Android gerado: orientação horizontal e tela cheia.
const fs = require('fs'), path = require('path');
const man = 'android/app/src/main/AndroidManifest.xml', sty = 'android/app/src/main/res/values/styles.xml';
let m = fs.readFileSync(man, 'utf8');
if (!m.includes('screenOrientation')) m = m.replace('<activity', '<activity\n            android:screenOrientation="sensorLandscape"');
fs.writeFileSync(man, m);
let s = fs.readFileSync(sty, 'utf8');
if (!s.includes('windowFullscreen')) s = s.replace(/(<style name="AppTheme.NoActionBar"[^>]*>)/, '$1\n        <item name="android:windowFullscreen">true</item>\n        <item name="android:windowLayoutInDisplayCutoutMode">shortEdges</item>');
fs.writeFileSync(sty, s);
console.log('Android ajustado: paisagem + tela cheia.');
