// Copia o jogo para ./www e baixa o Three.js (r128) para funcionar 100% offline dentro do app.
const fs = require('fs'), path = require('path'), https = require('https');
const root = path.join(__dirname, '..'), www = path.join(root, 'www');
fs.rmSync(www, { recursive: true, force: true });
['js', 'css', 'icons'].forEach((d) => fs.mkdirSync(path.join(www, d), { recursive: true }));
const cp = (rel) => fs.copyFileSync(path.join(root, rel), path.join(www, rel));
fs.readdirSync(path.join(root, 'js')).forEach((f) => cp('js/' + f));
cp('css/style.css'); fs.readdirSync(path.join(root, 'icons')).forEach((f) => cp('icons/' + f)); cp('manifest.webmanifest');
const URL = 'https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js';
https.get(URL, (res) => {
  if (res.statusCode !== 200) { console.error('Falha ao baixar o Three.js: HTTP ' + res.statusCode); process.exit(1); }
  const out = fs.createWriteStream(path.join(www, 'js/three.min.js'));
  res.pipe(out); out.on('finish', () => {
    let html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
    html = html.replace(URL, 'js/three.min.js').replace(/<script>[^<]*serviceWorker[^<]*<\/script>/, '');
    fs.writeFileSync(path.join(www, 'index.html'), html);
    console.log('www/ pronto (Three.js local).');
  });
}).on('error', (e) => { console.error('Sem internet para baixar o Three.js:', e.message); process.exit(1); });
