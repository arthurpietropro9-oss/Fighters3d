# Como gerar o APK (Android)

> Estes passos NÃO foram executados no ambiente onde o jogo foi criado (sem Android SDK nem internet). Usam ferramentas padrão (Capacitor + Gradle), mas podem pedir pequenos ajustes.

## Opção A — Sem instalar nada: GitHub Actions (recomendada)
1. Crie um repositório no GitHub e envie TODO o conteúdo desta pasta (inclusive `.github/`).
2. Abra a aba **Actions → Gerar APK → Run workflow** (ou faça um push na branch `main`).
3. Ao terminar (uns 5–8 min), baixe o arquivo **fighters-universe-apk** em *Artifacts*. Dentro está o `app-debug.apk`.
4. Copie para o celular, abra e permita "instalar apps desconhecidos".

## Opção B — No seu computador (Android Studio)
1. Instale Node.js 18+, JDK 17 e Android Studio.
2. Na pasta: `npm install`, depois `npm run prepare-www`, depois `npm run android:add`, depois `npm run android:sync`.
3. `npm run android:open` abre o Android Studio → **Build > Build APK(s)**.

## Opção C — Sem APK: instalar como app (PWA)
Hospede a pasta em qualquer site HTTPS (Netlify Drop, GitHub Pages, Vercel). No Chrome do celular: menu ⋮ → **Instalar app / Adicionar à tela inicial**. Abre em tela cheia, na horizontal.

## Se ainda estiver pesado
No jogo: Controles e opções → **Qualidade gráfica: Baixa**. A resolução também se ajusta sozinha durante a luta.
